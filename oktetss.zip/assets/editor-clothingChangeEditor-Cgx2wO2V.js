import{C as ye,P as we,_ as Ce}from"./editor-aiEditor-Dm1L4C_K.js";import{d as g,A as _e,y as P,q as j,T as ke,_ as Ie}from"./vendor-bdgQI7wY.js";import{_ as V,m as U,k as Pe,U as q,n as W,D as Te,L as De,p as Ee,q as Ue,h as Le,t as xe,u as Se,v as Ae}from"./editor-MotionEditor-B8LJN4fm.js";import{C as Z,U as Re,u as Me,g as Be}from"./editor-common-ColFbeBm.js";const h=Le.bind(Ie),Ne=H=>{const{onBackToHome:J,initialFiles:y,t:o,language:X,setLanguage:K}=H,[p,d]=g([]),[w,Q]=g({prompt:"",referenceImage:null,numImages:1,color:null,aiProvider:"haipix",haipixModel:"google_image_gen_banana_3",haipixMode:"vip1",haipixRatio:"auto",haipixResolution:"5k"}),[L,x]=g(!1),[S,A]=g(0),[Y,R]=g(0),[ee,M]=g(0),[B,f]=g(""),[te,ne]=g(!1),[C,F]=g(null),O=_e(!1),[ae,se]=g(!0);P(()=>{const e=t=>{if(t.key==="*"){const n=t.target;["INPUT","TEXTAREA","SELECT"].includes(n.tagName)||(t.preventDefault(),se(a=>!a))}};return window.addEventListener("keydown",e),()=>window.removeEventListener("keydown",e)},[]);const _=j(e=>{if(!e)return;const t=Array.from(e).filter(a=>a.type.startsWith("image/"));if(t.length===0)return;t.length>0&&!document.fullscreenElement&&document.documentElement.requestFullscreen().catch(a=>{console.warn(`Could not enter fullscreen mode: ${a.message}`)});const n=t.map(a=>({id:Date.now()+Math.random(),file:a,original:URL.createObjectURL(a),generated:null,status:"pending",selected:!0}));d(a=>[...a,...n])},[]);P(()=>{y&&y.length>0&&!O.current&&(_(y),O.current=!0)},[y,_]),P(()=>{const e=async t=>{var c;const n=t.target;if(["INPUT","TEXTAREA","SELECT"].includes(n.tagName))return;const a=(c=t.clipboardData)==null?void 0:c.items;if(!a)return;const r=[];for(let l=0;l<a.length;l++){const s=a[l];if(s.type.startsWith("image/")){const i=s.getAsFile();i&&r.push(i)}}if(r.length>0){t.preventDefault();const l=r.map(s=>({id:Date.now()+Math.random(),file:s,original:URL.createObjectURL(s),generated:null,status:"pending",selected:!0}));d(s=>[...s,...l])}};return document.addEventListener("paste",e),()=>document.removeEventListener("paste",e)},[]);const z=e=>new Promise((t,n)=>{const a=new FileReader;a.onload=()=>t(a.result),a.onerror=()=>n(new Error(`Lỗi đọc file: ${e.name}`)),a.readAsDataURL(e)}),oe=async(e,t,n)=>{let a=0;M(e.length),R(0);const r=[...e],c=async()=>{for(;r.length>0;){const l=r.shift();l&&(await n(l),a++,R(s=>s+1),A(Math.round(a/e.length*100)),r.length>0&&await new Promise(s=>setTimeout(s,2e3)))}};await Promise.all(Array(t).fill(null).map(()=>c()))},re=j(async()=>{x(!0),A(0),f("");const e=p.filter(n=>n.selected&&(n.status==="pending"||n.status==="error"));M(e.length);const t=async n=>{d(a=>a.map(r=>r.id===n.id?{...r,status:"processing",processingStartTime:Date.now(),processingPhase:"uploading"}:r));try{const a=await z(n.file),{numImages:r,...c}=w,l=await V(a,c,s=>{d(i=>i.map(u=>u.id===n.id?{...u,processingPhase:s}:u))});d(s=>s.map(i=>i.id===n.id?{...i,generated:l,status:"done",processingPhase:"done"}:i))}catch(a){throw f(U(a,o)),console.error(`Error processing image ${n.id}:`,a),d(r=>r.map(c=>c.id===n.id?{...c,status:"error"}:c)),a}};try{await oe(e,1,t)}catch(n){console.error(o("batch_processing_stopped"),n)}finally{x(!1)}},[p,w,o]),le=async e=>{const t=p.find(n=>n.id===e);if(t){d(n=>n.map(a=>a.id===e?{...a,status:"processing",generated:null,processingStartTime:Date.now(),processingPhase:"uploading"}:a)),f("");try{const n=await z(t.file),{numImages:a,...r}=w,c=await V(n,r,l=>{d(s=>s.map(i=>i.id===e?{...i,processingPhase:l}:i))});d(l=>l.map(s=>s.id===e?{...s,generated:c,status:"done",processingPhase:"done"}:s))}catch(n){f(U(n,o)),d(a=>a.map(r=>r.id===e?{...r,status:"error"}:r))}}},ie=e=>d(t=>t.filter(n=>n.id!==e)),ce=()=>d([]),de=e=>d(t=>t.map(n=>n.id===e?{...n,selected:!n.selected}:n)),ge=()=>d(e=>e.map(t=>({...t,selected:!0}))),pe=()=>d(e=>e.map(t=>({...t,selected:!1}))),ue=e=>{_(e.currentTarget.files),e.currentTarget.value=""},k=(e,t)=>{e.preventDefault(),e.stopPropagation(),ne(t)},he=e=>{var t;k(e,!1),_(((t=e.dataTransfer)==null?void 0:t.files)||null)},[G,N]=g(!1),me=async e=>{e.preventDefault(),e.stopPropagation();const t=p.filter(n=>n.selected&&n.generated);if(t.length!==0){N(!0);try{const{default:n}=await Ce(async()=>{const{default:i}=await import("https://cdn.jsdelivr.net/npm/jszip@3.10.1/+esm");return{default:i}},[]),a=new n;let r=0;for(let i=0;i<t.length;i++){const u=t[i];if(u.generated)try{const m=await xe(u.generated),$=`${String(i+1).padStart(3,"0")}_${u.file.name.split(".")[0]}-clothing.png`;a.file($,m),r++}catch(m){console.error("Error fetching image for zip:",m)}}if(r===0)throw new Error("Không thể tải được ảnh nào do lỗi kết nối hoặc CORS.");const c=await a.generateAsync({type:"blob"}),l=URL.createObjectURL(c),s=document.createElement("a");s.href=l,s.download=`clothing-changed-${new Date().toISOString().slice(0,10)}.zip`,document.body.appendChild(s),s.click(),document.body.removeChild(s),URL.revokeObjectURL(l)}catch(n){console.error("Error creating zip:",n),alert("Lỗi khi tải xuống: "+n.message+`

Giải pháp: Bấm vào từng ảnh để xem to rồi chuột phải chọn "Lưu hình ảnh thành..."`)}finally{N(!1)}}},[b,I]=g(null),[$e,fe]=g([]);P(()=>{Pe("image").then(fe).catch(e=>console.error("Models fetch error",e))},[]);const be=async(e,t,n)=>{if(!b||b.length===0)return;const a=[...b];I(null),f("");const r=new Set(a.map(c=>c.id));d(c=>c.map(l=>r.has(l.id)?{...l,status:"processing",processingPhase:"uploading",processingStartTime:Date.now()}:l)),a.forEach(async c=>{const l=c.id,s=c.generated||c.original;try{const i=await Me(s),{url:u}=await Se(i,void 0,1e3),m=await Ae(e,"upscale",void 0,void 0,void 0,t,n,void 0,D=>{d(v=>v.map(E=>E.id===l?{...E,processingPhase:D}:E))},u),$=await Be(m);d(D=>D.map(v=>v.id===l?{...v,generated:m,status:"done",processingPhase:"done",width:$.width,height:$.height}:v))}catch(i){const u=U(i,o);f(u),d(m=>m.map($=>$.id===l?{...$,status:"error",error:u}:$))}})},T=ke(()=>p.filter(e=>e.selected&&(e.status==="pending"||e.status==="error")).length,[p]),ve=T>0?o("button_change_clothing_batch",{count:String(T)}):o("button_select_to_change_clothing");return h`
        ${C&&C.generated&&h`
            <${De}
                t=${o}
                originalUrl=${C.original}
                generatedUrl=${C.generated}
                onClose=${()=>F(null)}
                caption=${o("detailedComparison")}
                toggleView=${!0}
            />
        `}
        <div class="editor-layout batch-background-view ${ae?"":"panel-hidden"}">
             <div class="image-panel droppable ${te?"drag-over":""}" onDragOver=${e=>k(e,!0)} onDragEnter=${e=>k(e,!0)} onDragLeave=${e=>k(e,!1)} onDrop=${he}>
                <div style=${{width:"100%",display:"flex",flexDirection:"column",height:"100%",padding:"1.5rem"}}>
                    <div class="actions" style=${{position:"relative",bottom:"auto",right:"auto",justifyContent:"space-between",marginBottom:"1rem",flexWrap:"wrap",gap:"0.5rem"}}>
                        <button class="btn" onClick=${()=>{var e;return(e=document.getElementById("batch-clothing-file-input"))==null?void 0:e.click()}}><${q} /> ${o("add_images")}</button>
                        <div style=${{display:"flex",gap:"0.5rem"}}><button class="btn btn-secondary" onClick=${ge}>${o("select_all")}</button><button class="btn btn-secondary" onClick=${pe}>${o("deselect_all")}</button><button class="btn btn-secondary" onClick=${ce} disabled=${p.length===0}>${o("delete_all")}</button></div>
                        <input type="file" id="batch-clothing-file-input" multiple accept="image/*" style=${{display:"none"}} onChange=${ue} />
                        <button
                            type="button"
                            class="btn btn-secondary"
                            onClick=${()=>{const e=p.filter(t=>t.selected);e.length>0?I(e):alert(o("button_select_to_ai_edit"))}}
                            disabled=${p.filter(e=>e.selected).length===0}
                            title=${o("label_upscale")}
                        >
                            <${W} /> ${o("label_upscale")}
                        </button>
                        <button type="button" class="btn btn-primary" onClick=${e=>{e.preventDefault(),e.stopPropagation(),me(e)}} disabled=${G||p.filter(e=>e.selected&&e.generated).length===0}><${Te} /> ${o(G?"zipping":"download_all")}</button>
                    </div>
                    ${L&&h`<div class="progress-container"><div class="progress-bar"><div class="progress-bar-inner" style=${{width:`${S}%`}}></div><span class="progress-label">${S}%</span></div><span class="progress-counter">${Y} / ${ee}</span></div>`}
                    ${B&&h`<div class="error-message" style=${{marginTop:"1rem"}}>${B}</div>`}
                    <div class="batch-grid" style=${{flex:1,overflowY:"auto",alignContent:"flex-start"}}>
                        ${p.length===0?h`
                            <div class="upload-placeholder" onClick=${()=>{var e;return(e=document.getElementById("batch-clothing-file-input"))==null?void 0:e.click()}} style=${{gridColumn:"1 / -1",height:"100%",minHeight:"400px",alignSelf:"stretch"}}>
                                <${q} /><strong>${o("upload_multiple_prompt_title")}</strong><p>${o("upload_clothing_change_prompt")}</p>
                            </div>`:p.map(e=>h`
                            <div class="batch-item ${e.selected?"selected":""} ${e.generated?"has-generated":""} ${e.status==="error"?"error":""}">
                                <div class="selection-checkbox" onClick=${()=>de(e.id)}><div class="checkbox-visual"><${Z} /></div></div>
                                <div class="image-comparator" style=${{display:"block"}} onClick=${()=>e.generated&&F(e)}>
                                    <div class="image-container ${e.generated?"has-result":""}">
                                        <img src=${e.generated||e.original} onMouseEnter=${t=>{e.generated&&(t.target.src=e.original)}} onMouseLeave=${t=>{e.generated&&(t.target.src=e.generated)}} />
                                        ${e.status==="processing"&&h`<${we} startTime=${e.processingStartTime} phase=${e.processingPhase} t=${o} />`}
                                        ${e.status==="done"&&h`<div class="batch-item-status-icon"><${Z} /></div>`}
                                        ${e.status==="error"&&h`<div class="error-badge" title="${e.error||o("error")}" onClick=${t=>{t.stopPropagation(),alert(e.error||o("error"))}}>${o("error")}</div>`}
                                    </div>
                                </div>
                                <div class="batch-item-actions">
                                    <button class="batch-item-btn" title=${o("regenerate")} onClick=${()=>le(e.id)}><${Ee} /></button>
                                    <button class="batch-item-btn" title="Nâng cao chất lượng (Upscale)" onClick=${()=>I([e])}><${W} /></button>
                                    <button class="batch-item-btn" title=${o("delete")} onClick=${()=>ie(e.id)}><${Ue} /></button>
                                </div>
                            </div>`)}
                    </div>
                </div>
            </div>
            <${ye} 
                settings=${w} 
                setSettings=${Q} 
                onGenerate=${re} 
                generating=${L} 
                hasImage=${T>0} 
                buttonText=${ve} 
                isBatch=${!0} 
                onBackToHome=${J} 
                onChooseAnotherImage=${()=>{var e;return(e=document.getElementById("batch-clothing-file-input"))==null?void 0:e.click()}} 
                t=${o} 
                language=${X} 
                setLanguage=${K}
            />
            ${b&&h`
                <${Re}
                    targetImages=${b.map(e=>({id:e.id,url:e.generated||e.original}))}
                    models=${$e}
                    onClose=${()=>I(null)}
                    onConfirm=${be}
                    t=${o}
                />
            `}
        </div>
    `};export{Ne as default};
