import{_ as o}from"./vendor-bdgQI7wY.js";import{h as i}from"./editor-MotionEditor-B8LJN4fm.js";const t=i.bind(o),e=()=>t`
        <div style=${{padding:"20px",color:"#fff"}}>
            <h2>Video Editor</h2>
            <p>Video editing features coming soon...</p>
        </div>
    `;export{e as default};
