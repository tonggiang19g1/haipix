import{d as a,y as g,_ as f}from"./vendor-bdgQI7wY.js";import{ab as y,Q as u,y as $,h}from"./editor-MotionEditor-B8LJN4fm.js";const t=h.bind(f),m=({onBack:r,t:n})=>{const[o,l]=a([]),[d,s]=a(!0),[i,p]=a(null);g(()=>{y().then(e=>{l(e),s(!1)}).catch(e=>{console.error("Failed to load history",e),p(e.message||"Failed to load history"),s(!1)})},[]);const c=e=>new Date(e*1e3).toLocaleString();return t`
        <div class="feature-editor-container" style=${{background:"#111",color:"#fff",padding:"20px",overflowY:"auto"}}>
            <div class="static-title-header" style=${{marginBottom:"20px",display:"flex",alignItems:"center",gap:"15px"}}>
                <button onClick=${r} class="btn btn-secondary" style=${{display:"flex",alignItems:"center",gap:"8px",padding:"8px 16px"}}>
                    <${u} style=${{transform:"rotate(180deg)",width:"20px",height:"20px"}} />
                    <span>${n("back")}</span>
                </button>
                <h1 class="title" style=${{fontSize:"24px",margin:0}}>Lịch sử giao dịch</h1>
            </div>

            ${d?t`<div style=${{textAlign:"center",padding:"40px"}}><${$} t=${n} /></div>`:i?t`<div class="error-message">${i}</div>`:t`
                <div style=${{display:"flex",flexDirection:"column",gap:"10px",maxWidth:"1000px",margin:"0 auto"}}>
                    
                    ${o.length===0?t`<div style=${{textAlign:"center",color:"#888",padding:"40px"}}>Chưa có giao dịch nào.</div>`:o.map((e,x)=>t`
                        <div key=${x} style=${{background:"#1f1f1f",borderRadius:"8px",padding:"15px",border:"1px solid #333",display:"flex",flexDirection:"column",gap:"8px"}}>
                            <div style=${{display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
                                <div style=${{display:"flex",gap:"10px",alignItems:"center"}}>
                                    <span style=${{background:e.fluctuation_type==="minus"?"rgba(239, 68, 68, 0.2)":"rgba(34, 197, 94, 0.2)",color:e.fluctuation_type==="minus"?"#ef4444":"#22c55e",padding:"4px 8px",borderRadius:"4px",fontSize:"12px",fontWeight:"bold",minWidth:"60px",textAlign:"center"}}>
                                        ${e.fluctuation_type==="minus"?"OUT":"IN"}
                                    </span>
                                    <span style=${{fontWeight:"bold",fontSize:"16px",color:"#e5e7eb"}}>
                                        ${e.fluctuation_type==="minus"?"-":"+"}${e.value_change} ${e.currency_name==="credits_ai"?"Credits":e.currency_name}
                                    </span>
                                </div>
                                <span style=${{color:"#6b7280",fontSize:"12px"}}>${c(e.created_time)}</span>
                            </div>

                            <div style=${{color:"#9ca3af",fontSize:"14px",lineHeight:"1.4"}}>
                                ${e.message||"No description"}
                            </div>

                            <div style=${{display:"flex",justifyContent:"space-between",fontSize:"12px",color:"#4b5563",borderTop:"1px solid #333",paddingTop:"8px",marginTop:"4px"}}>
                                <span>Source: ${e.source}</span>
                                <span>Bal: ${e.value_last}</span>
                            </div>
                        </div>
                    `)}
                </div>
            `}
        </div>
    `};export{m as default};
