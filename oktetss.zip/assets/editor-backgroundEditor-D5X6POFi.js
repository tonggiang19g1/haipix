import{P as Cs,a as As,_ as Ts}from"./editor-aiEditor-Dm1L4C_K.js";import{d as h,A as Mt,y as O,T as Ft,q as Zt,_ as Rs}from"./vendor-bdgQI7wY.js";import{k as zs,x as gi,m as ft,U as ui,D as hi,e as Ls,E as Ps,y as Bs,z as Ds,s as Ms,F as te,L as Fs,b as X,G as fi,W as mi,J as bi,K as xi,O as $i,p as Es,n as Ws,Q as js,q as Os,T as Us,h as Ns,X as yi,Y as Hs,Z as vi,u as Vs,v as Gs}from"./editor-MotionEditor-B8LJN4fm.js";import{G as Ks,a as Ys,U as qs,u as Xs,g as Qs}from"./editor-common-ColFbeBm.js";const Js="HaiPixStorage",Zs=1,Ct="app_data",ki=()=>new Promise((lt,G)=>{const j=indexedDB.open(Js,Zs);j.onupgradeneeded=()=>{const H=j.result;H.objectStoreNames.contains(Ct)||H.createObjectStore(Ct)},j.onsuccess=()=>lt(j.result),j.onerror=()=>G(j.error)}),Si=async lt=>{try{const G=await ki();return new Promise((j,H)=>{const dt=G.transaction(Ct,"readonly").objectStore(Ct).get(lt);dt.onsuccess=()=>j(dt.result),dt.onerror=()=>H(dt.error)})}catch(G){return console.error("IndexedDB getItem error:",G),null}},ee=async(lt,G)=>{try{const j=await ki();return new Promise((H,o)=>{const S=j.transaction(Ct,"readwrite").objectStore(Ct).put(G,lt);S.onsuccess=()=>H(),S.onerror=()=>o(S.error)})}catch(j){console.error("IndexedDB setItem error:",j)}},g=Ns.bind(Rs),wi=()=>g`<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='currentColor'><path d='M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z'></path></svg>`,ra=lt=>{var Je,Ze,tn,en,nn,on,sn,an,rn,ln,dn,pn,cn,gn,un,hn,fn,mn,bn,xn,$n,yn,vn,Sn,wn,kn,In,_n,Cn,An,Tn,Rn,zn,Ln,Pn,Bn,Dn,Mn,Fn,En,Wn,jn,On,Un,Nn,Hn,Vn,Gn,Kn,Yn,qn,Xn,Qn,Jn,Zn,to,eo,no,oo,io,so,ao,ro,lo,po,co,go,uo,ho,fo,mo,bo,xo,$o,yo,vo,So,wo,ko,Io,_o,Co,Ao,To,Ro,zo,Lo,Po,Bo,Do,Mo,Fo,Eo,Wo,jo,Oo,Uo,No,Ho,Vo,Go,Ko,Yo,qo,Xo,Qo,Jo,Zo,ti,ei,ni,oi,ii,si,ai,ri,li,di,pi,ci;const{onBackToHome:G,onImageUpdate:j,initialFiles:H,t:o,language:mt,setLanguage:dt}=lt,[S,I]=h([]),[f,N]=h(()=>({prompt:"",shotType:"wide",negativePrompt:o("negative_prompt_default"),useNegativePrompt:!1,referenceImage:null,keepPose:!0,keepComposition:!0,keepFocalLength:!0,keepAspectRatio:!0,lightingEffects:[],numImages:1,lensBlur:6,useLensBlur:!1,aiProvider:"haipix",haipixModel:"google_image_gen_banana_3",haipixMode:"vip1",haipixRatio:"auto",haipixResolution:"5k",customPrompt:"",useRimLight:!1,rimLightDirection:"left",rimLightIntensity:"medium",useGoldenHourBacklight:!1,foregroundAmount:"medium"})),[At,ue]=h(!1),[he,fe]=h(0),[Ii,me]=h(0),[_i,be]=h(0),[xe,y]=h(""),[Ci,$e]=h(!1),[Q,Et]=h(null),ye=Mt(!1),[pt,ve]=h(!0),[bt,Ai]=h(!1),[ta,Ti]=h(!1),[Se,we]=h(!1),[z,L]=h([]),[_,nt]=h([]),[Wt,Ri]=h(!1),[ne,zi]=h(200),[Tt,jt]=h(null),[Li,Pi]=h([]),[J,ke]=h(null),Ot=Mt(null),[Ie,Bi]=h(!1),[ct,_e]=h(null);O(()=>{zs("image").then(Pi).catch(t=>console.error("Models fetch error",t))},[]);const Di=async(t,e,n)=>{if(!Tt||Tt.length===0)return;const s=[...Tt];jt(null),y("");const l=new Set(s.map(r=>r.id));I(r=>r.map(i=>l.has(i.id)?{...i,status:"processing",processingPhase:"uploading",processingStartTime:Date.now()}:i)),s.forEach(async r=>{const i=r.id,a=r.generated||r.original;try{const d=await Xs(a),{url:u}=await Vs(d,void 0,1e3),b=await Gs(t,"upscale",void 0,void 0,void 0,e,n,void 0,w=>{I(k=>k.map(C=>C.id===i?{...C,processingPhase:w}:C))},u),x=await Qs(b);I(w=>w.map(k=>k.id===i?{...k,generated:b,status:"done",processingPhase:"done",width:x.width,height:x.height}:k))}catch(d){const u=ft(d,o);y(u),I(b=>b.map(x=>x.id===i?{...x,status:"error",error:u}:x))}})};O(()=>{(async()=>{try{let e=await Si("hai_pix_concept_album"),n=await Si("hai_pix_concept_folders");const s=r=>{if(!r||typeof r!="object")return r;const{aiProvider:i,haipixModel:a,haipixMode:d,haipixRatio:u,haipixResolution:b,referenceImage:x,detailReferences:w,...k}=r;return k},l=r=>r.map(i=>{const a=i.settings?s(i.settings):void 0;let d=i.shotSettings;return d&&(d={full:d.full?s(d.full):void 0,half:d.half?s(d.half):void 0,closeup:d.closeup?s(d.closeup):void 0,wide:d.wide?s(d.wide):void 0}),{...i,folderId:i.folderId??null,tags:i.tags??[],useCount:i.useCount??0,isFavorite:i.isFavorite??!1,notes:i.notes??"",settings:a,shotSettings:d}});if(e)e=l(e);else{const r=localStorage.getItem("hai_pix_concept_album");r&&(e=l(JSON.parse(r)),await ee("hai_pix_concept_album",e))}if(!n){const r=localStorage.getItem("hai_pix_concept_folders");r&&(n=JSON.parse(r),await ee("hai_pix_concept_folders",n))}e&&L(e),n&&nt(n||[])}catch(e){console.error("Error loading data from IndexedDB:",e)}finally{Ri(!0)}})()},[]);const[M,Ut]=h(null),[Z,Mi]=h(""),[xt,Fi]=h("newest"),[U,Rt]=h(!1),[W,$t]=h([]),[Ei,Nt]=h(!1),[Ht,Ce]=h(""),[Wi,Ae]=h(null),[Te,yt]=h(null),[vt,ji]=h(null),[p,$]=h(null),[m,Vt]=h(null),[K,Gt]=h(null),[Re,Oi]=h(!1),[ze,Le]=h(""),[zt,oe]=h(null),[Pe,ie]=h(null),[gt,se]=h([]),[ut,ae]=h([]),[F,Ui]=h(170),[V,St]=h(null),[Ni,Kt]=h(!1),[ht,re]=h(null),[Lt,Hi]=h(()=>{const t=localStorage.getItem("hai_pix_batch_left_width");return t?parseInt(t,10):280}),[Yt,Vi]=h(()=>{const t=localStorage.getItem("hai_pix_batch_right_width");return t?parseInt(t,10):380}),[ot,Be]=h(!1),[it,De]=h(!1),Me=Mt(Lt),Fe=Mt(Yt);O(()=>{Me.current=Lt},[Lt]),O(()=>{Fe.current=Yt},[Yt]),O(()=>{let t;const e=s=>{ot?(cancelAnimationFrame(t),t=requestAnimationFrame(()=>{const l=Math.max(200,Math.min(window.innerWidth-50,s.clientX));Hi(l)})):it&&(cancelAnimationFrame(t),t=requestAnimationFrame(()=>{const l=Math.max(250,Math.min(window.innerWidth-50,window.innerWidth-s.clientX));Vi(l)}))},n=()=>{ot&&(Be(!1),localStorage.setItem("hai_pix_batch_left_width",Me.current.toString())),it&&(De(!1),localStorage.setItem("hai_pix_batch_right_width",Fe.current.toString()))};return(ot||it)&&(window.addEventListener("mousemove",e),window.addEventListener("mouseup",n),document.body.style.cursor="col-resize",document.body.style.userSelect="none"),()=>{window.removeEventListener("mousemove",e),window.removeEventListener("mouseup",n),t&&cancelAnimationFrame(t),document.body.style.cursor="",document.body.style.userSelect=""}},[ot,it]);const Gi=(t,e,n)=>new Promise(s=>{if(!t||!t.startsWith("data:image")){s(t);return}const l=new Image;l.onload=()=>{const r=document.createElement("canvas");let i=l.width,a=l.height;i>a?i>e&&(a*=e/i,i=e):a>e&&(i*=e/a,a=e),r.width=i,r.height=a;const d=r.getContext("2d");d&&(d.fillStyle="#000000",d.fillRect(0,0,i,a),d.drawImage(l,0,0,i,a)),s(r.toDataURL("image/jpeg",n))},l.onerror=()=>s(t),l.src=t}),P=()=>{se(t=>{const e=[...t,{album:[...z],folders:[..._],images:[...S],settings:{...f}}];return e.length>50&&e.shift(),e}),ae([])},Ee=()=>{if(gt.length===0)return;const t=gt[gt.length-1];ae(e=>[...e,{album:[...z],folders:[..._],images:[...S],settings:{...f}}]),L(t.album),nt(t.folders),I(t.images),N(t.settings),se(e=>e.slice(0,-1))},le=()=>{if(ut.length===0)return;const t=ut[ut.length-1];se(e=>[...e,{album:[...z],folders:[..._],images:[...S],settings:{...f}}]),L(t.album),nt(t.folders),I(t.images),N(t.settings),ae(e=>e.slice(0,-1))};O(()=>{const t=e=>{e.target.tagName==="INPUT"||e.target.tagName==="TEXTAREA"||((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="z"?(e.preventDefault(),e.shiftKey?le():Ee()):(e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="y"&&(e.preventDefault(),le()))};return window.addEventListener("keydown",t),()=>window.removeEventListener("keydown",t)},[gt,ut,z,_,S,f]);const Ki=t=>{$t(e=>e.includes(t)?e.filter(n=>n!==t):[...e,t])},Yi=()=>{W.length&&confirm(o("album_confirm_delete_multi").replace("{count}",W.length.toString()))&&(P(),L(t=>t.filter(e=>!W.includes(e.id))),$t([]),Rt(!1))},We=t=>{W.length&&(P(),L(e=>e.map(n=>W.includes(n.id)?{...n,folderId:t}:n)),$t([]),Rt(!1),yt(null))},Y=Ft(()=>{let t=z;if(!Z.trim())t=t.filter(e=>e.folderId===M);else{const e=Z.toLowerCase().trim();t=t.filter(n=>{var s,l;return((s=n.name)==null?void 0:s.toLowerCase().includes(e))||n.prompt.toLowerCase().includes(e)||((l=n.tags)==null?void 0:l.some(r=>r.toLowerCase().includes(e)))})}return[...t].sort((e,n)=>xt==="favorite"?e.isFavorite===n.isFavorite?n.createdAt-e.createdAt:e.isFavorite?-1:1:xt==="newest"?n.createdAt-e.createdAt:xt==="oldest"?e.createdAt-n.createdAt:xt==="usage"?(n.useCount||0)-(e.useCount||0):0)},[z,M,Z,xt]);O(()=>{Wt&&ee("hai_pix_concept_album",z).catch(t=>{var e;console.error("Error saving concept album to IndexedDB:",t),t&&(t.name==="QuotaExceededError"||(e=t.message)!=null&&e.includes("quota"))&&y("LỖI: Bộ nhớ trình duyệt đã đầy. Bạn CẦN vào Album -> Dọn dẹp hoặc xóa bớt mẫu cũ để tiếp tục lưu.")})},[z,Wt]),O(()=>{Wt&&ee("hai_pix_concept_folders",_).catch(t=>{console.error("Error saving concept folders to IndexedDB:",t)})},[_,Wt]);const qt=Mt(!1);O(()=>{if(qt.current)return;if(localStorage.getItem("hai_pix_thumbnail_migration_v3")==="done"){qt.current=!0;return}if(z.length===0){qt.current=!0;return}(async()=>{console.log("[HaiPix] Starting thumbnail migration to 640px/80%...");let n=0;const s=await Promise.all(z.map(async l=>{if(l.thumbnail&&l.thumbnail.startsWith("data:image"))try{const r=new Image;await new Promise((w,k)=>{r.onload=()=>w(),r.onerror=()=>k(),r.src=l.thumbnail});const i=document.createElement("canvas"),a=720;let d=r.width,u=r.height;if(d<a&&u<a&&l.thumbnail.length<8e4)return l;d>u?d>a&&(u*=a/d,d=a):u>a&&(d*=a/u,u=a),i.width=d,i.height=u;const b=i.getContext("2d");b&&(b.fillStyle="#000000",b.fillRect(0,0,d,u),b.drawImage(r,0,0,d,u));const x=i.toDataURL("image/jpeg",.9);return n++,{...l,thumbnail:x}}catch{return console.warn("[HaiPix] Failed to migrate thumbnail for item:",l.id),l}return l}));n>0&&(console.log(`[HaiPix] Migrated ${n} thumbnails to 720px/90% quality`),L(s)),localStorage.setItem("hai_pix_thumbnail_migration_v3","done"),qt.current=!0})()},[z.length]);const de=async t=>{if(!t)throw new Error("URL is empty");return new Promise((e,n)=>{const s=new Image,l=t.startsWith("http")&&!t.includes("data:")?vi(t):t;t.startsWith("http")&&(s.crossOrigin="anonymous"),s.src=l,s.onload=()=>{try{const r=document.createElement("canvas"),i=720;let a=s.width,d=s.height;a>d?a>i&&(d*=i/a,a=i):d>i&&(a*=i/d,d=i),r.width=a,r.height=d;const u=r.getContext("2d");u&&(u.fillStyle="#000000",u.fillRect(0,0,a,d),u.drawImage(s,0,0,a,d)),e(r.toDataURL("image/jpeg",.9))}catch(r){n(r)}},s.onerror=()=>n(new Error("Failed to load image: "+t.substring(0,50))),setTimeout(()=>n(new Error("Timeout loading thumbnail")),15e3)})},je=()=>{if(!Ht.trim())return;const t={id:Date.now().toString(),name:Ht.trim(),parentId:M,createdAt:Date.now()};nt(e=>[t,...e]),Ce(""),Nt(!1)},qi=()=>{P();const e={id:Date.now().toString(),thumbnail:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=",prompt:"",folderId:M,isFavorite:!1,name:"Mẫu trống mới",createdAt:Date.now(),settings:{...f,prompt:""},shotSettings:{full:{...f,prompt:""},half:{...f,prompt:""},closeup:{...f,prompt:""},wide:{...f,prompt:""}}};L(n=>[e,...n])},Oe=(t,e)=>{nt(n=>n.map(s=>s.id===t?{...s,name:e}:s)),Ae(null)},Xi=t=>{P();const e=l=>{const r=_.filter(a=>a.parentId===l);let i=r.map(a=>a.id);for(const a of r)i=[...i,...e(a.id)];return i},n=[t,...e(t)];L(l=>l.filter(r=>!n.includes(r.folderId||""))),nt(l=>l.filter(r=>!n.includes(r.id)));const s=_.find(l=>l.id===t);M&&n.includes(M)&&Ut((s==null?void 0:s.parentId)??null)},Qi=()=>{confirm(`Bạn có muốn dọn dẹp Album không? 
- Xóa các mẫu lỗi (thuộc thư mục đã bị xóa).
- Xóa các mẫu trùng lặp giữa các thư mục.`)&&(P(),L(t=>{const e=new Set(_.map(i=>i.id)),n=new Set;let s=0,l=0;const r=t.filter(i=>{if(i.folderId!==null&&!e.has(i.folderId))return s++,!1;const a=i.thumbnail.length>2e3?`${i.thumbnail.length}_${i.thumbnail.substring(0,150)}_${i.thumbnail.substring(i.thumbnail.length-150)}`:i.thumbnail,d=`${i.prompt}_${a}`;return n.has(d)?(l++,!1):(n.add(d),!0)});return s>0||l>0?alert(`Dọn dẹp hoàn tất!
- Đã xóa ${s} mẫu "ẩn" (không thấy do thư mục gốc đã bị xóa).
- Đã xóa ${l} mẫu trùng lặp giữa các thư mục.

Tổng cộng đã giải phóng ${s+l} mẫu.`):alert("Album đã sạch sẽ, không có mẫu ẩn hay trùng lặp nào."),r}))},Ji=()=>{confirm(`CẢNH BÁO: Bạn có chắc chắn muốn XÓA SẠCH toàn bộ Album mẫu? 
Thao tác này sẽ xóa mọi thư mục và mẫu ảnh.`)&&confirm("XÁC NHẬN LẦN CUỐI: Toàn bộ dữ liệu Album mẫu sẽ bị mất vĩnh viễn?")&&(P(),L([]),nt([]),Ut(null),$t([]),Rt(!1),alert("Đã xóa sạch toàn bộ Album mẫu."))},pe=(t,e)=>{P(),L(n=>n.map(s=>s.id===t?{...s,folderId:e}:s)),yt(null),oe(null)},ce=async(t,e,n,s,l)=>{var d;const r=e!==void 0?e:f.prompt||"",i=n||f,a=i.shotType||"full";P(),console.log("[HaiPix] Saving to album. Shot:",a,"Target:",s||"new");try{const u=i||f||{},{aiProvider:b,haipixModel:x,haipixMode:w,haipixRatio:k,haipixResolution:C,referenceImage:E,detailReferences:tt,...c}=u;let v={...c};if(s)L(A=>A.map(T=>{if(T.id===s){const B={...T.shotSettings||{}};return B[a]={...v,prompt:r},{...T,shotSettings:B}}return T})),y(o("album_append_success")),setTimeout(()=>y(""),3e3);else{let A="";try{A=await de(t)}catch(B){console.warn("[HaiPix] Thumbnail compression failed, using ultimate fallback:",B),t&&t.startsWith("data:")?A=t:A="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFAAAABQAQMAAAD29XidAAAAA1BMVEX///+nxBvIAAAACklEQVR4AWMYSAAAARAAAn6jX8kAAAAASUVORK5CYII="}const T={id:Date.now().toString(),thumbnail:A,prompt:r,folderId:M,isFavorite:!1,name:l||"",createdAt:Date.now(),settings:{...v,prompt:r},shotSettings:{[a]:{...v,prompt:r}}};L(B=>[T,...B]),y(o("album_save_success")||"Đã lưu mẫu mới"),setTimeout(()=>y(""),3e3)}}catch(u){console.error("Error saving to album:",u);const b=u&&u.message?`: ${u.message}`:"";u&&(u.name==="QuotaExceededError"||(d=u.message)!=null&&d.toLowerCase().includes("quota"))?y("LỖI: Trình duyệt hết bộ nhớ lưu trữ. Bạn CẦN vào Album -> Dọn dẹp mẫu cũ."):y(`Lỗi khi lưu vào album${b} - Hãy thử xóa bớt mẫu cũ hoặc liên hệ hỗ trợ`)}finally{Gt(null),Le("")}},Zi=(t,e)=>{P(),L(n=>n.map(s=>s.id===t?{...s,name:e}:s))},ts=t=>{confirm(o("album_confirm_delete"))&&(P(),L(e=>e.filter(n=>n.id!==t)))},wt=(t,e)=>{const n=z.find(u=>u.id===t);if(!n)return;const s=n.shotSettings||{},l=["full","half","closeup","wide"].filter(u=>{const b=s[u];return b&&b.prompt&&b.prompt.trim()!==""});if(!e&&l.length>1){Vt(n);return}const r=e||(l.length===1?l[0]:f.shotType||"full");ji(t);const i=s[r],a={aiProvider:f.aiProvider,haipixModel:f.haipixModel,haipixMode:f.haipixMode,haipixRatio:f.haipixRatio,haipixResolution:f.haipixResolution},d=(u,b)=>{const x={...u};return b==="half"?(x.useLensBlur===void 0&&(x.useLensBlur=!0),x.lensBlur===void 0&&(x.lensBlur=6)):b==="closeup"&&(x.useLensBlur===void 0&&(x.useLensBlur=!0),x.lensBlur===void 0&&(x.lensBlur=8)),x};i?N({...d(i,r),...a}):n.settings?N({...d(n.settings,r),shotType:r,...a}):N(u=>d({...u,prompt:n.prompt,shotType:r},r)),L(u=>u.map(b=>b.id===t?{...b,useCount:(b.useCount||0)+1}:b)),Vt(null)};O(()=>{if(!vt)return;const t=z.find(s=>s.id===vt);if(!t||!t.shotSettings)return;const e=f.shotType||"full",n=t.shotSettings[e];if(n&&(n.prompt!==f.prompt||n.shotType!==f.shotType)){const s=(l,r)=>{const i={...l};return r==="half"?(i.useLensBlur===void 0&&(i.useLensBlur=!0),i.lensBlur===void 0&&(i.lensBlur=6)):r==="closeup"&&(i.useLensBlur===void 0&&(i.useLensBlur=!0),i.lensBlur===void 0&&(i.lensBlur=8)),i};N(l=>({...l,...s(n,e),aiProvider:l.aiProvider,haipixModel:l.haipixModel,haipixMode:l.haipixMode,haipixRatio:l.haipixRatio,haipixResolution:l.haipixResolution}))}},[f.shotType]);const Ue=Ft(()=>_.filter(t=>t.parentId===M),[_,M]),Ne=Ft(()=>{var t;return M===null?null:((t=_.find(e=>e.id===M))==null?void 0:t.name)??null},[_,M]),es=Ft(()=>{var t;return M===null?null:((t=_.find(e=>e.id===M))==null?void 0:t.parentId)??null},[_,M]),He=async t=>{let e=z,n=_;if(Array.isArray(t)&&t.length>0){e=z.filter(i=>t.includes(i.id));const r=new Set(e.map(i=>i.folderId).filter(i=>i!==null));n=_.filter(i=>r.has(i.id))}let s=`concept_album_${new Date().toISOString().slice(0,10)}_haipix.json`;Array.isArray(t)&&t.length>0?t.length===1?s=`${(e[0].name||"untitled").replace(/[/\\?%*:|"<>]/g,"-").trim()}_haipix.json`:s=`concept_album_selection_${t.length}_items_${new Date().toISOString().slice(0,10)}_haipix.json`:s=`concept_album_full_backup_${new Date().toISOString().slice(0,10)}_haipix.json`;const l=JSON.stringify({folders:n,items:e,version:"2.0"},null,2);try{if(window.showSaveFilePicker){const i=await(await window.showSaveFilePicker({suggestedName:s,types:[{description:"JSON Files",accept:{"application/json":[".json"]}}]})).createWritable();await i.write(l),await i.close()}else throw new Error("File System Access API not supported")}catch(r){if(r.name!=="AbortError"){const i=new Blob([l],{type:"application/json"}),a=URL.createObjectURL(i),d=document.createElement("a");d.href=a,d.download=s,d.click(),URL.revokeObjectURL(a)}}},ns=async t=>{const e=t.currentTarget.files;if(!e||e.length===0)return;Ot.current=null;let n=0,s=0,l=0,r=0;for(let i=0;i<e.length;i++){const a=e[i];if(!a.name.endsWith(".json"))continue;const d=await os(a,i+1,e.length);d&&(n+=d.foldersAdded,s+=d.itemsAdded,l+=d.itemsUpdated,r+=d.skippedCount)}_e({filesCount:e.length,foldersAdded:n,itemsAdded:s,itemsUpdated:l,itemsSkipped:r}),t.currentTarget.value=""},os=async(t,e,n)=>new Promise(s=>{const l=new FileReader;l.onload=async r=>{var i;try{y(`Đang đọc tệp ${e}/${n}: ${t.name}...`);const a=JSON.parse((i=r.target)==null?void 0:i.result);P();let d=[],u=[];Array.isArray(a)?d=a.map(c=>({...c,folderId:c.folderId??null})):a.items&&Array.isArray(a.items)&&(d=a.items.map(c=>({...c,folderId:c.folderId??null})),a.folders&&Array.isArray(a.folders)&&(u=a.folders));const b=async c=>{const v={...c};v.thumbnail&&(v.thumbnail.length>2e5||v.thumbnail.length<5e3)&&(v.thumbnail=await Gi(v.thumbnail,720,.9));const A=async T=>{if(!T)return T;const{aiProvider:B,haipixModel:D,haipixMode:R,haipixRatio:et,haipixResolution:_t,referenceImage:ea,detailReferences:na,..._s}=T;return{..._s}};if(v.settings=await A(v.settings),v.shotSettings){const T={};for(const B of Object.keys(v.shotSettings))T[B]=await A(v.shotSettings[B]);v.shotSettings=T}return v};y("Đang kiểm tra thư mục trùng lặp...");const x={},w=[];for(const c of u){const v=_.find(A=>A.name.toLowerCase()===c.name.toLowerCase());if(v)if(confirm(`Thư mục "${c.name}" đã tồn tại.

Bạn có muốn nhập các mẫu vào thư mục hiện có không?

[OK] = Gộp vào thư mục "${c.name}"
[Cancel] = Tạo thư mục mới với tên khác`))x[c.id]=v.id;else{const T=Date.now().toString()+"_"+c.id,B=c.name+" (nhập "+new Date().toLocaleDateString("vi-VN")+")";x[c.id]=T,w.push({...c,id:T,name:B})}else{const A=Date.now().toString()+"_"+c.id;x[c.id]=A,w.push({...c,id:A})}}w.forEach(c=>{c.parentId&&x[c.parentId]&&(c.parentId=x[c.parentId])}),y("Đang kiểm tra mẫu ảnh trùng lặp...");const k=[],C={};let E=0;for(const c of d){let v=null;c.folderId&&(x[c.folderId]?v=x[c.folderId]:_.find(R=>R.id===c.folderId)&&(v=c.folderId));const A=z.find(D=>{if(D.prompt!==c.prompt||D.thumbnail.length!==c.thumbnail.length)return!1;const R=D.thumbnail.substring(0,200)===c.thumbnail.substring(0,200),et=D.thumbnail.substring(D.thumbnail.length-200)===c.thumbnail.substring(c.thumbnail.length-200);return R&&et}),T=c.name?z.find(D=>D.name&&c.name&&D.name.toLowerCase()===c.name.toLowerCase()):null,B=A||T;if(B){let D=Ot.current||"skip";if(!Ot.current){let R="Gốc (Trang chính)";if(B.folderId){const et=_.find(_t=>_t.id===B.folderId);R=et?`Thư mục "${et.name}"`:"Thư mục không xác định"}D=await new Promise(et=>{ke({item:c,existingLocation:R,resolve:_t=>{_t.applyAll&&(Ot.current=_t.mode),et(_t.mode)}})}),ke(null)}if(D==="overwrite"){const R=await b(c);C[B.id]={thumbnail:R.thumbnail,prompt:R.prompt,tags:R.tags,notes:R.notes,folderId:v,settings:R.settings,shotSettings:R.shotSettings}}else if(D==="rename"){const R=await b(c),et=Date.now().toString()+"_"+Math.random().toString(36).substr(2,9);k.push({...R,id:et,name:R.name?`${R.name} (Copy)`:void 0,folderId:v,createdAt:R.createdAt||Date.now()})}else E++}else{const D=await b(c),R=Date.now().toString()+"_"+Math.random().toString(36).substr(2,9);k.push({...D,id:R,folderId:v,createdAt:D.createdAt||Date.now()})}}w.length>0&&nt(c=>[...w,...c]),(Object.keys(C).length>0||k.length>0)&&L(c=>{let v=c.map(A=>{const T=C[A.id];return T?{...A,...T}:A});return[...k,...v]}),y("");const tt={foldersAdded:w.length,itemsAdded:k.length,itemsUpdated:Object.keys(C).length,skippedCount:E};s(tt)}catch(a){console.error("Error importing album:",a),y(`Lỗi khi nhập file album: ${t.name}`),s(null)}},l.readAsText(t)}),[is,Pt]=h(!1),[Ve,kt]=h(null),[st,Ge]=h(null),[ss,at]=h(!1),[Xt,Bt]=h(null),[as,Dt]=h(!1),[rt,q]=h(null),[rs,It]=h(!1),[Ke,Ye]=h("");O(()=>{const t=e=>{if(e.key==="*"){const n=e.target;["INPUT","TEXTAREA","SELECT"].includes(n.tagName)||(e.preventDefault(),ve(s=>!s))}};return window.addEventListener("keydown",t),()=>window.removeEventListener("keydown",t)},[]);const Qt=Zt(t=>{if(!t)return;const e=Array.from(t).filter(s=>s.type.startsWith("image/"));if(e.length===0)return;e.length>0&&!document.fullscreenElement&&document.documentElement.requestFullscreen().catch(s=>{console.warn(`Could not enter fullscreen mode: ${s.message}`)});const n=e.map(s=>({id:Date.now()+Math.random(),file:s,original:URL.createObjectURL(s),generated:null,status:"pending",selected:!0}));I(s=>[...s,...n])},[]);O(()=>{H&&H.length>0&&!ye.current&&(Qt(H),ye.current=!0)},[H,Qt]),O(()=>{const t=async e=>{var r;const n=e.target;if(["INPUT","TEXTAREA","SELECT"].includes(n.tagName))return;const s=(r=e.clipboardData)==null?void 0:r.items;if(!s)return;const l=[];for(let i=0;i<s.length;i++){const a=s[i];if(a.type.startsWith("image/")){const d=a.getAsFile();d&&l.push(d)}}if(l.length>0){e.preventDefault();const i=l.map(a=>({id:Date.now()+Math.random(),file:a,original:URL.createObjectURL(a),generated:null,status:"pending",selected:!0}));I(a=>[...a,...i])}};return document.addEventListener("paste",t),()=>window.removeEventListener("paste",t)},[]);const ls=Zt(t=>{if(!st){y(o("error_no_subject_for_ref"));return}re(null);const e=new FileReader;e.onload=n=>{kt(n.target.result),Pt(!0)},e.readAsDataURL(t)},[st,o]),ds=Zt((t,e=-1)=>{if(!st){y(o("error_no_subject_for_ref"));return}const n=new FileReader;n.onload=s=>{kt(s.target.result),re(e),Pt(!0)},n.readAsDataURL(t)},[st,o]);O(()=>{if(S.length>0&&!st){const t=new Image;t.onload=()=>{Ge(t.naturalWidth/t.naturalHeight)},t.src=S[0].original}S.length===0&&Ge(null)},[S]);const ps=t=>{if(ht!==null){N(e=>{const n=[...e.detailReferences||[]];return ht===-1?n.push({id:Date.now().toString(),url:t,note:""}):ht>=0&&(n[ht].url=t),{...e,detailReferences:n}}),Pt(!1),kt(null),re(null);return}q(t),Pt(!1),kt(null),Dt(!0)},cs=async()=>{if(rt){Dt(!1),at(!0),y("");try{const t=await te(rt,768,.6),e=await Hs(t,mt);Bt({prompt:e.fullShotPrompt,image:t}),q(null)}catch(t){const e=ft(t,o);e.includes("429")||/rate limit|quota|limit/i.test(e)?It(!0):(y(e),q(null))}finally{at(!1)}}},gs=async()=>{if(rt){Dt(!1),at(!0),y("");try{const t=await te(rt,1024,.8),e=await yi(t,mt);Bt({prompt:e.fullShotPrompt,image:t}),q(null)}catch(t){const e=ft(t,o);e.includes("429")||/rate limit|quota|limit/i.test(e)?It(!0):(y(e),q(null))}finally{at(!1)}}},us=async()=>{if(rt){Dt(!1),at(!0),y("");try{const t=await te(rt,1024,.8),e=await yi(t,mt,Ke);Bt({prompt:e.fullShotPrompt,image:t}),q(null),Ye("")}catch(t){const e=ft(t,o);e.includes("429")||/rate limit|quota|limit/i.test(e)?It(!0):(y(e),q(null))}finally{at(!1)}}},hs=()=>{Pt(!1),kt(null)},fs=t=>I(e=>e.map(n=>n.id===t?{...n,selected:!n.selected}:n)),ms=()=>I(t=>t.map(e=>({...e,selected:!0}))),bs=()=>I(t=>t.map(e=>({...e,selected:!1}))),xs=t=>{P(),Qt(t.currentTarget.files),t.currentTarget&&(t.currentTarget.value="")},ge=(t,e)=>{if(t.preventDefault(),t.stopPropagation(),zt){t.dataTransfer&&(t.dataTransfer.dropEffect="none");return}$e(e)},$s=t=>{var e;t.preventDefault(),t.stopPropagation(),$e(!1),!zt&&(P(),Qt(((e=t.dataTransfer)==null?void 0:e.files)||null))},qe=t=>new Promise((e,n)=>{const s=new FileReader;s.onload=()=>e(s.result),s.onerror=()=>n(new Error(`Lỗi đọc file: ${t.name}`)),s.readAsDataURL(t)}),ys=async(t,e,n)=>{let s=0;be(t.length),me(0);const l=[...t],r=async()=>{for(;l.length>0;){const i=l.shift();i&&(await n(i),s++,me(a=>a+1),fe(Math.round(s/t.length*100)),l.length>0&&await new Promise(a=>setTimeout(a,2e3)))}};await Promise.all(Array(e).fill(null).map(()=>r()))},Xe=Zt(async()=>{ue(!0),fe(0),y("");const t=S.filter(n=>n.selected&&(n.status==="pending"||n.status==="error"));be(t.length),t.length>0&&P();const e=async n=>{const s=Date.now();let l=null;const r=54e4;I(i=>i.map(a=>a.id===n.id?{...a,status:"processing",processingStartTime:s,processingProgress:0,processingPhase:"uploading"}:a)),l=setInterval(()=>{const i=Date.now()-s,a=Math.min(i/r*99,99);I(d=>d.map(u=>u.id===n.id?{...u,processingProgress:a}:u))},100);try{const i=await qe(n.file);let a=f.prompt;f.customPrompt&&f.customPrompt.trim()&&(a=`${a} ${f.customPrompt.trim()}`),f.useGoldenHourBacklight&&(a=`${a}, Nắng vàng chiếu hậu cảnh tạo bóng đổ nghệ thuật ánh sáng cứng`);let d;const b=["f/16","f/11","f/8","f/5.6","f/4","f/3.5","f/2.8","f/2.0","f/1.8","f/1.4","f/1.2"][f.lensBlur]||"f/2.0",x=f.useLensBlur?` với độ mở ống kính ${b}`:"";f.shotType==="half"?d=`${o("bg_prompt_prefix")} ${o("bg_shot_half_instruction",{prompt:a,aperture:x})}`:f.shotType==="closeup"?d=`${o("bg_prompt_prefix")} ${o("bg_shot_closeup_instruction",{prompt:a,aperture:x})}`:f.shotType==="wide"?d=`${o("bg_prompt_prefix")} ${o("bg_shot_wide_instruction",{prompt:a})}`:d=`${o("bg_prompt_prefix")}${a}`;const w={...f,prompt:d};delete w.numImages,delete w.customPrompt;const k=await gi(i,w,C=>{I(E=>E.map(tt=>tt.id===n.id?{...tt,processingPhase:C}:tt))});I(C=>C.map(E=>E.id===n.id?{...E,generated:k,status:"done",settings:{...f},processingProgress:100,processingPhase:void 0}:E))}catch(i){throw y(ft(i,o)),console.error(`Error processing image ${n.id}:`,i),I(a=>a.map(d=>d.id===n.id?{...d,status:"error",processingProgress:void 0,processingPhase:void 0}:d)),i}finally{l&&clearInterval(l)}};try{await ys(t,1,e)}catch(n){console.error(o("batch_processing_stopped"),n)}finally{ue(!1)}},[S,f,o]),vs=async t=>{const e=S.find(r=>r.id===t);if(!e)return;const n=Date.now();let s=null;const l=54e4;P(),y(""),I(r=>r.map(i=>i.id===t?{...i,status:"processing",processingStartTime:n,processingProgress:0,processingPhase:"uploading"}:i)),s=setInterval(()=>{const r=Date.now()-n,i=Math.min(r/l*99,99);I(a=>a.map(d=>d.id===t?{...d,processingProgress:i}:d))},100);try{const r=await qe(e.file);let i=f.prompt;f.customPrompt&&f.customPrompt.trim()&&(i=`${i} ${f.customPrompt.trim()}`),f.useGoldenHourBacklight&&(i=`${i}, Nắng vàng chiếu hậu cảnh tạo bóng đổ nghệ thuật ánh sáng cứng`);let a;const u=["f/16","f/11","f/8","f/5.6","f/4","f/3.5","f/2.8","f/2.0","f/1.8","f/1.4","f/1.2"][f.lensBlur]||"f/2.0",b=f.useLensBlur?` với độ mở ống kính ${u}`:"";f.shotType==="half"?a=`${o("bg_prompt_prefix")} ${o("bg_shot_half_instruction",{prompt:i,aperture:b})}`:f.shotType==="closeup"?a=`${o("bg_prompt_prefix")} ${o("bg_shot_closeup_instruction",{prompt:i,aperture:b})}`:f.shotType==="wide"?a=`${o("bg_prompt_prefix")} ${o("bg_shot_wide_instruction",{prompt:i})}`:a=`${o("bg_prompt_prefix")}${i}`;const x={...f,prompt:a};delete x.numImages,delete x.customPrompt;const w=await gi(r,x,k=>{I(C=>C.map(E=>E.id===t?{...E,processingPhase:k}:E))});I(k=>k.map(C=>C.id===t?{...C,generated:w,status:"done",settings:{...f},processingProgress:100,processingPhase:void 0}:C))}catch(r){y(ft(r,o)),I(i=>i.map(a=>a.id===t?{...a,status:"error",processingProgress:void 0,processingPhase:void 0}:a))}finally{s&&clearInterval(s)}},Ss=t=>{P(),I(e=>e.filter(n=>n.id!==t))},ws=async()=>{const t=S.filter(l=>l.generated&&l.selected);if(t.length===0)return;const e=9,n=1e3,s=async(l,r=1)=>{try{const i=await fetch(vi(l));if(!i.ok)throw new Error(`HTTP ${i.status}`);return await i.blob()}catch(i){if(r<e)return console.log(`Fetch failed, retrying (${r}/${e})...`),await new Promise(a=>setTimeout(a,n*r)),s(l,r+1);throw i}};we(!0);try{const{default:l}=await Ts(async()=>{const{default:b}=await import("https://cdn.jsdelivr.net/npm/jszip@3.10.1/+esm");return{default:b}},[]),r=new l;let i=0,a=1;for(const b of t)if(b.generated)try{const x=await s(b.generated),w=`${a.toString().padStart(3,"0")}_${b.file.name.split(".")[0]}_background.png`;r.file(w,x),i++,a++}catch(x){console.error("Error fetching image for zip:",x)}if(i===0)throw new Error("Không thể tải được ảnh nào do lỗi kết nối hoặc CORS.");const d=await r.generateAsync({type:"blob"}),u=document.createElement("a");u.href=URL.createObjectURL(d),u.download=`backgrounds_${Date.now()}.zip`,u.click(),URL.revokeObjectURL(u.href)}catch(l){console.error("Error creating zip:",l),y("Lỗi khi tải xuống: "+l.message+`

Giải pháp: Bấm vào từng ảnh để xem to rồi chuột phải chọn "Lưu hình ảnh thành..."`)}finally{we(!1)}},Jt=Ft(()=>S.filter(t=>t.selected&&(t.status==="pending"||t.status==="error")).length,[S]),Qe=Jt>0?o("button_change_bg_batch",{count:String(Jt)}):o("button_select_to_change_bg"),ks=[{label:o("subject_aspect_ratio"),value:st??1},{label:"16:9",value:16/9},{label:"4:3",value:4/3},{label:"3:2",value:3/2},{label:"1:1",value:1},{label:"3:4",value:3/4},{label:"2:3",value:2/3},{label:"9:16",value:9/16}],Is=[{label:"Tự do",value:0},{label:o("subject_aspect_ratio"),value:st??1},{label:"16:9",value:16/9},{label:"4:3",value:4/3},{label:"3:2",value:3/2},{label:"1:1",value:1},{label:"3:4",value:3/4},{label:"2:3",value:2/3},{label:"9:16",value:9/16}];return g`
        ${xe&&g`<${Ps} message=${xe} onClose=${()=>y("")} />`}
        ${ss&&g`<${Bs} text="Đang phân tích ảnh tham chiếu..." t=${o} />`}
        ${Xt&&g`
            <${Ds}
                message=${o("toast_analysis_complete")}
                actions=${[{label:o("toast_action_no"),isPrimary:!0,note:o("toast_action_no_note"),onClick:()=>{N(t=>({...t,prompt:Xt.prompt,customPrompt:o("label_foreground_auto"),referenceImage:null})),Bt(null)}},{label:o("toast_action_yes"),note:g`<div>${o("toast_action_yes_note")}</div>`,onClick:()=>{N(t=>({...t,prompt:Xt.prompt,customPrompt:o("label_foreground_auto"),referenceImage:Xt.image})),Bt(null)}}]}
            />
        `}
        ${is&&Ve&&(st||ht!==null)&&g`
            <${Ms} 
                t=${o}
                imageUrl=${Ve} 
                onCrop=${ps}
                onCancel=${hs}
                aspectRatios=${ht!==null?Is:ks}
                warning=${ht!==null?`1. crop cận nguyên vật thể cần tham chiếu
2. phông nền tham chiếu cần xóa người trước khi sử dụng
3. nếu sử dụng quá nhiều tham chiếu có thể gây biến dị cho người mẫu
Chú ý: 1 công cụ sáng tạo mới đa nhiệp vụ hãy cùng sáng tạo tùy biến`:""}
            />
        `}
        ${as&&g`
            <div style=${{position:"fixed",top:0,left:0,right:0,bottom:0,background:"rgba(0,0,0,0.8)",zIndex:2e3,display:"flex",alignItems:"center",justifyContent:"center"}}>
                <div style=${{background:"#1f1f1f",padding:"24px",borderRadius:"12px",width:"500px",maxWidth:"90%",border:"1px solid #333"}}>
                    <h3 style=${{marginTop:0,marginBottom:"20px",fontSize:"18px",color:"white",textAlign:"center"}}>${o("bg_analysis_mode_title")}</h3>
                    
                    <div style=${{marginBottom:"24px",display:"flex",flexDirection:"column",gap:"20px"}}>
                        <!-- Option 1: Detailed (NOW REACTIVATED) - MOVED TO TOP -->
                        <div style=${{padding:"20px",background:"#252525",border:"1px solid #ff4d4f",borderRadius:"12px",boxShadow:"0 0 10px rgba(255, 77, 79, 0.1)"}}>
                            <div style=${{display:"flex",alignItems:"center",marginBottom:"8px"}}>
                                <div style=${{padding:"4px 8px",background:"#ff4d4f",borderRadius:"4px",fontSize:"10px",fontWeight:"bold",color:"white",marginRight:"8px"}}>MỚI</div>
                                <div style=${{fontWeight:"bold",color:"white",fontSize:"16px"}}>${o("bg_mode_detailed")}</div>
                            </div>
                            <div style=${{fontSize:"13px",color:"#ccc",lineHeight:"1.4",marginBottom:"12px"}}>
                                cảnh vẽ lại độ giống cao nhưng quá nhiều chi tiết có thể làm thay đổi bố cục hãy thử xóa bớt các nội dung bên ngoài khung hình ví dụ: (ảnh gốc "bán thân" xóa mô tả dưới chân, nền cỏ.. - trên cao mái nhà ... ) với ảnh gốc "cận cảnh" xóa gần như toàn bộ nội dung prompt chỉ để lại vài mảng khối ví dụ tường màu gì ...)
                            </div>
                            <button class="btn btn-primary" style=${{width:"100%",background:"#ff4d4f",borderColor:"#ff4d4f",padding:"12px",fontSize:"15px"}} onClick=${gs}>
                                Phân tích chi tiết (Gợi ý)
                            </button>
                        </div>

                        <!-- Option 1.5: Advanced Detailed (New) -->
                        <div style=${{padding:"20px",background:"#252525",border:"1px solid #00d1b2",borderRadius:"12px",boxShadow:"0 0 10px rgba(0, 209, 178, 0.1)"}}>
                            <div style=${{display:"flex",alignItems:"center",marginBottom:"8px"}}>
                                <div style=${{padding:"4px 8px",background:"#00d1b2",borderRadius:"4px",fontSize:"10px",fontWeight:"bold",color:"white",marginRight:"8px"}}>✨ VIP</div>
                                <div style=${{fontWeight:"bold",color:"white",fontSize:"16px"}}>Mô tả chi tiết nâng cao</div>
                            </div>
                            <div style=${{fontSize:"13px",color:"#ccc",lineHeight:"1.4",marginBottom:"12px"}}>
                                Phân tích giống "Mô tả chi tiết" nhưng cho phép bạn thêm yêu cầu cá nhân (ví dụ: mô tả rõ hơn về bầu trời, đổi màu vật thể cụ thể...)
                            </div>
                            <textarea 
                                style=${{width:"100%",background:"#111",border:"1px solid #444",borderRadius:"8px",color:"#fff",padding:"10px",fontSize:"13px",minHeight:"60px",marginBottom:"12px",outline:"none",resize:"vertical"}}
                                placeholder="Nhập thêm yêu cầu của bạn tại đây... (Ví dụ: Chú ý mô tả kỹ chiếc xe màu đỏ và thay đổi nền thành buổi chiều hoàng hôn)"
                                value=${Ke}
                                onInput=${t=>Ye(t.currentTarget.value)}
                            ></textarea>
                            <button class="btn btn-primary" style=${{width:"100%",background:"#00d1b2",borderColor:"#00d1b2",padding:"12px",fontSize:"15px"}} onClick=${us}>
                                Phân tích chi tiết nâng cao
                            </button>
                        </div>

                        <!-- Option 2: Concise (Recommended) - MOVED DOWN -->
                        <div style=${{padding:"20px",background:"rgba(64, 169, 255, 0.05)",border:"1px solid #1890ff",borderRadius:"12px"}}>
                            <div style=${{display:"flex",alignItems:"center",marginBottom:"8px"}}>
                                <div style=${{fontWeight:"bold",color:"white",fontSize:"16px"}}>${o("bg_mode_concise")}</div>
                            </div>
                            <button class="btn btn-primary" style=${{width:"100%",marginTop:"16px",padding:"12px",fontSize:"15px"}} onClick=${cs}>
                                Phân tích ngắn gọn
                            </button>
                        </div>
                    </div>
                    
                    <div style=${{display:"flex",justifyContent:"center"}}>
                        <button class="btn btn-secondary" onClick=${()=>{Dt(!1),kt(null)}}>${o("cancel")}</button>
                    </div>
                </div>
            </div>
        `}
        ${m&&g`
            <div style=${{position:"fixed",top:0,left:0,right:0,bottom:0,background:"rgba(0,0,0,0.85)",zIndex:1e4,display:"flex",alignItems:"center",justifyContent:"center"}} onClick=${()=>Vt(null)}>
                <div style=${{background:"#1f1f1f",padding:"24px",borderRadius:"16px",width:"400px",maxWidth:"90%",border:"1px solid #333",boxShadow:"0 10px 30px rgba(0,0,0,0.5)"}} onClick=${t=>t.stopPropagation()}>
                    <h3 style=${{marginTop:0,marginBottom:"12px",fontSize:"20px",color:"white",textAlign:"center"}}>Chọn góc chụp sử dụng</h3>
                    <p style=${{color:"#888",fontSize:"14px",textAlign:"center",marginBottom:"24px",lineHeight:"1.4"}}>Mẫu này có dữ liệu cho nhiều góc chụp.<br/>Vui lòng chọn một để kích hoạt:</p>
                    
                    <div style=${{display:"flex",flexDirection:"column",gap:"12px"}}>
                        <button 
                            class="btn btn-primary" 
                            style=${{background:(Ze=(Je=m.shotSettings)==null?void 0:Je.wide)!=null&&Ze.prompt&&m.shotSettings.wide.prompt.trim()!==""?"linear-gradient(45deg, #00d1b2, #00b89c)":"#252525",border:"none",opacity:(en=(tn=m.shotSettings)==null?void 0:tn.wide)!=null&&en.prompt&&m.shotSettings.wide.prompt.trim()!==""?1:.4,padding:"14px",fontSize:"15px",fontWeight:"bold",color:(on=(nn=m.shotSettings)==null?void 0:nn.wide)!=null&&on.prompt&&m.shotSettings.wide.prompt.trim()!==""?"#fff":"#666",borderRadius:"10px",boxShadow:(an=(sn=m.shotSettings)==null?void 0:sn.wide)!=null&&an.prompt&&m.shotSettings.wide.prompt.trim()!==""?"0 4px 10px rgba(0, 209, 178, 0.2)":"none"}} 
                            disabled=${!((ln=(rn=m.shotSettings)==null?void 0:rn.wide)!=null&&ln.prompt&&m.shotSettings.wide.prompt.trim()!=="")} 
                            onClick=${()=>wt(m.id,"wide")}
                        >
                            Góc chụp: Cảnh rộng
                        </button>
                        <button 
                            class="btn btn-primary" 
                            style=${{background:(pn=(dn=m.shotSettings)==null?void 0:dn.full)!=null&&pn.prompt&&m.shotSettings.full.prompt.trim()!==""?"linear-gradient(45deg, #00d1b2, #00b89c)":"#252525",border:"none",opacity:(gn=(cn=m.shotSettings)==null?void 0:cn.full)!=null&&gn.prompt&&m.shotSettings.full.prompt.trim()!==""?1:.4,padding:"14px",fontSize:"15px",fontWeight:"bold",color:(hn=(un=m.shotSettings)==null?void 0:un.full)!=null&&hn.prompt&&m.shotSettings.full.prompt.trim()!==""?"#fff":"#666",borderRadius:"10px",boxShadow:(mn=(fn=m.shotSettings)==null?void 0:fn.full)!=null&&mn.prompt&&m.shotSettings.full.prompt.trim()!==""?"0 4px 10px rgba(0, 209, 178, 0.2)":"none"}} 
                            disabled=${!((xn=(bn=m.shotSettings)==null?void 0:bn.full)!=null&&xn.prompt&&m.shotSettings.full.prompt.trim()!=="")} 
                            onClick=${()=>wt(m.id,"full")}
                        >
                            Góc chụp: Toàn thân
                        </button>
                        <button 
                            class="btn btn-primary" 
                            style=${{background:(yn=($n=m.shotSettings)==null?void 0:$n.half)!=null&&yn.prompt&&m.shotSettings.half.prompt.trim()!==""?"linear-gradient(45deg, #00d1b2, #00b89c)":"#252525",border:"none",opacity:(Sn=(vn=m.shotSettings)==null?void 0:vn.half)!=null&&Sn.prompt&&m.shotSettings.half.prompt.trim()!==""?1:.4,padding:"14px",fontSize:"15px",fontWeight:"bold",color:(kn=(wn=m.shotSettings)==null?void 0:wn.half)!=null&&kn.prompt&&m.shotSettings.half.prompt.trim()!==""?"#fff":"#666",borderRadius:"10px",boxShadow:(_n=(In=m.shotSettings)==null?void 0:In.half)!=null&&_n.prompt&&m.shotSettings.half.prompt.trim()!==""?"0 4px 10px rgba(0, 209, 178, 0.2)":"none"}} 
                            disabled=${!((An=(Cn=m.shotSettings)==null?void 0:Cn.half)!=null&&An.prompt&&m.shotSettings.half.prompt.trim()!=="")} 
                            onClick=${()=>wt(m.id,"half")}
                        >
                            Góc chụp: Bán thân
                        </button>
                        <button 
                            class="btn btn-primary" 
                            style=${{background:(Rn=(Tn=m.shotSettings)==null?void 0:Tn.closeup)!=null&&Rn.prompt&&m.shotSettings.closeup.prompt.trim()!==""?"linear-gradient(45deg, #00d1b2, #00b89c)":"#252525",border:"none",opacity:(Ln=(zn=m.shotSettings)==null?void 0:zn.closeup)!=null&&Ln.prompt&&m.shotSettings.closeup.prompt.trim()!==""?1:.4,padding:"14px",fontSize:"15px",fontWeight:"bold",color:(Bn=(Pn=m.shotSettings)==null?void 0:Pn.closeup)!=null&&Bn.prompt&&m.shotSettings.closeup.prompt.trim()!==""?"#fff":"#666",borderRadius:"10px",boxShadow:(Mn=(Dn=m.shotSettings)==null?void 0:Dn.closeup)!=null&&Mn.prompt&&m.shotSettings.closeup.prompt.trim()!==""?"0 4px 10px rgba(0, 209, 178, 0.2)":"none"}} 
                            disabled=${!((En=(Fn=m.shotSettings)==null?void 0:Fn.closeup)!=null&&En.prompt&&m.shotSettings.closeup.prompt.trim()!=="")} 
                            onClick=${()=>wt(m.id,"closeup")}
                        >
                            Góc chụp: Cận cảnh
                        </button>
                    </div>
                    
                    <div style=${{display:"flex",justifyContent:"center",marginTop:"24px"}}>
                        <button class="btn btn-secondary" onClick=${()=>Vt(null)} style=${{padding:"8px 24px",borderRadius:"8px"}}>${o("cancel")}</button>
                    </div>
                </div>
            </div>
        `}
        ${rs&&rt&&g`
            <div style=${{position:"fixed",top:0,left:0,right:0,bottom:0,background:"rgba(0,0,0,0.8)",zIndex:2e3,display:"flex",alignItems:"center",justifyContent:"center"}}>
                <div style=${{background:"#1f1f1f",padding:"24px",borderRadius:"12px",width:"600px",maxWidth:"95%",border:"1px solid #333",color:"white"}}>
                    <h2 style=${{marginTop:0,marginBottom:"24px",fontSize:"22px",textAlign:"left",fontWeight:"400"}}>
                        Chú ý hết lượt phân tích miễn phí.<br/>bạn có giữ ảnh này làm ảnh tham chiếu không ?
                    </h2>

                    <div style=${{display:"flex",flexDirection:"column",gap:"20px"}}>
                        <!-- Option 1: ChatGPT Guide (Replaces "Dùng mô tả") -->
                        <div style=${{padding:"20px",background:"#252525",border:"1px solid #333",borderRadius:"12px"}}>
                            <div class="btn btn-primary" style=${{display:"block",padding:"12px 20px",background:"#1890ff",color:"white",borderRadius:"16px",textAlign:"left",textDecoration:"none",fontWeight:"400",fontSize:"18px",marginBottom:"16px",width:"fit-content",opacity:0.7,cursor:"default"}} >
                                dùng chat gpt phân tích nền
                            </div>
                            <div style=${{fontSize:"15px",color:"#ff4d4f",lineHeight:"1.6"}}>
                                <div>Ảnh kết quả có phông nền giống từ 60% - 90%.</div>
                                <div>Sự hòa hợp giữa cảnh và người đạt khoảng 100%.</div>
                                <div>Mức độ đồng bộ của cảnh trong bộ ảnh đạt từ 70% - 90%.</div>
                                <div>khuyến nghị nên sử dụng lựa chọn này</div>
                            </div>
                        </div>

                        <!-- Option 2: Use Background Image Directly -->
                        <div style=${{padding:"20px",background:"#252525",border:"1px solid #333",borderRadius:"12px"}}>
                            <div style=${{color:"white",fontSize:"18px",fontWeight:"400",marginBottom:"16px",cursor:"pointer",border:"1px solid #555",background:"#333",padding:"12px 20px",borderRadius:"16px",display:"block",width:"fit-content",textAlign:"center"}} onClick=${async()=>{at(!0);try{const t=await te(rt,768,.6);N(e=>({...e,prompt:"",customPrompt:o("label_foreground_auto"),referenceImage:t})),It(!1),q(null)}catch(t){y(ft(t,o))}finally{at(!1)}}}>
                                dùng ảnh nền
                            </div>
                            <div style=${{fontSize:"15px",color:"#ff4d4f",lineHeight:"1.6"}}>
                                <div>Ảnh kết quả phông nền giống 100%.</div>
                                <div>Hòa hợp giữa cảnh và người đạt khoảng 50%</div>
                                <div>Mức độ đồng bộ cảnh bộ ảnh đạt 100%</div>
                                <div style=${{marginTop:"8px"}}>Yêu cầu chuẩn bị trước :</div>
                                <div>- Cần chuẩn ngay từ khâu chụp: ánh sáng, góc chụp, bổ cục phải phù hợp 100% với nền.</div>
                                <div>- Nền cần được xóa người, dọn khi đưa vào tham chiếu. Ảnh gốc và nền cần được ướm bổ cục và vị trí từ trước</div>
                                <div>- Nền cần được xử lý bằng Photoshop để dọn lại vị trí chân người mẫu đứng</div>
                            </div>
                        </div>
                    </div>

                    <div style=${{display:"flex",justifyContent:"flex-end",marginTop:"20px"}}>
                        <button class="btn btn-secondary" onClick=${()=>{It(!1),q(null)}}>Hủy</button>
                    </div>
                </div>
            </div>
        `}
        ${J&&g`
            <div style=${{position:"fixed",top:0,left:0,right:0,bottom:0,background:"rgba(0,0,0,0.85)",zIndex:11e3,display:"flex",alignItems:"center",justifyContent:"center"}}>
                <div style=${{background:"#1f1f1f",padding:"24px",borderRadius:"16px",width:"450px",maxWidth:"90%",border:"1px solid #333",boxShadow:"0 10px 30px rgba(0,0,0,0.5)"}}>
                    <h3 style=${{marginTop:0,marginBottom:"12px",fontSize:"18px",color:"white"}}>${o("album_import_duplicate_title")}</h3>
                    <p style=${{color:"#ccc",fontSize:"14px",marginBottom:"20px",lineHeight:"1.4"}}>
                        ${o("album_import_duplicate_msg",{name:J.item.name||"Không tên"})}
                        ${J.existingLocation&&g`
                            <div style=${{marginTop:"10px",padding:"8px 12px",background:"#222",borderRadius:"8px",fontSize:"12px",color:"#faad14",border:"1px solid #444",textAlign:"left"}}>
                                📍 Vị trí hiện tại: <b>${J.existingLocation}</b>
                            </div>
                        `}
                    </p>
                    
                    <div style=${{display:"flex",flexDirection:"column",gap:"8px",marginBottom:"20px"}}>
                        <div style=${{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"8px"}}>
                            <button class="btn btn-primary" onClick=${()=>J.resolve({mode:"overwrite",applyAll:!1})}>
                                ${o("album_import_overwrite")}
                            </button>
                            <button class="btn btn-primary" style=${{background:"#52c41a",borderColor:"#52c41a"}} onClick=${()=>J.resolve({mode:"overwrite",applyAll:!0})}>
                                ${o("album_import_overwrite_all")}
                            </button>
                        </div>
                        
                        <div style=${{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"8px"}}>
                            <button class="btn btn-secondary" onClick=${()=>J.resolve({mode:"skip",applyAll:!1})}>
                                ${o("album_import_skip")}
                            </button>
                            <button class="btn btn-secondary" onClick=${()=>J.resolve({mode:"skip",applyAll:!0})}>
                                ${o("album_import_skip_all")}
                            </button>
                        </div>

                        <button class="btn btn-secondary" onClick=${()=>J.resolve({mode:"rename",applyAll:Ie})}>
                            ${o("album_import_rename")}
                        </button>
                    </div>
                    
                    <label style=${{display:"flex",alignItems:"center",gap:"8px",color:"#888",fontSize:"12px",cursor:"pointer"}}>
                        <input type="checkbox" checked=${Ie} onChange=${t=>Bi(t.currentTarget.checked)} style=${{cursor:"pointer"}} />
                        ${o("album_import_apply_all")}
                    </label>
                </div>
            </div>
        `}
        ${ct&&g`
            <div style=${{position:"fixed",top:0,left:0,right:0,bottom:0,background:"rgba(0,0,0,0.85)",zIndex:11e3,display:"flex",alignItems:"center",justifyContent:"center"}}>
                <div style=${{background:"#1f1f1f",padding:"24px",borderRadius:"16px",width:"400px",maxWidth:"90%",border:"1px solid #333",textAlign:"center"}}>
                    <div style=${{fontSize:"48px",marginBottom:"16px"}}>✅</div>
                    <h3 style=${{marginTop:0,marginBottom:"20px",color:"white"}}>Hoàn tất nhập album</h3>
                    
                    <div style=${{textAlign:"left",background:"#252525",padding:"16px",borderRadius:"12px",marginBottom:"24px",fontSize:"14px",color:"#ccc",lineHeight:"1.8"}}>
                        ${ct.filesCount>1&&g`<div>📁 Số tệp xử lý: <b>${ct.filesCount}</b></div>`}
                        <div>📂 Thư mục mới: <span style=${{color:"#52c41a"}}>${ct.foldersAdded}</span></div>
                        <div>✨ Mẫu ảnh mới: <span style=${{color:"#1890ff"}}>${ct.itemsAdded}</span></div>
                        <div>🔄 Mẫu cập nhật: <span style=${{color:"#faad14"}}>${ct.itemsUpdated}</span></div>
                        <div>⏭️ Đã bỏ qua: <span style=${{color:"#8c8c8c"}}>${ct.itemsSkipped}</span></div>
                    </div>
                    
                    <button class="btn btn-primary" style=${{width:"100%",padding:"12px"}} onClick=${()=>_e(null)}>
                        Đóng
                    </button>
                </div>
            </div>
        `}
        ${(()=>{const t=S.filter(l=>l.generated),e=Q!==null?t[Q]:null,n=Q!==null&&Q<t.length-1,s=Q!==null&&Q>0;return e&&e.generated&&g`
                <${Fs}
                    t=${o}
                    originalUrl=${e.original}
                    generatedUrl=${e.generated}
                    onClose=${()=>Et(null)}
                    caption=${o("detailedComparison")}
                    toggleView=${!0}
                    onNext=${()=>n&&Et(Q+1)}
                    onPrev=${()=>s&&Et(Q-1)}
                    hasNext=${n}
                    hasPrev=${s}
                    imageIndex=${Q}
                    totalImages=${t.length}
                />
            `})()}
        <div class="editor-layout batch-background-view ${pt?"":"panel-hidden"}" style=${{gridTemplateColumns:`${bt?"40px":Lt+"px"} 4px 1fr 4px ${pt?Yt:40}px`,gap:0,transition:ot||it?"none":"grid-template-columns 0.3s cubic-bezier(0.4, 0, 0.2, 1)",position:"relative"}}>
            ${(ot||it)&&g`
                <div style=${{position:"fixed",top:0,left:0,right:0,bottom:0,zIndex:9999,cursor:"col-resize",background:"transparent"}}></div>
            `}


            <!-- Left Sidebar: Album Concept (Vertical) -->
            <div style=${{width:bt?"40px":`${Lt}px`,height:"100%",background:"#0a0a0a",borderRight:"1px solid #1a1a1a",display:"flex",flexDirection:"column",overflow:"hidden",position:"relative",transition:"width 0.3s cubic-bezier(0.4, 0, 0.2, 1)"}}>
                <!-- Collapse Left Toggle Button -->
                <button 
                    onClick=${()=>Ai(!bt)}
                    style=${{position:"absolute",top:"50%",right:"-12px",transform:"translateY(-50%)",width:"24px",height:"48px",background:"#333",border:"1px solid #555",borderLeft:"none",borderRadius:"0 8px 8px 0",cursor:"pointer",zIndex:150,display:"flex",alignItems:"center",justifyContent:"center",color:"#aaa",fontSize:"12px",transition:"background 0.2s"}}
                    title=${bt?"Mở rộng Album":"Thu gọn Album"}
                >
                    ${bt?"»":"«"}
                </button>

                ${bt?g`
                    <div style=${{writingMode:"vertical-rl",textOrientation:"mixed",color:"#888",fontSize:"12px",padding:"10px 5px",textAlign:"center"}}>Album Mẫu</div>
                `:g`
                <${X} title=${g`<div style=${{display:"flex",alignItems:"center",gap:"8px",fontSize:"14px"}}><div style=${{width:"2px",height:"14px",background:"#fff",borderRadius:"1px"}}></div> <span style=${{fontWeight:"600"}}>Album Mẫu</span> <span style=${{fontWeight:"300",opacity:.8,fontSize:"12px"}}>Concept</span> ${Ne&&!Z?g`<span style=${{opacity:.5,fontSize:"11px"}}> / ${Ne}</span>`:""}</div>`} initialOpen=${!0}>
                    <div 
                        style=${{padding:"0.5rem",height:"calc(100vh - 120px)",maxHeight:"calc(100vh - 120px)",overflowY:"auto",overflowX:"hidden",scrollbarWidth:"thin"}}
                        onDragOver=${t=>t.stopPropagation()}
                        onDragEnter=${t=>t.stopPropagation()}
                    >
                        <!-- Compact Toolbar (Vertical Layout) - Sticky -->
                        <div style=${{display:"flex",flexDirection:"column",gap:"0.4rem",marginBottom:"0.6rem",position:"sticky",top:"-0.5rem",zIndex:100,background:"#0a0a0a",padding:"0.5rem 0 0.6rem 0",borderBottom:"1px solid #1a1a1a"}}>
                            <!-- Nav group -->
                            <div style=${{display:"flex",gap:"0.3rem",alignItems:"center",flexWrap:"wrap"}}>
                                ${M!==null&&!Z&&g`
                                    <button class="btn btn-secondary btn-sm" onClick=${()=>Ut(es)} style=${{fontSize:"9px",padding:"2px 8px",background:"#222",border:"1px solid #444",borderRadius:"15px"}}>
                                        ← ${o("album_back_to_root").replace("← ","")}
                                    </button>
                                `}
                                <button class="btn btn-sm" onClick=${()=>Kt(!0)} style=${{fontSize:"9px",padding:"2px 8px",background:"linear-gradient(45deg, #ff9a9e 0%, #fad0c4 99%, #fad0c4 100%)",border:"none",borderRadius:"15px",color:"#000",fontWeight:"bold",display:"flex",alignItems:"center",gap:"3px",boxShadow:"0 2px 5px rgba(0,0,0,0.2)"}}>
                                    <span>📚</span> ${o("album_guide_button")}
                                </button>

                                <button class="btn btn-primary btn-sm" onClick=${()=>qi()} style=${{fontSize:"9px",padding:"2px 8px",background:"#28a745",borderColor:"#28a745",borderRadius:"15px",fontWeight:"bold"}}>
                                    + Tạo mẫu mới
                                </button>
                                
                                <button class="btn btn-primary btn-sm" onClick=${()=>Nt(!0)} style=${{fontSize:"9px",padding:"2px 8px",background:"#0095ff",borderColor:"#0095ff",borderRadius:"15px",fontWeight:"bold"}}>
                                    + ${o("album_create_folder")}
                                </button>
                            </div>

                            <!-- Search group -->
                            <div style=${{display:"flex",gap:"0.3rem",alignItems:"center"}}>
                                <div style=${{position:"relative",flex:1}}>
                                    <input 
                                        type="text" 
                                        placeholder=${o("album_search_placeholder")} 
                                        value=${Z}
                                        onInput=${t=>Mi(t.currentTarget.value)}
                                        style=${{width:"100%",padding:"1px 6px 1px 18px",background:"#000",border:"1px solid #333",borderRadius:"4px",color:"#fff",fontSize:"10px",height:"22px"}} 
                                    />
                                    <span style=${{position:"absolute",left:"5px",top:"50%",transform:"translateY(-50%)",opacity:.5,fontSize:"9px"}}>🔍</span>
                                </div>
                                <select 
                                    value=${xt} 
                                    onChange=${t=>Fi(t.currentTarget.value)}
                                    style=${{background:"#000",border:"1px solid #333",borderRadius:"4px",color:"#fff",padding:"1px 2px",fontSize:"9px",height:"22px"}}
                                >
                                    <option value="newest">${o("album_sort_newest")}</option>
                                    <option value="oldest">${o("album_sort_oldest")}</option>
                                    <option value="usage">${o("album_sort_usage")}</option>
                                    <option value="favorite">${o("album_sort_favorite")}</option>
                                </select>
                            </div>

                            <!-- Zoom Slider + Actions group -->
                            <div style=${{display:"flex",gap:"6px",alignItems:"center",flexWrap:"wrap"}}>
                                <!-- Undo/Redo Controls -->
                                <div style=${{display:"flex",alignItems:"center",gap:"2px",background:"#222",padding:"2px 4px",borderRadius:"4px",border:"1px solid #333"}}>
                                    <button onClick=${Ee} disabled=${gt.length===0} title=${`${o("undo")} (Ctrl+Z)`} style=${{background:"transparent",border:"none",cursor:gt.length>0?"pointer":"default",opacity:gt.length>0?1:.3,padding:"2px 4px",fontSize:"14px",lineHeight:1}}>↩️</button>
                                    <button onClick=${le} disabled=${ut.length===0} title=${`${o("redo")} (Ctrl+Y)`} style=${{background:"transparent",border:"none",cursor:ut.length>0?"pointer":"default",opacity:ut.length>0?1:.3,padding:"2px 4px",fontSize:"14px",lineHeight:1}}>↪️</button>
                                </div>

                                <!-- Zoom Controls -->
                                <div style=${{display:"flex",alignItems:"center",gap:"4px",background:"#111",padding:"2px 6px",borderRadius:"4px",border:"1px solid #333"}}>
                                    <span style=${{fontSize:"10px",color:"#888"}}>🔍</span>
                                    <input 
                                        type="range" 
                                        min="100" 
                                        max="300" 
                                        value=${F}
                                        onInput=${t=>Ui(parseInt(t.currentTarget.value))}
                                        style=${{width:"60px",height:"4px",accentColor:"#667eea"}}
                                    />
                                    <span style=${{fontSize:"9px",color:"#666",minWidth:"28px"}}>${F}px</span>
                                </div>
                                
                                <button class=${`btn btn-sm ${U?"btn-primary":"btn-secondary"}`} style=${{fontSize:"9px",padding:"1px 6px",background:U?"#0095ff":"#222",border:"1px solid #333"}} onClick=${()=>{Rt(!U),U&&$t([])}}>
                                    ${U?"✓ ":""}${o("album_select_mode")}
                                </button>
                                <button class="btn btn-link btn-sm" style=${{fontSize:"9px",padding:"1px 4px",textDecoration:"none",color:"#ccc"}} onClick=${()=>He(U&&W.length>0?W:void 0)}>
                                    ${U&&W.length>0?`${o("export_album")} (${W.length})`:o("export_album")}
                                </button>
                                <label class="btn btn-link btn-sm" style=${{cursor:"pointer",margin:0,fontSize:"9px",padding:"1px 4px",textDecoration:"none",color:"#ccc"}}>
                                    ${o("import_album")}
                                    <input type="file" accept=".json" multiple style=${{display:"none"}} onChange=${ns} />
                                </label>
                                 <button class="btn btn-link btn-sm" style=${{fontSize:"9px",padding:"1px 4px",textDecoration:"none",color:"#ff8c00"}} onClick=${Qi}>
                                    ✨ Dọn file trùng
                                </button>
                                <button class="btn btn-link btn-sm" style=${{fontSize:"9px",padding:"1px 4px",textDecoration:"none",color:"#ff4d4f"}} onClick=${Ji}>
                                    🗑️ Xóa sạch
                                </button>
                            </div>
                        </div>

                        <!-- Floating Batch Actions Bar -->
                        ${U&&W.length>0&&g`
                            <div style=${{position:"sticky",top:"0",zIndex:10,marginBottom:"0.5rem",background:"#667eea",color:"#fff",padding:"0.3rem 0.5rem",borderRadius:"6px",display:"flex",flexDirection:"column",gap:"0.3rem",boxShadow:"0 4px 15px rgba(0,0,0,0.3)"}}>
                                <span style=${{fontWeight:"bold",fontSize:"11px"}}>${o("album_selected_count").replace("{count}",W.length.toString())}</span>
                                <div style=${{display:"flex",gap:"0.3rem",flexWrap:"wrap"}}>
                                    <button class="btn btn-sm" style=${{background:"rgba(255,255,255,0.2)",border:"1px solid rgba(255,255,255,0.3)",color:"#fff",fontSize:"9px",padding:"2px 6px"}} onClick=${Yi}>
                                        🗑️ ${o("album_batch_delete")}
                                    </button>
                                    <button class="btn btn-sm" style=${{background:"rgba(255,255,255,0.2)",border:"1px solid rgba(255,255,255,0.3)",color:"#fff",fontSize:"9px",padding:"2px 6px"}} onClick=${()=>He(W)}>
                                        📤 Export
                                    </button>
                                    <div style=${{position:"relative"}}>
                                        <button class="btn btn-sm" style=${{background:"rgba(255,255,255,0.2)",border:"1px solid rgba(255,255,255,0.3)",color:"#fff",fontSize:"9px",padding:"2px 6px"}} onClick=${()=>yt("batch")}>
                                            📂 ${o("album_batch_move")}
                                        </button>
                                        ${Te==="batch"&&g`
                                            <div style=${{position:"absolute",top:"100%",left:0,marginTop:"5px",background:"#2a2a2a",border:"1px solid #444",borderRadius:"8px",padding:"0.5rem",minWidth:"120px",zIndex:100}}>
                                                <div style=${{fontSize:"10px",color:"#888",marginBottom:"5px"}}>${o("album_move_to")}...</div>
                                                <div style=${{display:"flex",flexDirection:"column",gap:"2px"}}>
                                                    <button class="btn btn-sm btn-secondary" style=${{textAlign:"left",fontSize:"10px"}} onClick=${()=>We(null)}>${o("album_root")}</button>
                                                    ${_.map(t=>g`
                                                        <button class="btn btn-sm btn-secondary" style=${{textAlign:"left",fontSize:"10px"}} onClick=${()=>We(t.id)}>${t.name}</button>
                                                    `)}
                                                </div>
                                                <button class="btn btn-sm btn-link" style=${{width:"100%",marginTop:"5px",fontSize:"9px"}} onClick=${()=>yt(null)}>${o("cancel")}</button>
                                            </div>
                                        `}
                                    </div>
                                </div>
                                <button class="btn btn-sm" style=${{position:"absolute",top:"2px",right:"2px",background:"transparent",border:"none",color:"#fff",fontSize:"14px",padding:"0"}} onClick=${()=>{Rt(!1),$t([])}}>×</button>
                            </div>
                        `}

                        <!-- Create Folder Modal -->
                        ${Ei&&g`
                            <div style=${{position:"fixed",top:0,left:0,right:0,bottom:0,background:"rgba(0,0,0,0.7)",zIndex:9999,display:"flex",alignItems:"center",justifyContent:"center"}} onClick=${()=>Nt(!1)}>
                                <div style=${{background:"#1e1e1e",padding:"1.5rem",borderRadius:"12px",minWidth:"300px",border:"1px solid #444"}} onClick=${t=>t.stopPropagation()}>
                                    <h3 style=${{margin:"0 0 1rem 0",color:"#fff"}}>${o("album_create_folder")}</h3>
                                    <input 
                                        type="text"
                                        placeholder=${o("album_folder_name_placeholder")}
                                        value=${Ht}
                                        onInput=${t=>Ce(t.currentTarget.value)}
                                        onKeyDown=${t=>t.key==="Enter"&&je()}
                                        style=${{width:"100%",padding:"0.75rem",fontSize:"1rem",background:"#333",border:"1px solid #555",borderRadius:"6px",color:"#fff",marginBottom:"1rem"}}
                                        autoFocus
                                    />
                                    <div style=${{display:"flex",gap:"0.5rem",justifyContent:"flex-end"}}>
                                        <button class="btn btn-secondary" onClick=${()=>Nt(!1)}>${o("cancel")}</button>
                                        <button class="btn btn-primary" onClick=${je} disabled=${!Ht.trim()}>${o("button_save")}</button>
                                    </div>
                                </div>
                            </div>
                        `}

                        ${Ni&&g`
                            <div style=${{position:"fixed",top:0,left:0,right:0,bottom:0,background:"rgba(0,0,0,0.85)",zIndex:99999,display:"flex",alignItems:"center",justifyContent:"center"}} onClick=${()=>Kt(!1)}>
                                <div style=${{background:"#1e1e1e",padding:"0",borderRadius:"16px",width:"600px",maxWidth:"95%",border:"1px solid #444",display:"flex",flexDirection:"column",maxHeight:"90vh",overflow:"hidden",boxShadow:"0 20px 50px rgba(0,0,0,0.5)"}} onClick=${t=>t.stopPropagation()}>
                                    <!-- Header -->
                                    <div style=${{padding:"20px 24px",borderBottom:"1px solid #333",display:"flex",alignItems:"center",justifyContent:"space-between",background:"linear-gradient(to right, #2a2a2a, #1e1e1e)"}}>
                                        <h3 style=${{margin:0,color:"#fff",fontSize:"18px",display:"flex",alignItems:"center",gap:"8px"}}>
                                            <span style=${{fontSize:"24px"}}>📚</span> ${o("album_guide_button")}
                                        </h3>
                                        <button onClick=${()=>Kt(!1)} style=${{background:"transparent",border:"none",color:"#888",cursor:"pointer",fontSize:"20px",padding:"5px"}}>✕</button>
                                    </div>
                                    
                                    <!-- Content -->
                                    <div style=${{padding:"24px",overflowY:"auto",color:"#ddd",fontSize:"14px",lineHeight:"1.6"}}>
                                        <div style=${{marginBottom:"20px",display:"flex",gap:"15px"}}>
                                            <div style=${{background:"#333",borderRadius:"50%",width:"32px",height:"32px",display:"flex",alignItems:"center",justifyContent:"center",fontWeight:"bold",flexShrink:0}}>1</div>
                                            <div>
                                                <strong style=${{color:"#fff",fontSize:"16px"}}>Lưu & Bổ sung Concept</strong>
                                                <p style=${{marginTop:"5px",margin:0}}>Khi nhấn nút <span style=${{display:"inline-flex",alignItems:"center",justifyContent:"center",width:"20px",height:"20px",background:"#333",borderRadius:"4px",verticalAlign:"middle"}}><${fi} style=${{width:"12px"}}/></span>, bạn có thể chọn "Lưu mẫu mới" hoặc "Bổ sung" vào một mẫu cũ để hoàn thiện bộ 3 góc chụp: Toàn thân, Bán thân và Cận cảnh.</p>
                                            </div>
                                        </div>

                                        <div style=${{marginBottom:"20px",display:"flex",gap:"15px"}}>
                                            <div style=${{background:"#333",borderRadius:"50%",width:"32px",height:"32px",display:"flex",alignItems:"center",justifyContent:"center",fontWeight:"bold",flexShrink:0}}>2</div>
                                            <div>
                                                <strong style=${{color:"#fff",fontSize:"16px"}}>Theo dõi độ hoàn thiện</strong>
                                                <p style=${{marginTop:"5px",margin:0}}>Mỗi thẻ ảnh có 3 biểu tượng tượng hình đại diện cho 3 góc chụp. Màu <strong>Xanh</strong> là đã có dữ liệu, màu <strong>Xám</strong> là chưa có. Giúp bạn biết mẫu nào cần nạp thêm ảnh góc chụp nào.</p>
                                            </div>
                                        </div>

                                        <div style=${{marginBottom:"20px",display:"flex",gap:"15px"}}>
                                            <div style=${{background:"#333",borderRadius:"50%",width:"32px",height:"32px",display:"flex",alignItems:"center",justifyContent:"center",fontWeight:"bold",flexShrink:0}}>3</div>
                                            <div>
                                                <strong style=${{color:"#fff",fontSize:"16px"}}>Đồng bộ Menu thông minh</strong>
                                                <p style=${{marginTop:"5px",margin:0}}>Khi click chọn mẫu (viền xanh ngọc), nếu bạn thay đổi nút bấm <strong>Menu góc chụp</strong> ở bảng cài đặt, hệ thống sẽ tự động nạp đúng Prompt và hiệu ứng tương ứng của mẫu đó.</p>
                                            </div>
                                        </div>

                                        <div style=${{marginBottom:"20px",display:"flex",gap:"15px"}}>
                                            <div style=${{background:"#333",borderRadius:"50%",width:"32px",height:"32px",display:"flex",alignItems:"center",justifyContent:"center",fontWeight:"bold",flexShrink:0}}>4</div>
                                            <div>
                                                <strong style=${{color:"#fff",fontSize:"16px"}}>Quản lý & Sao lưu</strong>
                                                <p style=${{marginTop:"5px",margin:0}}>Dùng nút "Thư mục mới" để phân loại Concept. Hãy thường xuyên dùng nút <strong>Export (Xuất)</strong> để tải về file sao lưu (.json) tránh mất dữ liệu khi trình duyệt xóa bộ nhớ cache.</p>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Footer -->
                                    <div style=${{padding:"16px 24px",borderTop:"1px solid #333",textAlign:"right",background:"#252525"}}>
                                        <button class="btn btn-primary" onClick=${()=>Kt(!1)}>Đã hiểu</button>
                                    </div>
                                </div>
                            </div>
                        `}

                        <!-- Album Content (Vertical Grid) -->
                        ${!Z&&Ue.length===0&&Y.length===0?g`
                            <div style=${{textAlign:"center",padding:"1rem",color:"#666",border:"1px dashed #333",borderRadius:"8px",fontSize:"12px"}}>
                                ${o("album_empty")}
                            </div>
                        `:Y.length===0&&Z?g`
                            <div style=${{textAlign:"center",padding:"1rem",color:"#666",fontSize:"12px"}}>
                                ${o("album_no_results")}
                            </div>
                        `:g`
                            <div style=${{display:"grid",gridTemplateColumns:`repeat(auto-fill, minmax(${Math.max(80,F-40)}px, 1fr))`,gap:"0.5rem",paddingBottom:"0.5rem",alignItems:"start"}}>
                                <!-- Subfolders (Full Width Row) -->
                                ${!Z&&Ue.map(t=>g`
                                    <div 
                                        class="subfolder-card"
                                        style=${{gridColumn:"1 / -1",display:"flex",alignItems:"center",gap:"0.5rem",background:Pe===t.id?"#333":"#1a1a1a",borderRadius:"6px",padding:"0.4rem 0.6rem",border:Pe===t.id?"2px dashed #667eea":"1px solid #333",cursor:"pointer",transition:"all 0.2s"}}
                                        onClick=${()=>Ut(t.id)}
                                        onDragOver=${e=>{e.preventDefault(),e.stopPropagation(),ie(t.id)}}
                                        onDragLeave=${()=>ie(null)}
                                        onDrop=${e=>{e.preventDefault(),e.stopPropagation(),ie(null),zt&&pe(zt,t.id)}}
                                    >
                                        <div style=${{fontSize:"1.5rem"}}>📁</div>
                                        <div style=${{flex:1,minWidth:0}}>
                                            ${Wi===t.id?g`
                                                <input 
                                                    type="text"
                                                    value=${t.name}
                                                    onClick=${e=>e.stopPropagation()}
                                                    onBlur=${e=>Oe(t.id,e.currentTarget.value)}
                                                    onKeyDown=${e=>{e.key==="Enter"&&Oe(t.id,e.currentTarget.value)}}
                                                    style=${{width:"100%",background:"#111",border:"1px solid #444",borderRadius:"4px",padding:"2px 4px",color:"#fff",fontSize:"11px"}}
                                                    autoFocus
                                                />
                                            `:g`
                                                <div style=${{fontSize:"12px",fontWeight:"bold",color:"#eee",whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>${t.name}</div>
                                            `}
                                            <div style=${{fontSize:"10px",color:"#666"}}>${z.filter(e=>e.folderId===t.id).length} ${o("album_items_count").split(" ")[1]}</div>
                                        </div>
                                        <div style=${{display:"flex",gap:"2px"}}>
                                            <button 
                                                class="btn btn-secondary btn-sm" 
                                                style=${{fontSize:"9px",padding:"2px 6px",background:"#333"}}
                                                onClick=${e=>{e.stopPropagation(),Ae(t.id)}}
                                            >✏️</button>
                                            <button 
                                                class="btn btn-secondary btn-sm" 
                                                style=${{fontSize:"9px",padding:"2px 6px",background:"#333",color:"#ff4d4f"}}
                                                onClick=${e=>{e.stopPropagation(),confirm(o("album_delete_folder_confirm"))&&Xi(t.id)}}
                                            >🗑️</button>
                                        </div>
                                    </div>
                                `)}
                                
                                <!-- Items (Portrait Cards for Grid) -->
                                ${Y.map(t=>{var e,n,s,l,r,i,a,d,u,b,x,w,k,C,E,tt;return g`
                                    <div 
                                        draggable=${!U&&!ot&&!it}
                                        onDragStart=${c=>{c.stopPropagation(),oe(t.id),c.dataTransfer&&(c.dataTransfer.effectAllowed="move")}}
                                        onDragEnd=${()=>oe(null)}
                                        style=${{position:"relative",background:"#000",borderRadius:"8px",overflow:"hidden",border:vt===t.id?"2px solid #00d1b2":W.includes(t.id)?"2px solid #0095ff":t.thumbnail.startsWith("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=")?"4px solid #fff":"1px solid #222",transition:"all 0.2s",boxShadow:vt===t.id?"0 0 20px rgba(0, 209, 178, 0.4)":t.thumbnail.startsWith("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=")?"0 0 15px rgba(255,255,255,0.4)":"0 2px 8px rgba(0,0,0,0.5)",opacity:zt===t.id?.5:1,cursor:"pointer"}}
                                        onClick=${()=>U?Ki(t.id):wt(t.id)}
                                    >
                                        <!-- Full Frame Image & Overlays -->
                                        <div style=${{position:"relative",width:"100%",background:"#000",display:"flex",alignItems:"center",justifyContent:"center"}}>
                                            <img src=${t.thumbnail} style=${{width:"100%",height:"auto",objectFit:"contain",display:"block",minHeight:"100px"}} />
                                            
                                            <!-- TOP LEFT: Name Overlay -->
                                            <div style=${{position:"absolute",top:0,left:0,right:"24px",padding:"3px 5px",background:"linear-gradient(to bottom, rgba(0,0,0,0.4) 0%, transparent 100%)",zIndex:2}}>
                                                <input 
                                                    type="text" 
                                                    placeholder="Tên mẫu ?" 
                                                    value=${t.name||""} 
                                                    onBlur=${c=>Zi(t.id,c.currentTarget.value)}
                                                    onKeyDown=${c=>c.key==="Enter"&&c.currentTarget.blur()}
                                                    onClick=${c=>c.stopPropagation()}
                                                    disabled=${U}
                                                    style=${{width:"100%",background:"transparent",border:"none",color:"#fff",fontSize:"11px",fontWeight:"500",padding:0,outline:"none",textShadow:"0 1px 3px rgba(0,0,0,1), 0 0 5px rgba(0,0,0,0.8)"}}
                                                />
                                            </div>

                                            <!-- BOTTOM LEFT icons removed -->

                                            <!-- TOP RIGHT: Delete/Select & Move -->
                                            <div style=${{position:"absolute",top:"3px",right:"3px",zIndex:10,display:"flex",flexDirection:"column",gap:"3px",alignItems:"flex-end"}}>
                                                ${U?g`
                                                    <div style=${{width:"20px",height:"20px",borderRadius:"4px",background:W.includes(t.id)?"#0095ff":"rgba(0,0,0,0.6)",border:"1px solid #fff",display:"flex",alignItems:"center",justifyContent:"center",color:"#fff",fontSize:"10px"}}>
                                                        ${W.includes(t.id)?"✓":""}
                                                    </div>
                                                `:g`
                                                    <button 
                                                        title=${o("delete")}
                                                        onClick=${c=>{c.stopPropagation(),ts(t.id)}}
                                                        style=${{background:"rgba(0,0,0,0.2)",border:"none",borderRadius:"4px",width:"20px",height:"20px",display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",color:"#ff4d4f",fontSize:"8px"}}
                                                    >✕</button>
                                                `}

                                                ${!U&&g`
                                                    <button 
                                                        title=${o("edit")}
                                                        onClick=${c=>{c.stopPropagation(),$({...t})}}
                                                        style=${{background:"rgba(0,0,0,0.2)",border:"none",borderRadius:"4px",width:"20px",height:"20px",display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",color:"#fff",fontSize:"10px"}}
                                                    >✏️</button>
                                                    <button 
                                                        title=${o("album_move_to")}
                                                        onClick=${c=>{c.stopPropagation(),yt(t.id)}}
                                                        style=${{background:"rgba(0,0,0,0.2)",border:"none",borderRadius:"4px",width:"20px",height:"20px",display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",color:"#ffd700",fontSize:"10px"}}
                                                    >📂</button>
                                                `}
                                            </div>
                                            
                                            <div style=${{position:"absolute",bottom:`${Math.max(1,2*(F/170))}px`,left:`${Math.max(1,2*(F/170))}px`,zIndex:10,display:"flex",gap:`${Math.max(1.5,2.5*(F/170))}px`,background:"rgba(0,0,0,0.3)",padding:`${Math.max(1.5,3*(F/170))}px`,borderRadius:`${Math.max(3,5*(F/170))}px`,alignItems:"center",border:"1px solid rgba(255,255,255,0.1)"}}>
                                                <div title=${o("frame_type_wide")} style=${{width:`${Math.max(12,30*(F/170))}px`,height:`${Math.max(12,30*(F/170))}px`,display:"flex",alignItems:"center",justifyContent:"center",color:(n=(e=t.shotSettings)==null?void 0:e.wide)!=null&&n.prompt&&t.shotSettings.wide.prompt.trim()!==""?"#00d1b2":"rgba(255,255,255,0.3)",filter:(l=(s=t.shotSettings)==null?void 0:s.wide)!=null&&l.prompt&&t.shotSettings.wide.prompt.trim()!==""?"drop-shadow(0 0 5px rgba(0, 209, 178, 0.5))":"none"}}><${mi} style=${{width:"100%",height:"100%"}} /></div>
                                                <div title=${o("frame_type_full_shot")} style=${{width:`${Math.max(9,22.5*(F/170))}px`,height:`${Math.max(9,22.5*(F/170))}px`,display:"flex",alignItems:"center",justifyContent:"center",color:(i=(r=t.shotSettings)==null?void 0:r.full)!=null&&i.prompt&&t.shotSettings.full.prompt.trim()!==""?"#00d1b2":"rgba(255,255,255,0.3)",filter:(d=(a=t.shotSettings)==null?void 0:a.full)!=null&&d.prompt&&t.shotSettings.full.prompt.trim()!==""?"drop-shadow(0 0 5px rgba(0, 209, 178, 0.5))":"none"}}><${bi} style=${{width:"100%",height:"100%"}} /></div>
                                                <div title=${o("frame_type_half_body")} style=${{width:`${Math.max(9,22.5*(F/170))}px`,height:`${Math.max(9,22.5*(F/170))}px`,display:"flex",alignItems:"center",justifyContent:"center",color:(b=(u=t.shotSettings)==null?void 0:u.half)!=null&&b.prompt&&t.shotSettings.half.prompt.trim()!==""?"#00d1b2":"rgba(255,255,255,0.3)",filter:(w=(x=t.shotSettings)==null?void 0:x.half)!=null&&w.prompt&&t.shotSettings.half.prompt.trim()!==""?"drop-shadow(0 0 5px rgba(0, 209, 178, 0.5))":"none"}}><${xi} style=${{width:"100%",height:"100%"}} /></div>
                                                <div title=${o("frame_type_closeup")} style=${{width:`${Math.max(9,22.5*(F/170))}px`,height:`${Math.max(9,22.5*(F/170))}px`,display:"flex",alignItems:"center",justifyContent:"center",color:(C=(k=t.shotSettings)==null?void 0:k.closeup)!=null&&C.prompt&&t.shotSettings.closeup.prompt.trim()!==""?"#00d1b2":"rgba(255,255,255,0.3)",filter:(tt=(E=t.shotSettings)==null?void 0:E.closeup)!=null&&tt.prompt&&t.shotSettings.closeup.prompt.trim()!==""?"drop-shadow(0 0 5px rgba(0, 209, 178, 0.5))":"none"}}><${$i} style=${{width:"100%",height:"100%"}} /></div>
                                            </div>

                                            <!-- Stats & Tags Overlay removed -->
                                        </div>

                                        <!-- Enhanced Move To Overlay -->
                                        ${Te===t.id&&g`
                                            <div style=${{position:"absolute",top:0,left:0,right:0,bottom:0,background:"rgba(0,0,0,0.92)",zIndex:100,padding:"10px",display:"flex",flexDirection:"column",gap:"6px",animation:"fadeIn 0.2s ease"}}>
                                                <div style=${{fontSize:"11px",color:"#667eea",fontWeight:"bold",textAlign:"center"}}>${o("album_move_to")}</div>
                                                <div style=${{flex:1,overflowY:"auto",display:"flex",flexDirection:"column",gap:"3px"}}>
                                                    <button class="btn btn-sm btn-secondary" style=${{textAlign:"left",padding:"6px",fontSize:"10px"}} onClick=${c=>{c.stopPropagation(),pe(t.id,null)}}>🏠 ${o("album_root")}</button>
                                                    ${_.filter(c=>c.id!==t.folderId).map(c=>g`
                                                        <button class="btn btn-sm btn-secondary" style=${{textAlign:"left",padding:"6px",fontSize:"10px"}} onClick=${v=>{v.stopPropagation(),pe(t.id,c.id)}}>📁 ${c.name}</button>
                                                    `)}
                                                </div>
                                                <button class="btn btn-sm btn-link" style=${{fontSize:"9px"}} onClick=${c=>{c.stopPropagation(),yt(null)}}>${o("cancel")}</button>
                                            </div>
                                        `}
                                    </div>
                                `})}
                            </div>
                        `}
                    </div>
                </${X}>
                `}

                <!-- Album Lightbox Modal -->
                ${V&&g`
                    <div 
                        style=${{position:"fixed",top:0,left:0,right:0,bottom:0,background:"rgba(0,0,0,0.95)",zIndex:9999,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center"}}
                        onClick=${()=>St(null)}
                    >
                        <!-- Close Button -->
                        <button 
                            style=${{position:"absolute",top:"20px",right:"20px",background:"rgba(255,255,255,0.1)",border:"1px solid rgba(255,255,255,0.3)",borderRadius:"50%",width:"44px",height:"44px",color:"#fff",fontSize:"24px",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}
                            onClick=${()=>St(null)}
                        >×</button>

                        <!-- Navigation Prev -->
                        ${(()=>{const t=Y.findIndex(e=>e.id===V.id);return t>0?g`
                                <button 
                                    style=${{position:"absolute",left:"20px",top:"50%",transform:"translateY(-50%)",background:"rgba(255,255,255,0.1)",border:"1px solid rgba(255,255,255,0.3)",borderRadius:"50%",width:"50px",height:"50px",color:"#fff",fontSize:"24px",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}
                                    onClick=${e=>{e.stopPropagation(),St(Y[t-1])}}
                                >◀</button>
                            `:""})()}

                        <!-- Navigation Next -->
                        ${(()=>{const t=Y.findIndex(e=>e.id===V.id);return t<Y.length-1?g`
                                <button 
                                    style=${{position:"absolute",right:"20px",top:"50%",transform:"translateY(-50%)",background:"rgba(255,255,255,0.1)",border:"1px solid rgba(255,255,255,0.3)",borderRadius:"50%",width:"50px",height:"50px",color:"#fff",fontSize:"24px",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}
                                    onClick=${e=>{e.stopPropagation(),St(Y[t+1])}}
                                >▶</button>
                            `:""})()}

                        <!-- Main Image (Full Screen, Portrait Priority) -->
                        <img 
                            src=${V.thumbnail} 
                            style=${{maxWidth:"90vw",maxHeight:"85vh",objectFit:"contain",borderRadius:"8px",boxShadow:"0 10px 50px rgba(0,0,0,0.5)"}}
                            onClick=${t=>t.stopPropagation()}
                        />

                        <!-- Info Bar -->
                        <div style=${{marginTop:"15px",padding:"10px 20px",background:"rgba(255,255,255,0.1)",borderRadius:"8px",display:"flex",alignItems:"center",gap:"15px",color:"#fff",fontSize:"13px"}}>
                            ${V.name&&g`<span style=${{fontWeight:"bold"}}>${V.name}</span>`}
                            <span style=${{opacity:.7}}>⚡ ${V.useCount||0} lần sử dụng</span>
                            ${V.isFavorite&&g`<span style=${{color:"#ff4d4f"}}>❤️ Yêu thích</span>`}
                            
                            <div style=${{marginLeft:"auto",display:"flex",gap:"8px"}}>
                                <label class="btn btn-sm" style=${{background:"rgba(255,255,255,0.2)",border:"1px solid rgba(255,255,255,0.3)",color:"#fff",cursor:"pointer",margin:0,display:"flex",alignItems:"center"}} onClick=${t=>t.stopPropagation()}>
                                    📷 Thay ảnh
                                    <input 
                                        type="file" 
                                        accept="image/*" 
                                        style=${{display:"none"}} 
                                        onChange=${async t=>{var s;const e=(s=t.target.files)==null?void 0:s[0];if(!e)return;const n=new FileReader;n.onload=async l=>{const r=l.target.result,i=await de(r);P(),L(a=>a.map(d=>d.id===V.id?{...d,thumbnail:i}:d)),St(a=>a?{...a,thumbnail:i}:null)},n.readAsDataURL(e)}}
                                    />
                                </label>
                                <button 
                                    class="btn btn-sm btn-primary"
                                    onClick=${t=>{t.stopPropagation(),wt(V.id),St(null)}}
                                >
                                    Sử dụng prompt này
                                </button>
                            </div>
                        </div>

                        <!-- Counter -->
                        <div style=${{marginTop:"10px",color:"rgba(255,255,255,0.5)",fontSize:"12px"}}>
                            ${Y.findIndex(t=>t.id===V.id)+1} / ${Y.length}
                        </div>
                    </div>
                `}
            </div>

            <!-- Left Resize Handle -->
            <div 
                onMouseDown=${()=>Be(!0)} 
                class="panel-resizer"
                style=${{width:"100%",position:"relative",zIndex:100,display:"flex",justifyContent:"center",cursor:"col-resize"}}
            >
                <!-- Visual divider -->
                <div style=${{width:"1px",background:ot?"var(--primary)":"#222",height:"100%"}}></div>
                <!-- Hit area (Invisible but wider) -->
                <div style=${{position:"absolute",top:0,bottom:0,width:"16px",cursor:"col-resize"}}></div>
            </div>

            <!-- Center: Main Image Workspace -->
            <div class="image-panel droppable ${Ci?"drag-over":""}" style=${{height:"100%",overflow:"hidden",position:"relative"}} onDragOver=${t=>ge(t,!0)} onDragEnter=${t=>ge(t,!0)} onDragLeave=${t=>ge(t,!1)} onDrop=${$s}>
                <div style=${{width:"100%",display:"flex",flexDirection:"column",height:"100%",padding:"0.75rem 1rem",overflow:"hidden"}}>
                    <div class="actions" style=${{position:"relative",bottom:"auto",right:"auto",justifyContent:"space-between",marginBottom:"1rem",flexWrap:"wrap",gap:"0.5rem",flexShrink:0}}>
                        <div style=${{display:"flex",gap:"0.5rem"}}>
                            <button class="btn btn-secondary" onClick=${ms}>${o("select_all")}</button>
                            <button class="btn btn-secondary" onClick=${bs}>${o("deselect_all")}</button>
                            ${S.some(t=>t.selected)&&g`
                                <button class="btn btn-primary" style=${{background:"#eab308",border:"none",color:"#000"}} onClick=${()=>jt(S.filter(t=>t.selected))}>
                                     Upscale (${S.filter(t=>t.selected).length})
                                </button>
                            `}
                        </div>

                        <!-- Logo DP CONCEPT AI - Branding Style -->
                        <div style=${{position:"absolute",left:"50%",top:"50%",transform:"translate(-50%, -50%)",pointerEvents:"none",display:"flex",alignItems:"baseline",zIndex:1,gap:"0"}}>
                            <span style=${{fontSize:"2.2rem",fontWeight:800,background:"linear-gradient(180deg, #FFFFFF 0%, #B0C4DE 100%)",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent",backgroundClip:"text",letterSpacing:"-2px"}}>DP</span>
                            <span style=${{fontSize:"2.2rem",fontWeight:800,background:"linear-gradient(180deg, #60A5FA 0%, #818CF8 100%)",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent",backgroundClip:"text",letterSpacing:"-1px"}}>CONCEPT AI</span>
                            <span style=${{fontSize:"1rem",fontWeight:600,color:"#6B7280",marginLeft:"6px"}}>V3.8</span>
                        </div>

                        <input type="file" id="batch-bg-file-input" multiple accept="image/*" style=${{display:"none"}} onChange=${xs} />
                        <div style=${{display:"flex",gap:"0.5rem",alignItems:"center"}}>
                            <button class="btn btn-secondary" onClick=${()=>{var t;return(t=document.getElementById("batch-bg-file-input"))==null?void 0:t.click()}}>
                                <${ui} /> Thêm ảnh
                            </button>
                            <div style=${{display:"flex",alignItems:"center",gap:"4px",marginLeft:"8px"}}>
                                <span style=${{fontSize:"10px",opacity:.6}}>📷</span>
                                <input 
                                    type="range" 
                                    min="100" 
                                    max="500" 
                                    value=${ne} 
                                    onInput=${t=>zi(parseInt(t.target.value))}
                                    style=${{width:"80px",cursor:"pointer"}}
                                    title=${`Kích thước ảnh: ${ne}px`}
                                />
                                <span style=${{fontSize:"10px",opacity:.6}}>🖼️</span>
                            </div>
                            <button class="btn btn-primary" onClick=${ws} disabled=${S.filter(t=>t.generated&&t.selected).length===0||Se}>
                                <${hi} /> ${Se?"Đang nén...":o("download_all")}
                            </button>
                        </div>
                    </div>
                    ${At&&g`<div class="progress-container" style=${{flexShrink:0}}><div class="progress-bar"><div class="progress-bar-inner" style=${{width:`${he}%`}}></div><span class="progress-label">${he}%</span></div><span class="progress-counter">${Ii} / ${_i}</span></div>`}
                    <div class="batch-grid" style=${{flex:1,overflowY:"auto",alignContent:"flex-start",scrollbarWidth:"thin",gridTemplateColumns:`repeat(auto-fill, minmax(${ne}px, 1fr))`}}>

                        ${S.length===0?g`
                            <div class="upload-placeholder" onClick=${()=>{var t;return(t=document.getElementById("batch-bg-file-input"))==null?void 0:t.click()}} style=${{gridColumn:"1 / -1",height:"100%",minHeight:"400px",alignSelf:"stretch"}}>
                                <${ui} /><strong>${o("upload_multiple_prompt_title")}</strong>
                                <p style=${{opacity:.7,fontSize:"0.85em",marginTop:"0.5rem"}}>${o("upload_multiple_prompt_note")}</p>
                                <p style=${{opacity:.55,fontSize:"0.8em"}}>${o("upload_bg_prompt")||"Để thay nền hàng loạt bằng AI."}</p>
                            </div>
                        `:S.map((t,e)=>{const n=S.filter((s,l)=>s.generated&&l<e).length;return g`
                            <div class="batch-item ${t.selected?"selected":""} ${t.generated?"has-generated":""} ${t.status==="error"?"error":""}">
                                <div class="selection-checkbox" onClick=${()=>fs(t.id)}><div class="checkbox-visual"><${wi} /></div></div>
                                <div class="image-comparator" style=${{display:"block"}} onClick=${()=>t.generated&&Et(n)}>
                                    <div class="image-container ${t.generated?"has-result":""}">
                                        <img src=${t.generated||t.original} onMouseEnter=${s=>{t.generated&&(s.target.src=t.original)}} onMouseLeave=${s=>{t.generated&&(s.target.src=t.generated)}} />
                                        ${t.status==="processing"&&g`<${Cs} startTime=${t.processingStartTime} phase=${t.processingPhase} t=${o} />`}
                                        ${t.status==="done"&&g`<div class="batch-item-status-icon"><${wi} /></div>`}
                                        ${t.status==="error"&&g`<div class="error-badge" title="${t.error||o("error")}" onClick=${s=>{s.stopPropagation(),alert(t.error||o("error"))}}>${o("error")}</div>`}
                                         <${Ks} 
                                            generated=${t.generated} 
                                            originalFileSize=${t.file.size} 
                                        />
                                        
                                        <!-- Quality Label -->
                                        ${t.width&&t.height&&g`
                                            <div style=${{position:"absolute",top:"4px",left:"4px",background:"rgba(0,0,0,0.6)",color:"#fff",fontSize:"10px",padding:"2px 4px",borderRadius:"3px",backdropFilter:"blur(2px)",border:"1px solid rgba(255,255,255,0.2)"}}>
                                                ${Ys(t.width,t.height)}
                                            </div>
                                        `}

                                        <!-- Direct Download Button -->
                                        ${t.generated&&g`
                                            <button 
                                                type="button"
                                                title=${o("download")}
                                                onClick=${async s=>{var l;s.stopPropagation(),s.preventDefault();try{let r="png";const i=(l=t.file.name.split(".").pop())==null?void 0:l.toLowerCase();["jpg","jpeg"].includes(i||"")?r="jpg":i==="webp"&&(r="webp"),await Us(t.generated,`haipix_${t.file.name.split(".")[0]}_new.${r}`)}catch(r){console.error("Download failed:",r),y('Lỗi khi tải ảnh. Bạn có thể bấm vào ảnh để xem to rồi chuột phải chọn "Lưu hình ảnh thành..."'),setTimeout(()=>y(""),5e3)}}}
                                                style=${{position:"absolute",bottom:"8px",right:"8px",background:"rgba(56, 189, 248, 0.9)",border:"none",borderRadius:"50%",width:"32px",height:"32px",display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",color:"#fff",zIndex:40,boxShadow:"0 4px 12px rgba(0,0,0,0.4)",transition:"all 0.2s",transform:"scale(1)"}}
                                                onMouseEnter=${s=>{s.currentTarget.style.transform="scale(1.15)",s.currentTarget.style.background="#0ea5e9",s.currentTarget.style.boxShadow="0 6px 16px rgba(14, 165, 233, 0.4)"}}
                                                onMouseLeave=${s=>{s.currentTarget.style.transform="scale(1)",s.currentTarget.style.background="rgba(56, 189, 248, 0.9)",s.currentTarget.style.boxShadow="0 4px 12px rgba(0,0,0,0.4)"}}
                                            >
                                                <${hi} style=${{width:"16px",height:"16px"}} />
                                            </button>
                                        `}
                                    </div>
                                </div>
                                 <div class="batch-item-actions">
                                    <button class="batch-item-btn" title=${o("save_to_album")} onClick=${s=>{var l;s.stopPropagation(),t.generated&&Gt({url:t.generated,prompt:((l=t.settings)==null?void 0:l.prompt)||"",settings:t.settings})}} disabled=${!t.generated}><${fi} /></button>
                                    <button class="batch-item-btn" title=${o("regenerate")} onClick=${()=>vs(t.id)}><${Es} /></button>
                                    <button class="batch-item-btn" title="Nâng cao chất lượng (Upscale)" onClick=${()=>jt([t])}><${Ws} /></button>
                                    <button class="batch-item-btn" title=${o("use_this_image_action")} onClick=${()=>{t.generated&&(j(t.generated),G())}}><${js} /></button>
                                    <button class="batch-item-btn" title=${o("delete")} onClick=${()=>Ss(t.id)}><${Os} /></button>
                                </div>
                            </div>`})}
                    </div>
                </div>
                <${Ls} t=${o} style=${{position:"absolute",bottom:"1rem",right:"1rem",zIndex:10,margin:0,background:"rgba(0,0,0,0.5)",border:"1px solid rgba(255,255,255,0.1)",backdropFilter:"blur(4px)",fontSize:"10px",padding:"4px 8px",borderRadius:"8px",color:"#fff",boxShadow:"0 4px 12px rgba(0,0,0,0.3)"}} />
            </div>

            <!-- Right Resize Handle -->
            <div 
                onMouseDown=${()=>De(!0)} 
                class="panel-resizer"
                style=${{width:"100%",position:"relative",zIndex:100,display:pt?"flex":"none",justifyContent:"center",cursor:"col-resize"}}
            >
                <!-- Visual divider -->
                <div style=${{width:"1px",background:it?"var(--primary)":"#222",height:"100%"}}></div>
                <!-- Hit area (Invisible but wider) -->
                <div style=${{position:"absolute",top:0,bottom:0,width:"16px",cursor:"col-resize"}}></div>
            </div>


            <!-- Save Concept Selection Modal -->
            ${Tt&&g`
                <${qs} 
                    targetImages=${Tt.map(t=>({id:t.id,url:t.generated||t.original}))}
                    models=${Li}
                    onClose=${()=>jt(null)}
                    onConfirm=${Di}
                    t=${o}
                />
            `}
            <!-- Edit Prompts Modal -->
            ${p&&g`
                <div style=${{position:"fixed",top:0,left:0,right:0,bottom:0,background:"rgba(0,0,0,0.85)",zIndex:10001,display:"flex",alignItems:"center",justifyContent:"center"}} onClick=${()=>$(null)}>
                    <div style=${{background:"#1f1f1f",padding:"24px",borderRadius:"12px",width:"600px",maxWidth:"95%",border:"1px solid #333",display:"flex",flexDirection:"column",gap:"20px"}} onClick=${t=>t.stopPropagation()}>
                        <div style=${{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                            <h3 style=${{margin:0,color:"#fff",fontSize:"18px"}}>Chỉnh sửa câu lệnh mẫu</h3>
                            <button onClick=${()=>$(null)} style=${{background:"transparent",border:"none",color:"#888",cursor:"pointer",fontSize:"20px"}}>×</button>
                        </div>

                        <div style=${{display:"flex",gap:"15px",alignItems:"flex-start",background:"#2a2a2a",padding:"15px",borderRadius:"8px"}}>
                            <label style=${{cursor:"pointer",display:"flex",flexDirection:"column",gap:"5px",alignItems:"center",flexShrink:0}}>
                                <img src=${p.thumbnail} style=${{width:"80px",height:"106px",objectFit:"cover",borderRadius:"4px",border:"1px solid #444"}} />
                                <span style=${{fontSize:"10px",color:"#fff",background:"#444",padding:"2px 6px",borderRadius:"4px"}}>📷 Thay ảnh</span>
                                <input 
                                    type="file" 
                                    accept="image/*" 
                                    style=${{display:"none"}} 
                                    onChange=${async t=>{var s;const e=(s=t.target.files)==null?void 0:s[0];if(!e)return;const n=new FileReader;n.onload=async l=>{const r=l.target.result,i=await de(r);$({...p,thumbnail:i})},n.readAsDataURL(e)}}
                                />
                            </label>
                            <div style=${{flex:1,display:"flex",flexDirection:"column",gap:"10px"}}>
                                <div style=${{display:"flex",flexDirection:"column",gap:"4px"}}>
                                    <label style=${{color:"#888",fontSize:"11px",fontWeight:"bold"}}>Tên mẫu concept</label>
                                    <input 
                                        style=${{background:"#111",border:"1px solid #444",color:"#fff",padding:"6px 10px",borderRadius:"4px",fontSize:"14px"}}
                                        value=${p.name||""}
                                        onInput=${t=>$({...p,name:t.currentTarget.value})}
                                    />
                                </div>
                                <div style=${{display:"flex",flexDirection:"column",gap:"4px"}}>
                                    <label style=${{color:"#888",fontSize:"11px",fontWeight:"bold"}}>Ghi chú / Lưu ý</label>
                                    <textarea 
                                        style=${{background:"#111",border:"1px solid #444",color:"#fff",padding:"6px 10px",borderRadius:"4px",fontSize:"12px",minHeight:"40px",resize:"vertical"}}
                                        value=${p.notes||""}
                                        onInput=${t=>$({...p,notes:t.currentTarget.value})}
                                        placeholder="Ví dụ: Dùng tốt cho ảnh ngoại cảnh, màu retro..."
                                    ></textarea>
                                </div>
                            </div>
                        </div>

                        <div style=${{display:"flex",flexDirection:"column",gap:"15px",maxHeight:"60vh",overflowY:"auto",paddingRight:"5px"}}>
                            <!-- Wide Shot -->
                            <div style=${{display:"flex",flexDirection:"column",gap:"6px"}}>
                                <div style=${{display:"flex",alignItems:"center",gap:"8px",color:"#00d1b2",fontSize:"13px",fontWeight:"bold"}}>
                                    <${mi} style=${{width:"16px",height:"16px"}} /> Cảnh rộng
                                </div>
                                <textarea 
                                    style=${{background:"#111",border:"1px solid #333",borderRadius:"6px",color:"#fff",padding:"10px",fontSize:"13px",width:"100%",minHeight:"80px",resize:"vertical"}}
                                    value=${((jn=(Wn=p.shotSettings)==null?void 0:Wn.wide)==null?void 0:jn.prompt)||""}
                                    onInput=${t=>{const e={...p},n={...e.shotSettings||{}};n.wide={...n.wide||e.settings||{},prompt:t.currentTarget.value},e.shotSettings=n,$(e)}}
                                ></textarea>

                                <!-- Technical Options for Wide -->
                                <${X} title=${g`<span style=${{fontSize:"11px",opacity:.8}}>⚙️ Thông số kỹ thuật</span>`} initialOpen=${!1}>
                                    <div style=${{display:"flex",flexDirection:"column",gap:"12px",padding:"10px",background:"#1a1a1a",borderRadius:"6px",marginTop:"5px"}}>
                                        <div style=${{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                                            <label style=${{fontSize:"12px",display:"flex",alignItems:"center",gap:"6px",cursor:"pointer"}}>
                                                <input type="checkbox" checked=${(Un=(On=p.shotSettings)==null?void 0:On.wide)==null?void 0:Un.useLensBlur} onChange=${t=>{const e={...p},n={...e.shotSettings||{}};n.wide={...n.wide||e.settings||{},useLensBlur:t.currentTarget.checked},e.shotSettings=n,$(e)}} />
                                                Xoá phông (Lens Blur)
                                            </label>
                                            <input type="range" min="0" max="10" value=${((Hn=(Nn=p.shotSettings)==null?void 0:Nn.wide)==null?void 0:Hn.lensBlur)||0} disabled=${!((Gn=(Vn=p.shotSettings)==null?void 0:Vn.wide)!=null&&Gn.useLensBlur)} onInput=${t=>{const e={...p},n={...e.shotSettings||{}};n.wide={...n.wide||{},lensBlur:parseInt(t.currentTarget.value)},e.shotSettings=n,$(e)}} />
                                        </div>

                                        <div style=${{borderTop:"1px solid #333",paddingTop:"10px"}}>
                                            <label style=${{fontSize:"12px",display:"flex",alignItems:"center",gap:"6px",cursor:"pointer",marginBottom:"8px"}}>
                                                <input type="checkbox" checked=${(Yn=(Kn=p.shotSettings)==null?void 0:Kn.wide)==null?void 0:Yn.useRimLight} onChange=${t=>{const e={...p},n={...e.shotSettings||{}};n.wide={...n.wide||e.settings||{},useRimLight:t.currentTarget.checked},e.shotSettings=n,$(e)}} />
                                                Ánh sáng viền (Rim Light)
                                            </label>
                                            ${((Xn=(qn=p.shotSettings)==null?void 0:qn.wide)==null?void 0:Xn.useRimLight)&&g`
                                                <div style=${{display:"flex",gap:"10px",paddingLeft:"20px"}}>
                                                    <select style=${{background:"#222",color:"#fff",border:"1px solid #444",fontSize:"11px",padding:"2px"}} value=${(Jn=(Qn=p.shotSettings)==null?void 0:Qn.wide)==null?void 0:Jn.rimLightDirection} onChange=${t=>{const e={...p},n={...e.shotSettings||{}};n.wide={...n.wide||{},rimLightDirection:t.currentTarget.value},e.shotSettings=n,$(e)}}>
                                                        <option value="left">${o("direction_left")}</option>
                                                        <option value="right">${o("direction_right")}</option>
                                                        <option value="top">${o("direction_top")}</option>
                                                        <option value="bottom">${o("direction_bottom")}</option>
                                                    </select>
                                                    <select style=${{background:"#222",color:"#fff",border:"1px solid #444",fontSize:"11px",padding:"2px"}} value=${(to=(Zn=p.shotSettings)==null?void 0:Zn.wide)==null?void 0:to.rimLightIntensity} onChange=${t=>{const e={...p},n={...e.shotSettings||{}};n.wide={...n.wide||{},rimLightIntensity:t.currentTarget.value},e.shotSettings=n,$(e)}}>
                                                        <option value="strong">${o("intensity_strong")}</option>
                                                        <option value="medium">${o("intensity_medium")}</option>
                                                        <option value="weak">${o("intensity_weak")}</option>
                                                    </select>
                                                </div>
                                            `}
                                        </div>

                                        <div style=${{borderTop:"1px solid #333",paddingTop:"10px"}}>
                                            <select style=${{width:"100%",background:"#222",color:"#fff",border:"1px solid #444",fontSize:"12px",padding:"4px"}} value=${((no=(eo=p.shotSettings)==null?void 0:eo.wide)==null?void 0:no.colorSyncMode)||"none"} onChange=${t=>{const e={...p},n={...e.shotSettings||{}};n.wide={...n.wide||e.settings||{},colorSyncMode:t.currentTarget.value},e.shotSettings=n,$(e)}}>
                                                <option value="none">Không đồng bộ màu</option>
                                                <option value="sync_character_scene">Đồng bộ Nhân vật & Cảnh</option>
                                                <option value="ref_bg_follows_subject">Nền theo chủ thể</option>
                                                <option value="subject_follows_ref_bg">Chủ thể theo nền</option>
                                            </select>
                                        </div>
                                        <div style=${{borderTop:"1px solid #333",paddingTop:"10px"}}>
                                            <label style=${{fontSize:"12px",display:"flex",alignItems:"center",gap:"6px",cursor:"pointer"}}>
                                                <input type="checkbox" checked=${(io=(oo=p.shotSettings)==null?void 0:oo.wide)==null?void 0:io.keepPose} onChange=${t=>{const e={...p},n={...e.shotSettings||{}};n.wide={...n.wide||e.settings||{},keepPose:t.currentTarget.checked},e.shotSettings=n,$(e)}} />
                                                Giữ nguyên dáng (Keep Pose)
                                            </label>
                                        </div>
                                    </div>
                                </${X}>
                            </div>

                            <!-- Full Shot -->
                            <div style=${{display:"flex",flexDirection:"column",gap:"6px",marginTop:"15px",borderTop:"1px solid #333",paddingTop:"15px"}}>
                                <div style=${{display:"flex",alignItems:"center",gap:"8px",color:"#00d1b2",fontSize:"13px",fontWeight:"bold"}}>
                                    <${bi} style=${{width:"16px",height:"16px"}} /> Toàn thân
                                </div>
                                <textarea 
                                    style=${{background:"#111",border:"1px solid #333",borderRadius:"6px",color:"#fff",padding:"10px",fontSize:"13px",width:"100%",minHeight:"80px",resize:"vertical"}}
                                    value=${((ao=(so=p.shotSettings)==null?void 0:so.full)==null?void 0:ao.prompt)||""}
                                    onInput=${t=>{const e={...p};e.shotSettings||(e.shotSettings={}),e.shotSettings.full||(e.shotSettings.full={...e.settings}),e.shotSettings.full={...e.shotSettings.full,prompt:t.currentTarget.value},$(e)}}
                                ></textarea>

                                <!-- Technical Options for Full -->
                                <${X} title=${g`<span style=${{fontSize:"11px",opacity:.8}}>⚙️ Thông số kỹ thuật</span>`} initialOpen=${!1}>
                                    <div style=${{display:"flex",flexDirection:"column",gap:"12px",padding:"10px",background:"#1a1a1a",borderRadius:"6px",marginTop:"5px"}}>
                                        <div style=${{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                                            <label style=${{fontSize:"12px",display:"flex",alignItems:"center",gap:"6px",cursor:"pointer"}}>
                                                <input type="checkbox" checked=${(lo=(ro=p.shotSettings)==null?void 0:ro.full)==null?void 0:lo.useLensBlur} onChange=${t=>{const e={...p},n={...e.shotSettings||{}};n.full={...n.full||e.settings||{},useLensBlur:t.currentTarget.checked},e.shotSettings=n,$(e)}} />
                                                Xoá phông (Lens Blur)
                                            </label>
                                            <input type="range" min="0" max="10" value=${((co=(po=p.shotSettings)==null?void 0:po.full)==null?void 0:co.lensBlur)||0} disabled=${!((uo=(go=p.shotSettings)==null?void 0:go.full)!=null&&uo.useLensBlur)} onInput=${t=>{const e={...p},n={...e.shotSettings||{}};n.full={...n.full||{},lensBlur:parseInt(t.currentTarget.value)},e.shotSettings=n,$(e)}} />
                                        </div>

                                        <div style=${{borderTop:"1px solid #333",paddingTop:"10px"}}>
                                            <label style=${{fontSize:"12px",display:"flex",alignItems:"center",gap:"6px",cursor:"pointer",marginBottom:"8px"}}>
                                                <input type="checkbox" checked=${(fo=(ho=p.shotSettings)==null?void 0:ho.full)==null?void 0:fo.useRimLight} onChange=${t=>{const e={...p},n={...e.shotSettings||{}};n.full={...n.full||e.settings||{},useRimLight:t.currentTarget.checked},e.shotSettings=n,$(e)}} />
                                                Ánh sáng viền (Rim Light)
                                            </label>
                                            ${((bo=(mo=p.shotSettings)==null?void 0:mo.full)==null?void 0:bo.useRimLight)&&g`
                                                <div style=${{display:"flex",gap:"10px",paddingLeft:"20px"}}>
                                                    <select style=${{background:"#222",color:"#fff",border:"1px solid #444",fontSize:"11px",padding:"2px"}} value=${($o=(xo=p.shotSettings)==null?void 0:xo.full)==null?void 0:$o.rimLightDirection} onChange=${t=>{const e={...p},n={...e.shotSettings||{}};n.full={...n.full||{},rimLightDirection:t.currentTarget.value},e.shotSettings=n,$(e)}}>
                                                        <option value="left">${o("direction_left")}</option>
                                                        <option value="right">${o("direction_right")}</option>
                                                        <option value="top">${o("direction_top")}</option>
                                                        <option value="bottom">${o("direction_bottom")}</option>
                                                    </select>
                                                    <select style=${{background:"#222",color:"#fff",border:"1px solid #444",fontSize:"11px",padding:"2px"}} value=${(vo=(yo=p.shotSettings)==null?void 0:yo.full)==null?void 0:vo.rimLightIntensity} onChange=${t=>{const e={...p},n={...e.shotSettings||{}};n.full={...n.full||{},rimLightIntensity:t.currentTarget.value},e.shotSettings=n,$(e)}}>
                                                        <option value="strong">${o("intensity_strong")}</option>
                                                        <option value="medium">${o("intensity_medium")}</option>
                                                        <option value="weak">${o("intensity_weak")}</option>
                                                    </select>
                                                </div>
                                            `}
                                        </div>

                                        <div style=${{borderTop:"1px solid #333",paddingTop:"10px"}}>
                                            <label style=${{fontSize:"11px",color:"#888",display:"block",marginBottom:"4px"}}>Đồng bộ màu sắc (Color Sync)</label>
                                            <select style=${{width:"100%",background:"#222",color:"#fff",border:"1px solid #444",fontSize:"12px",padding:"4px"}} value=${((wo=(So=p.shotSettings)==null?void 0:So.full)==null?void 0:wo.colorSyncMode)||"none"} onChange=${t=>{const e={...p},n={...e.shotSettings||{}};n.full={...n.full||e.settings||{},colorSyncMode:t.currentTarget.value},e.shotSettings=n,$(e)}}>
                                                <option value="none">Không đồng bộ</option>
                                                <option value="sync_character_scene">Nhân vật & Cảnh</option>
                                                <option value="ref_bg_follows_subject">Nền theo chủ thể</option>
                                                <option value="subject_follows_ref_bg">Chủ thể theo nền</option>
                                            </select>
                                        </div>

                                        <div style=${{borderTop:"1px solid #333",paddingTop:"10px"}}>
                                            <label style=${{fontSize:"12px",display:"flex",alignItems:"center",gap:"6px",cursor:"pointer"}}>
                                                <input type="checkbox" checked=${(Io=(ko=p.shotSettings)==null?void 0:ko.full)==null?void 0:Io.keepPose} onChange=${t=>{const e={...p},n={...e.shotSettings||{}};n.full={...n.full||e.settings||{},keepPose:t.currentTarget.checked},e.shotSettings=n,$(e)}} />
                                                Giữ nguyên dáng (Keep Pose)
                                            </label>
                                        </div>
                                    </div>
                                </${X}>
                            </div>

                            <!-- Half Shot -->
                            <div style=${{display:"flex",flexDirection:"column",gap:"6px"}}>
                                <div style=${{display:"flex",alignItems:"center",gap:"8px",color:"#00d1b2",fontSize:"13px",fontWeight:"bold"}}>
                                    <${xi} style=${{width:"16px",height:"16px"}} /> Bán thân
                                </div>
                                <textarea 
                                    style=${{background:"#111",border:"1px solid #333",borderRadius:"6px",color:"#fff",padding:"10px",fontSize:"13px",width:"100%",minHeight:"80px",resize:"vertical"}}
                                    value=${((Co=(_o=p.shotSettings)==null?void 0:_o.half)==null?void 0:Co.prompt)||""}
                                    onInput=${t=>{const e={...p},n={...e.shotSettings||{}};n.half={...n.half||e.settings||{},prompt:t.currentTarget.value},e.shotSettings=n,$(e)}}
                                ></textarea>

                                <!-- Technical Options for Half -->
                                <${X} title=${g`<span style=${{fontSize:"11px",opacity:.8}}>⚙️ Thông số kỹ thuật</span>`} initialOpen=${!1}>
                                    <div style=${{display:"flex",flexDirection:"column",gap:"12px",padding:"10px",background:"#1a1a1a",borderRadius:"6px",marginTop:"5px"}}>
                                        <div style=${{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                                            <label style=${{fontSize:"12px",display:"flex",alignItems:"center",gap:"6px",cursor:"pointer"}}>
                                                <input type="checkbox" checked=${(To=(Ao=p.shotSettings)==null?void 0:Ao.half)==null?void 0:To.useLensBlur} onChange=${t=>{const e={...p},n={...e.shotSettings||{}};n.half={...n.half||e.settings||{},useLensBlur:t.currentTarget.checked},e.shotSettings=n,$(e)}} />
                                                Xoá phông (Lens Blur)
                                            </label>
                                            <input type="range" min="0" max="10" value=${((zo=(Ro=p.shotSettings)==null?void 0:Ro.half)==null?void 0:zo.lensBlur)||0} disabled=${!((Po=(Lo=p.shotSettings)==null?void 0:Lo.half)!=null&&Po.useLensBlur)} onInput=${t=>{const e={...p},n={...e.shotSettings||{}};n.half={...n.half||{},lensBlur:parseInt(t.currentTarget.value)},e.shotSettings=n,$(e)}} />
                                        </div>

                                        <div style=${{borderTop:"1px solid #333",paddingTop:"10px"}}>
                                            <label style=${{fontSize:"12px",display:"flex",alignItems:"center",gap:"6px",cursor:"pointer",marginBottom:"8px"}}>
                                                <input type="checkbox" checked=${(Do=(Bo=p.shotSettings)==null?void 0:Bo.half)==null?void 0:Do.useRimLight} onChange=${t=>{const e={...p},n={...e.shotSettings||{}};n.half={...n.half||e.settings||{},useRimLight:t.currentTarget.checked},e.shotSettings=n,$(e)}} />
                                                Ánh sáng viền (Rim Light)
                                            </label>
                                            ${((Fo=(Mo=p.shotSettings)==null?void 0:Mo.half)==null?void 0:Fo.useRimLight)&&g`
                                                <div style=${{display:"flex",gap:"10px",paddingLeft:"20px"}}>
                                                    <select style=${{background:"#222",color:"#fff",border:"1px solid #444",fontSize:"11px",padding:"2px"}} value=${(Wo=(Eo=p.shotSettings)==null?void 0:Eo.half)==null?void 0:Wo.rimLightDirection} onChange=${t=>{const e={...p},n={...e.shotSettings||{}};n.half={...n.half||{},rimLightDirection:t.currentTarget.value},e.shotSettings=n,$(e)}}>
                                                        <option value="left">${o("direction_left")}</option>
                                                        <option value="right">${o("direction_right")}</option>
                                                        <option value="top">${o("direction_top")}</option>
                                                        <option value="bottom">${o("direction_bottom")}</option>
                                                    </select>
                                                    <select style=${{background:"#222",color:"#fff",border:"1px solid #444",fontSize:"11px",padding:"2px"}} value=${(Oo=(jo=p.shotSettings)==null?void 0:jo.half)==null?void 0:Oo.rimLightIntensity} onChange=${t=>{const e={...p},n={...e.shotSettings||{}};n.half={...n.half||{},rimLightIntensity:t.currentTarget.value},e.shotSettings=n,$(e)}}>
                                                        <option value="strong">${o("intensity_strong")}</option>
                                                        <option value="medium">${o("intensity_medium")}</option>
                                                        <option value="weak">${o("intensity_weak")}</option>
                                                    </select>
                                                </div>
                                            `}
                                        </div>

                                        <div style=${{borderTop:"1px solid #333",paddingTop:"10px"}}>
                                            <select style=${{width:"100%",background:"#222",color:"#fff",border:"1px solid #444",fontSize:"12px",padding:"4px"}} value=${((No=(Uo=p.shotSettings)==null?void 0:Uo.half)==null?void 0:No.colorSyncMode)||"none"} onChange=${t=>{const e={...p},n={...e.shotSettings||{}};n.half={...n.half||e.settings||{},colorSyncMode:t.currentTarget.value},e.shotSettings=n,$(e)}}>
                                                <option value="none">Không đồng bộ màu</option>
                                                <option value="sync_character_scene">Đồng bộ Nhân vật & Cảnh</option>
                                                <option value="ref_bg_follows_subject">Nền theo chủ thể</option>
                                                <option value="subject_follows_ref_bg">Chủ thể theo nền</option>
                                            </select>
                                        </div>

                                        <div style=${{borderTop:"1px solid #333",paddingTop:"10px"}}>
                                            <label style=${{fontSize:"12px",display:"flex",alignItems:"center",gap:"6px",cursor:"pointer"}}>
                                                <input type="checkbox" checked=${(Vo=(Ho=p.shotSettings)==null?void 0:Ho.half)==null?void 0:Vo.keepPose} onChange=${t=>{const e={...p},n={...e.shotSettings||{}};n.half={...n.half||e.settings||{},keepPose:t.currentTarget.checked},e.shotSettings=n,$(e)}} />
                                                Giữ nguyên dáng (Keep Pose)
                                            </label>
                                        </div>
                                    </div>
                                </${X}>
                            </div>

                            <!-- Closeup Shot -->
                            <div style=${{display:"flex",flexDirection:"column",gap:"6px"}}>
                                <div style=${{display:"flex",alignItems:"center",gap:"8px",color:"#00d1b2",fontSize:"13px",fontWeight:"bold"}}>
                                    <${$i} style=${{width:"16px",height:"16px"}} /> Cận cảnh
                                </div>
                                <textarea 
                                    style=${{background:"#111",border:"1px solid #333",borderRadius:"6px",color:"#fff",padding:"10px",fontSize:"13px",width:"100%",minHeight:"80px",resize:"vertical"}}
                                    value=${((Ko=(Go=p.shotSettings)==null?void 0:Go.closeup)==null?void 0:Ko.prompt)||""}
                                    onInput=${t=>{const e={...p},n={...e.shotSettings||{}};n.closeup={...n.closeup||e.settings||{},prompt:t.currentTarget.value},e.shotSettings=n,$(e)}}
                                ></textarea>

                                <!-- Technical Options for Closeup -->
                                <${X} title=${g`<span style=${{fontSize:"11px",opacity:.8}}>⚙️ Thông số kỹ thuật</span>`} initialOpen=${!1}>
                                    <div style=${{display:"flex",flexDirection:"column",gap:"12px",padding:"10px",background:"#1a1a1a",borderRadius:"6px",marginTop:"5px"}}>
                                        <div style=${{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                                            <label style=${{fontSize:"12px",display:"flex",alignItems:"center",gap:"6px",cursor:"pointer"}}>
                                                <input type="checkbox" checked=${(qo=(Yo=p.shotSettings)==null?void 0:Yo.closeup)==null?void 0:qo.useLensBlur} onChange=${t=>{const e={...p},n={...e.shotSettings||{}};n.closeup={...n.closeup||e.settings||{},useLensBlur:t.currentTarget.checked},e.shotSettings=n,$(e)}} />
                                                Xoá phông (Lens Blur)
                                            </label>
                                            <input type="range" min="0" max="10" value=${((Qo=(Xo=p.shotSettings)==null?void 0:Xo.closeup)==null?void 0:Qo.lensBlur)||0} disabled=${!((Zo=(Jo=p.shotSettings)==null?void 0:Jo.closeup)!=null&&Zo.useLensBlur)} onInput=${t=>{const e={...p},n={...e.shotSettings||{}};n.closeup={...n.closeup||{},lensBlur:parseInt(t.currentTarget.value)},e.shotSettings=n,$(e)}} />
                                        </div>

                                        <div style=${{borderTop:"1px solid #333",paddingTop:"10px"}}>
                                            <label style=${{fontSize:"12px",display:"flex",alignItems:"center",gap:"6px",cursor:"pointer",marginBottom:"8px"}}>
                                                <input type="checkbox" checked=${(ei=(ti=p.shotSettings)==null?void 0:ti.closeup)==null?void 0:ei.useRimLight} onChange=${t=>{const e={...p},n={...e.shotSettings||{}};n.closeup={...n.closeup||e.settings||{},useRimLight:t.currentTarget.checked},e.shotSettings=n,$(e)}} />
                                                Ánh sáng viền (Rim Light)
                                            </label>
                                            ${((oi=(ni=p.shotSettings)==null?void 0:ni.closeup)==null?void 0:oi.useRimLight)&&g`
                                                <div style=${{display:"flex",gap:"10px",paddingLeft:"20px"}}>
                                                    <select style=${{background:"#222",color:"#fff",border:"1px solid #444",fontSize:"11px",padding:"2px"}} value=${(si=(ii=p.shotSettings)==null?void 0:ii.closeup)==null?void 0:si.rimLightDirection} onChange=${t=>{const e={...p},n={...e.shotSettings||{}};n.closeup={...n.closeup||{},rimLightDirection:t.currentTarget.value},e.shotSettings=n,$(e)}}>
                                                        <option value="left">${o("direction_left")}</option>
                                                        <option value="right">${o("direction_right")}</option>
                                                        <option value="top">${o("direction_top")}</option>
                                                        <option value="bottom">${o("direction_bottom")}</option>
                                                    </select>
                                                    <select style=${{background:"#222",color:"#fff",border:"1px solid #444",fontSize:"11px",padding:"2px"}} value=${(ri=(ai=p.shotSettings)==null?void 0:ai.closeup)==null?void 0:ri.rimLightIntensity} onChange=${t=>{const e={...p},n={...e.shotSettings||{}};n.closeup={...n.closeup||{},rimLightIntensity:t.currentTarget.value},e.shotSettings=n,$(e)}}>
                                                        <option value="strong">${o("intensity_strong")}</option>
                                                        <option value="medium">${o("intensity_medium")}</option>
                                                        <option value="weak">${o("intensity_weak")}</option>
                                                    </select>
                                                </div>
                                            `}
                                        </div>

                                        <div style=${{borderTop:"1px solid #333",paddingTop:"10px"}}>
                                            <select style=${{width:"100%",background:"#222",color:"#fff",border:"1px solid #444",fontSize:"12px",padding:"4px"}} value=${((di=(li=p.shotSettings)==null?void 0:li.closeup)==null?void 0:di.colorSyncMode)||"none"} onChange=${t=>{const e={...p},n={...e.shotSettings||{}};n.closeup={...n.closeup||e.settings||{},colorSyncMode:t.currentTarget.value},e.shotSettings=n,$(e)}}>
                                                <option value="none">Không đồng bộ màu</option>
                                                <option value="sync_character_scene">Đồng bộ Nhân vật & Cảnh</option>
                                                <option value="ref_bg_follows_subject">Nền theo chủ thể</option>
                                                <option value="subject_follows_ref_bg">Chủ thể theo nền</option>
                                            </select>
                                        </div>

                                        <div style=${{borderTop:"1px solid #333",paddingTop:"10px"}}>
                                            <label style=${{fontSize:"12px",display:"flex",alignItems:"center",gap:"6px",cursor:"pointer"}}>
                                                <input type="checkbox" checked=${(ci=(pi=p.shotSettings)==null?void 0:pi.closeup)==null?void 0:ci.keepPose} onChange=${t=>{const e={...p},n={...e.shotSettings||{}};n.closeup={...n.closeup||e.settings||{},keepPose:t.currentTarget.checked},e.shotSettings=n,$(e)}} />
                                                Giữ nguyên dáng (Keep Pose)
                                            </label>
                                        </div>
                                    </div>
                                </${X}>
                            </div>

                        </div>

                        <div style=${{display:"flex",justifyContent:"flex-end",gap:"12px"}}>
                            <button class="btn btn-secondary" onClick=${()=>$(null)}>${o("cancel")}</button>
                            <button class="btn btn-primary" onClick=${()=>{L(t=>t.map(e=>e.id===p.id?p:e)),$(null),y(o("album_save_success")),setTimeout(()=>y(""),3e3)}}>${o("save")}</button>
                        </div>
                    </div>
                </div>
            `}

            ${K&&g`
                <div style=${{position:"fixed",top:0,left:0,right:0,bottom:0,background:"rgba(0,0,0,0.8)",zIndex:1e4,display:"flex",alignItems:"center",justifyContent:"center"}} onClick=${()=>Gt(null)}>
                    <div style=${{background:"#1f1f1f",padding:"24px",borderRadius:"12px",width:"450px",maxWidth:"95%",border:"1px solid #333"}} onClick=${t=>t.stopPropagation()}>
                        <h3 style=${{marginTop:0,color:"#fff",fontSize:"18px",marginBottom:"20px"}}>${o("album_save_option_title")}</h3>
                        
                        <div style=${{display:"flex",flexDirection:"column",gap:"12px"}}>
                            <div style=${{background:"#111",padding:"12px",borderRadius:"8px",border:"1px solid #333"}}>
                                <label style=${{display:"block",fontSize:"11px",color:"#888",marginBottom:"8px",fontWeight:"bold"}}>Tên mẫu mới (Nếu lưu mẫu mới)</label>
                                <input 
                                    type="text" 
                                    class="form-control" 
                                    placeholder="Ví dụ: Concept Retro Đông..." 
                                    value=${ze} 
                                    onInput=${t=>Le(t.currentTarget.value)}
                                    style=${{background:"#1a1a1a",color:"#fff",border:"1px solid #444",height:"40px",fontSize:"14px"}}
                                />
                            </div>

                            <button class="btn btn-primary" style=${{padding:"12px",fontSize:"15px",background:"#00d1b2",border:"none",borderRadius:"6px",color:"#fff",cursor:"pointer",fontWeight:"bold"}} onClick=${()=>ce(K.url,K.prompt,K.settings,void 0,ze)}>
                                ✨ ${o("album_save_new")}
                            </button>
                            
                            <div style=${{height:"1px",background:"#333",margin:"10px 0"}}></div>
                            
                            <button class="btn btn-secondary" style=${{padding:"12px",fontSize:"15px",background:"#333",border:"1px solid #444",borderRadius:"6px",color:"#fff",cursor:"pointer"}} onClick=${()=>Oi(!Re)}>
                                📂 ${o("album_save_append")}
                            </button>
                            
                            ${Re&&g`
                                <div style=${{marginTop:"10px",maxHeight:"250px",overflowY:"auto",background:"#111",borderRadius:"8px",padding:"8px",border:"1px solid #333"}}>
                                    <div style=${{fontSize:"11px",color:"#888",marginBottom:"8px",padding:"0 4px"}}>${o("album_save_append_note")}</div>
                                    ${z.slice(0,10).map(t=>g`
                                        <div 
                                            style=${{display:"flex",alignItems:"center",gap:"10px",padding:"8px",borderRadius:"6px",cursor:"pointer",border:"1px solid transparent",transition:"background 0.2s"}}
                                            onMouseOver=${e=>e.currentTarget.style.background="#222"}
                                            onMouseOut=${e=>e.currentTarget.style.background="transparent"}
                                            onClick=${()=>ce(K.url,K.prompt,K.settings,t.id)}
                                        >
                                            <img src=${t.thumbnail} style=${{width:"40px",height:"54px",objectFit:"contain",background:"#000",borderRadius:"4px"}} />
                                            <div style=${{flex:1,minWidth:0}}>
                                                <div style=${{fontSize:"12px",color:"#fff",fontWeight:"bold",whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>${t.name||"Mẫu không tên"}</div>
                                                <div style=${{fontSize:"10px",color:"#666",whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>${t.prompt}</div>
                                            </div>
                                        </div>
                                    `)}
                                </div>
                            `}

                            ${vt&&g`
                                <div style=${{marginTop:"12px",padding:"10px",background:"rgba(0, 209, 178, 0.1)",borderRadius:"8px",border:"1px dashed #00d1b2"}}>
                                    <div style=${{fontSize:"12px",color:"#00d1b2",fontWeight:"bold",marginBottom:"8px"}}>Mẫu đang được chọn:</div>
                                    ${(()=>{const t=z.find(e=>e.id===vt);return t?g`
                                            <div 
                                                style=${{display:"flex",alignItems:"center",gap:"10px",cursor:"pointer"}}
                                                onClick=${()=>ce(K.url,K.prompt,K.settings,t.id)}
                                            >
                                                <img src=${t.thumbnail} style=${{width:"40px",height:"54px",objectFit:"contain",background:"#000",borderRadius:"4px"}} />
                                                <div style=${{flex:1,minWidth:0}}>
                                                    <div style=${{fontSize:"12px",color:"#fff",fontWeight:"bold"}}>${t.name||"Mẫu không tên"}</div>
                                                    <div style=${{fontSize:"10px",color:"#888"}}>Bấm vào đây để bổ sung nhanh góc chụp hiện tại</div>
                                                </div>
                                            </div>
                                        `:null})()}
                                </div>
                            `}
                        </div>
                        
                        <div style=${{marginTop:"20px",display:"flex",justifyContent:"flex-end"}}>
                            <button style=${{background:"transparent",border:"none",color:"#888",cursor:"pointer",fontSize:"14px"}} onClick=${()=>Gt(null)}>${o("cancel")}</button>
                        </div>
                    </div>
                </div>
            `}

            <!-- Right Panel with Toggle -->
            <div style=${{position:"relative",width:"100%",height:"100%"}}>
                <!-- Collapse Right Toggle Button -->
                <button 
                    onClick=${()=>ve(!pt)}
                    style=${{position:"absolute",top:"50%",left:"-12px",transform:"translateY(-50%)",width:"24px",height:"48px",background:"#333",border:"1px solid #555",borderRight:"none",borderRadius:"8px 0 0 8px",cursor:"pointer",zIndex:150,display:"flex",alignItems:"center",justifyContent:"center",color:"#aaa",fontSize:"12px",transition:"background 0.2s"}}
                    title=${pt?"Thu gọn Menu":"Mở rộng Menu"}
                >
                    ${pt?"»":"«"}
                </button>
                
                ${pt?g`
                    <div class="batch-right-panel-container">
                        <${As} settings=${f} setSettings=${N} onGenerate=${Xe} generating=${At} hasImage=${Jt>0} buttonText=${Qe} isBatch=${!0} onBackToHome=${G} onChooseAnotherImage=${()=>{var t;return(t=document.getElementById("batch-bg-file-input"))==null?void 0:t.click()}} t=${o} language=${mt} setLanguage=${dt} onLaunchRefCrop=${ls} onLaunchDetailRefCrop=${ds} subjectImageUploaded=${S.length>0} onUploaderHover=${Ti} />
                        
                        <!-- Floating Generate Button Layer -->
                        <div class="batch-floating-button-area">
                            <button 
                                class="btn btn-primary" 
                                onClick=${Xe} 
                                disabled=${At||Jt===0} 
                                style=${{width:"100%",padding:"14px",fontSize:"18px",fontWeight:"bold",borderRadius:"12px",boxShadow:"0 10px 25px rgba(0, 209, 178, 0.4)",display:"flex",alignItems:"center",justifyContent:"center",gap:"10px"}}
                            >
                                ${At?g`<div class="spinner" style=${{width:"20px",height:"20px"}}></div>`:""}
                                ${At?o("processing"):Qe}
                            </button>
                        </div>
                    </div>
                `:g`
                    <div style=${{writingMode:"vertical-rl",textOrientation:"mixed",color:"#888",fontSize:"12px",padding:"10px 5px",textAlign:"center",height:"100%"}}>Menu Cài đặt</div>
                `}
            </div>

        </div>
    `};export{ra as BatchBackgroundApp,ra as default};
