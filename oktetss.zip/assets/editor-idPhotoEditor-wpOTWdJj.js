import{d,A as be,y as _,q as N,T as ve,_ as fe}from"./vendor-bdgQI7wY.js";import{k as ye,a8 as we,m as G,U as V,n as q,D as Pe,L as Ie,p as Te,q as ke,h as _e,T as Ce,u as Ee,v as De}from"./editor-MotionEditor-B8LJN4fm.js";import{I as xe,c as Ue,P as Le}from"./editor-aiEditor-Dm1L4C_K.js";import{P as Se,C as W,U as Ae,u as Re,g as Fe}from"./editor-common-ColFbeBm.js";const u=_e.bind(fe),Me=C=>{const{onBackToHome:j,initialFiles:b,t:n,language:X,setLanguage:Q}=C,[g,c]=d([]),[v,Y]=d({background:"white",clothingPrompts:[xe[0].prompt],customClothingImage:null,customPrompt:"",preserveFaceDetails:!0,smoothSkin:!0,slightSmile:!1,hairStyle:"original",numImages:1,keepOriginalLayout:!0,keepOriginalRatio:!0,preserveHairStyle:!0,preserveFaceShape:!0,usePreservationPrompt:!0,preservationPrompt:Se,aiProvider:"haipix",haipixModel:"google_image_gen_banana_3",haipixMode:"vip1",haipixRatio:"auto",haipixResolution:"5k"}),[U,L]=d(!1),[S,A]=d(0),[z,R]=d(0),[J,F]=d(0),[M,f]=d(""),[K,Z]=d(!1),[y,O]=d(null),B=be(!1),[ee,te]=d(!0),[$,w]=d(null),[se,ae]=d([]);_(()=>{ye("image").then(ae).catch(e=>console.error("Models fetch error",e))},[]);const ne=async(e,t,a)=>{if(!$||$.length===0)return;const s=[...$];w(null),f("");const i=new Set(s.map(l=>l.id));c(l=>l.map(o=>i.has(o.id)?{...o,status:"processing",processingPhase:"uploading",processingStartTime:Date.now()}:o)),s.forEach(async l=>{const o=l.id,r=l.generated||l.original;try{const p=await Re(r),{url:T}=await Ee(p,void 0,1e3),k=await De(e,"upscale",void 0,void 0,void 0,t,a,void 0,D=>{c(m=>m.map(x=>x.id===o?{...x,processingPhase:D}:x))},T),h=await Fe(k);c(D=>D.map(m=>m.id===o?{...m,generated:k,status:"done",processingPhase:"done",width:h.width,height:h.height}:m))}catch(p){const T=G(p,n);f(T),c(k=>k.map(h=>h.id===o?{...h,status:"error",error:T}:h))}})};_(()=>{const e=t=>{if(t.key==="*"){const a=t.target;["INPUT","TEXTAREA","SELECT"].includes(a.tagName)||(t.preventDefault(),te(s=>!s))}};return window.addEventListener("keydown",e),()=>window.removeEventListener("keydown",e)},[]);const P=N(e=>{if(!e)return;const t=Array.from(e).filter(s=>s.type.startsWith("image/"));if(t.length===0)return;t.length>0&&!document.fullscreenElement&&document.documentElement.requestFullscreen().catch(s=>{console.warn(`Could not enter fullscreen mode: ${s.message}`)});const a=t.map(s=>({id:Date.now()+Math.random(),file:s,original:URL.createObjectURL(s),generated:null,status:"pending",selected:!0}));c(s=>[...s,...a])},[]);_(()=>{b&&b.length>0&&!B.current&&(P(b),B.current=!0)},[b,P]),_(()=>{const e=async t=>{var l;const a=t.target;if(["INPUT","TEXTAREA","SELECT"].includes(a.tagName))return;const s=(l=t.clipboardData)==null?void 0:l.items;if(!s)return;const i=[];for(let o=0;o<s.length;o++){const r=s[o];if(r.type.startsWith("image/")){const p=r.getAsFile();p&&i.push(p)}}if(i.length>0){t.preventDefault();const o=i.map(r=>({id:Date.now()+Math.random(),file:r,original:URL.createObjectURL(r),generated:null,status:"pending",selected:!0}));c(r=>[...r,...o])}};return document.addEventListener("paste",e),()=>document.removeEventListener("paste",e)},[]);const oe=e=>new Promise((t,a)=>{const s=new FileReader;s.onload=()=>t(s.result),s.onerror=()=>a(new Error(`Lỗi đọc file: ${e.name}`)),s.readAsDataURL(e)}),re=async(e,t,a)=>{let s=0;F(e.length),R(0);const i=[...e],l=async()=>{for(;i.length>0;){const o=i.shift();o&&(await a(o),s++,R(r=>r+1),A(Math.round(s/e.length*100)),i.length>0&&await new Promise(r=>setTimeout(r,2e3)))}};await Promise.all(Array(t).fill(null).map(()=>l()))},H=N(async()=>{L(!0),A(0),f("");const e=g.filter(a=>a.selected&&(a.status==="pending"||a.status==="error"));F(e.length);const t=async a=>{c(s=>s.map(i=>i.id===a.id?{...i,status:"processing",processingStartTime:Date.now(),processingPhase:"uploading"}:i));try{const s=await oe(a.file),i=v.clothingPrompts[0]||"",l=await we(s,v,i,o=>{c(r=>r.map(p=>p.id===a.id?{...p,processingPhase:o}:p))});c(o=>o.map(r=>r.id===a.id?{...r,generated:l,status:"done",processingPhase:"done"}:r))}catch(s){throw f(G(s,n)),c(i=>i.map(l=>l.id===a.id?{...l,status:"error"}:l)),s}};try{await re(e,1,t)}catch(a){console.error(n("batch_processing_stopped"),a)}finally{L(!1)}},[g,v,n]),le=e=>H(),ie=e=>c(t=>t.filter(a=>a.id!==e)),ce=()=>c([]),de=e=>c(t=>t.map(a=>a.id===e?{...a,selected:!a.selected}:a)),ge=()=>c(e=>e.map(t=>({...t,selected:!0}))),ue=()=>c(e=>e.map(t=>({...t,selected:!1}))),pe=e=>{P(e.currentTarget.files),e.currentTarget.value=""},I=(e,t)=>{e.preventDefault(),e.stopPropagation(),Z(t)},he=e=>{var t;I(e,!1),P(((t=e.dataTransfer)==null?void 0:t.files)||null)},$e=()=>{g.forEach(e=>{e.generated&&Ce(e.generated,`${e.file.name.split(".")[0]}-id.png`)})},E=ve(()=>g.filter(e=>e.selected&&(e.status==="pending"||e.status==="error")).length,[g]),me=E>0?n("button_generate_batch_id",{count:String(E)}):n("button_select_to_generate_id");return u`
        ${y&&y.generated&&u`
            <${Ie}
                t=${n}
                originalUrl=${y.original}
                generatedUrl=${y.generated}
                onClose=${()=>O(null)}
                caption=${n("detailedComparison")}
                toggleView=${!0}
            />
        `}
        <div class="editor-layout batch-background-view ${ee?"":"panel-hidden"}">
             <div class="image-panel droppable ${K?"drag-over":""}" onDragOver=${e=>I(e,!0)} onDragEnter=${e=>I(e,!0)} onDragLeave=${e=>I(e,!1)} onDrop=${he}>
                <div style=${{width:"100%",display:"flex",flexDirection:"column",height:"100%",padding:"1.5rem"}}>
                    <div class="actions" style=${{position:"relative",bottom:"auto",right:"auto",justifyContent:"space-between",marginBottom:"1rem",flexWrap:"wrap",gap:"0.5rem"}}>
                        <button class="btn" onClick=${()=>{var e;return(e=document.getElementById("batch-id-file-input"))==null?void 0:e.click()}}><${V} /> ${n("add_images")}</button>
                        <div style=${{display:"flex",gap:"0.5rem"}}><button class="btn btn-secondary" onClick=${ge}>${n("select_all")}</button><button class="btn btn-secondary" onClick=${ue}>${n("deselect_all")}</button><button class="btn btn-secondary" onClick=${ce} disabled=${g.length===0}>${n("delete_all")}</button></div>
                        <input type="file" id="batch-id-file-input" multiple accept="image/*" style=${{display:"none"}} onChange=${pe} />
                        <button 
                            type="button" 
                            class="btn btn-secondary" 
                            onClick=${()=>{const e=g.filter(t=>t.selected);e.length>0?w(e):alert(n("button_select_to_ai_edit"))}} 
                            disabled=${g.filter(e=>e.selected).length===0}
                            title=${n("label_upscale")}
                        >
                            <${q} /> ${n("label_upscale")}
                        </button>
                        <button class="btn btn-primary" onClick=${$e} disabled=${g.every(e=>!e.generated)}><${Pe} /> ${n("download_all")}</button>
                    </div>
                    ${U&&u`<div class="progress-container"><div class="progress-bar"><div class="progress-bar-inner" style=${{width:`${S}%`}}></div><span class="progress-label">${S}%</span></div><span class="progress-counter">${z} / ${J}</span></div>`}
                    ${M&&u`<div class="error-message" style=${{marginTop:"1rem"}}>${M}</div>`}
                    <div class="batch-grid" style=${{flex:1,overflowY:"auto",alignContent:"flex-start"}}>
                        ${g.length===0?u`
                            <div class="upload-placeholder" onClick=${()=>{var e;return(e=document.getElementById("batch-id-file-input"))==null?void 0:e.click()}} style=${{gridColumn:"1 / -1",height:"100%",minHeight:"400px",alignSelf:"stretch"}}>
                                <${V} /><strong>${n("upload_multiple_prompt_title")}</strong><p>${n("upload_id_photo_prompt")}</p>
                            </div>`:g.map(e=>u`
                            <div class="batch-item ${e.selected?"selected":""} ${e.generated?"has-generated":""} ${e.status==="error"?"error":""}">
                                <div class="selection-checkbox" onClick=${()=>de(e.id)}><div class="checkbox-visual"><${W} /></div></div>
                                <div class="image-comparator" style=${{display:"block"}} onClick=${()=>e.generated&&O(e)}>
                                    <div class="image-container ${e.generated?"has-result":""}">
                                        <img src=${e.generated||e.original} onMouseEnter=${t=>{e.generated&&(t.target.src=e.original)}} onMouseLeave=${t=>{e.generated&&(t.target.src=e.generated)}} />
                                        ${e.status==="processing"&&u`<${Le} startTime=${e.processingStartTime} phase=${e.processingPhase} t=${n} />`}
                                        ${e.status==="done"&&u`<div class="batch-item-status-icon"><${W} /></div>`}
                                        ${e.status==="error"&&u`<div class="error-badge" title="${e.error||n("error")}" onClick=${t=>{t.stopPropagation(),alert(e.error||n("error"))}}>${n("error")}</div>`}
                                    </div>
                                </div>
                                <div class="batch-item-actions">
                                    <button class="batch-item-btn" title=${n("regenerate")} onClick=${()=>le(e.id)}><${Te} /></button>
                                    <button class="batch-item-btn" title="Nâng cao chất lượng (Upscale)" onClick=${()=>w([e])}><${q} /></button>
                                    <button class="batch-item-btn" title=${n("delete")} onClick=${()=>ie(e.id)}><${ke} /></button>
                                </div>
                            </div>`)}
                    </div>
                </div>
            </div>
            ${$&&u`
                <${Ae} 
                    targetImages=${$.map(e=>({id:e.id,url:e.generated||e.original}))}
                    models=${se}
                    onClose=${()=>w(null)}
                    onConfirm=${ne}
                    t=${n}
                />
            `}
            <${Ue} settings=${v} setSettings=${Y} onGenerate=${H} generating=${U} hasImage=${E>0} buttonText=${me} isBatch=${!0} onBackToHome=${j} onChooseAnotherImage=${()=>{var e;return(e=document.getElementById("batch-id-file-input"))==null?void 0:e.click()}} t=${n} language=${X} setLanguage=${Q} />
        </div>
    `},Ge=C=>u`
        <div style=${{height:"100%",display:"flex",flexDirection:"column"}}>
            <div style=${{flex:1,minHeight:0}}>
                <${Me} ...${C} />
            </div>
        </div>
    `;export{Ge as default};
