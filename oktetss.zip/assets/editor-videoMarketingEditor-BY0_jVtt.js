import{V as le,_ as se}from"./editor-aiEditor-Dm1L4C_K.js";import{d as p,y as X,T as de,_ as ce}from"./vendor-bdgQI7wY.js";import{E as pe,d as me,D as I,T as V,p as ge,q as ve,U as L,ac as K,m as Q,ad as ue,h as he,Z as be}from"./editor-MotionEditor-B8LJN4fm.js";import"./editor-common-ColFbeBm.js";const l=he.bind(ce),$e=({startTime:$})=>{const[S,D]=p(0);return X(()=>{if(!$)return;const t=setInterval(()=>{D(Math.floor((Date.now()-$)/1e3))},1e3);return()=>clearInterval(t)},[$]),l`<span style=${{fontSize:"0.8rem",color:"#888"}}>${S}s</span>`},ke=$=>{const{onBackToHome:S,initialFiles:D,t,language:ee,setLanguage:te}=$,[c,R]=p("motion"),[m,z]=p([]),[x,oe]=p({prompt:"",aiProvider:"haipix",haipixModel:"veo_3_1",haipixMode:"",haipixRatio:"9:16",haipixResolution:""}),[E,M]=p(!1),[A,j]=p(""),[w,k]=p(null),[ie]=p(!0),[W,U]=p(!1),[f,H]=p([]),[i,v]=p({selectedTemplate:"",studioName:"",specialty:"",hookText:"",ctaText:"",style:"cinematic",musicMood:"upbeat",duration:"medium"}),[_,G]=p(!1),[P,ae]=p(null),N=()=>{z(e=>[...e,{id:Date.now().toString()+Math.random(),startImage:null,startImagePreview:null,endImage:null,endImagePreview:null,prompt:"",status:"pending",selected:!0}])};X(()=>{m.length===0&&N()},[]);const re=e=>{z(a=>a.filter(o=>o.id!==e))},h=(e,a)=>{z(o=>o.map(r=>r.id===e?{...r,...a}:r))},F=(e,a,o)=>{const r=new FileReader;r.onload=n=>{var s;(s=n.target)!=null&&s.result&&h(e,{[o==="start"?"startImage":"endImage"]:a,[o==="start"?"startImagePreview":"endImagePreview"]:n.target.result})},r.readAsDataURL(a)},B=async e=>{const a=e?m.filter(o=>o.id===e):m.filter(o=>o.selected&&(o.status==="pending"||o.status==="error"));if(a.length!==0){M(!0),j("");for(const o of a){h(o.id,{status:"processing",progress:t("loader_video"),processingStartTime:Date.now()});try{const r=[];if(o.startImagePreview&&r.push(o.startImagePreview),o.endImagePreview&&r.push(o.endImagePreview),r.length===0)throw new Error(t("error_no_image"));if(!o.prompt.trim())throw new Error(t("error_no_prompt"));const n=g=>h(o.id,{progress:g}),s={...x,prompt:o.prompt},d=await K(r,s,t,n);h(o.id,{status:"done",generatedVideo:d,progress:null})}catch(r){console.error(r),h(o.id,{status:"error",progress:Q(r,t)})}}M(!1)}},ne=async()=>{const e=m.filter(n=>n.selected&&n.generatedVideo);if(e.length===0)return;const a=9,o=1e3,r=async(n,s=1)=>{try{const d=await fetch(be(n));if(!d.ok)throw new Error(`HTTP ${d.status}`);return await d.blob()}catch(d){if(s<a)return console.log(`Fetch failed, retrying (${s}/${a})...`),await new Promise(g=>setTimeout(g,o*s)),r(n,s+1);throw d}};U(!0);try{const{default:n}=await se(async()=>{const{default:u}=await import("https://cdn.jsdelivr.net/npm/jszip@3.10.1/+esm");return{default:u}},[]),s=new n;let d=0,g=1;for(const u of e)if(u.generatedVideo)try{const y=await r(u.generatedVideo),C=`${g.toString().padStart(3,"0")}_video_${u.id.slice(0,8)}.mp4`;s.file(C,y),d++,g++}catch(y){console.error("Error fetching video for zip:",y)}if(d===0)throw new Error("Không thể tải được video nào do lỗi kết nối hoặc CORS.");const T=await s.generateAsync({type:"blob"}),b=document.createElement("a");b.href=URL.createObjectURL(T),b.download=`videos_${Date.now()}.zip`,b.click(),URL.revokeObjectURL(b.href)}catch(n){console.error("Error creating zip:",n),alert("Lỗi khi tải xuống: "+n.message+`

Giải pháp: Bấm vào từng video để xem to rồi chuột phải chọn "Lưu video thành..."`)}finally{U(!1)}},O=de(()=>m.filter(e=>e.selected&&e.generatedVideo).length,[m]);return l`
        ${A&&l`<${pe} message=${A} onClose=${()=>j("")} />`}
        ${w&&w.generatedVideo&&l`
            <div class="lightbox-overlay" onClick=${()=>k(null)}>
                <div class="lightbox-content video-preview-modal" onClick=${e=>e.stopPropagation()} style=${{maxWidth:"900px",width:"90%",backgroundColor:"#1a1a1a",borderRadius:"12px",overflow:"hidden",boxShadow:"0 20px 50px rgba(0,0,0,0.5)"}}>
                     <div class="lightbox-header" style=${{padding:"1rem 1.5rem",borderBottom:"1px solid #333",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                        <h3 style=${{margin:0,fontSize:"1.1rem",color:"#fff"}}>${t("video_preview")}</h3>
                        <button class="lightbox-close-btn" onClick=${()=>k(null)} title=${t("closeEsc")} style=${{background:"none",border:"none",color:"#aaa",cursor:"pointer"}}><${me} /></button>
                    </div>
                    <div class="lightbox-video-wrapper" style=${{padding:"0",background:"#000",display:"flex",justifyContent:"center",alignItems:"center",minHeight:"400px"}}>
                        <video src=${w.generatedVideo} controls autoplay loop style=${{maxWidth:"100%",maxHeight:"70vh",boxShadow:"0 4px 20px rgba(0,0,0,0.3)"}} />
                    </div>
                    <div class="lightbox-footer" style=${{padding:"1rem 1.5rem",borderTop:"1px solid #333",display:"flex",justifyContent:"flex-end",gap:"1rem",background:"#1a1a1a"}}>
                        <button class="btn btn-secondary" onClick=${()=>k(null)}>${t("close")}</button>
                        <button class="btn btn-primary" onClick=${()=>{V(w.generatedVideo,"video-"+w.id+".mp4")}}>
                            <${I} /> ${t("download_video")}
                        </button>
                    </div>
                </div>
            </div>
        `}
        
        <div class="editor-layout batch-background-view ${ie?"":"panel-hidden"}">
             <div class="image-panel" style=${{overflowY:"auto",padding:"1.5rem"}}>
                <!-- Sub-tabs Navigation -->
                <div class="video-sub-tabs" style=${{display:"flex",gap:"0.5rem",marginBottom:"1.5rem",borderBottom:"1px solid #333",paddingBottom:"1rem",position:"relative",zIndex:10}}>
                    <button 
                        class="btn ${c==="motion"?"btn-primary":"btn-secondary"}"
                        onClick=${()=>R("motion")}
                        style=${{padding:"0.75rem 1.5rem",borderRadius:"8px 8px 0 0",fontWeight:c==="motion"?"600":"400",transition:"all 0.2s ease",background:c==="motion"?"linear-gradient(135deg, #a55eea 0%, #8854d0 100%)":void 0,border:c==="motion"?"none":void 0,cursor:"pointer",display:"flex",alignItems:"center"}}
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style=${{marginRight:"8px"}}><path d="M21 7L13 15L9 11L3 17"/><polyline points="17 7 21 7 21 11"/></svg>
                        ${t("video_tab_motion")}
                        <span style=${{marginLeft:"8px",background:"#ff4757",color:"#fff",padding:"2px 6px",borderRadius:"10px",fontSize:"0.7rem",fontWeight:"600"}}>HOT</span>
                    </button>
                    <button 
                        class="btn ${c==="from-image"?"btn-primary":"btn-secondary"}"
                        onClick=${()=>R("from-image")}
                        style=${{padding:"0.75rem 1.5rem",borderRadius:"8px 8px 0 0",fontWeight:c==="from-image"?"600":"400",transition:"all 0.2s ease",cursor:"pointer",display:"flex",alignItems:"center"}}
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style=${{marginRight:"8px"}}><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/></svg>
                        ${t("video_tab_from_image")}
                    </button>
                    <button 
                        class="btn ${c==="viral"?"btn-primary":"btn-secondary"}"
                        onClick=${()=>R("viral")}
                        style=${{padding:"0.75rem 1.5rem",borderRadius:"8px 8px 0 0",fontWeight:c==="viral"?"600":"400",transition:"all 0.2s ease",background:c==="viral"?"linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%)":void 0,border:c==="viral"?"none":void 0,cursor:"pointer",display:"flex",alignItems:"center"}}
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style=${{marginRight:"8px"}}><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                        ${t("video_tab_viral")}
                        <span style=${{marginLeft:"8px",background:"#ff4757",color:"#fff",padding:"2px 6px",borderRadius:"10px",fontSize:"0.7rem",fontWeight:"600"}}>HOT</span>
                    </button>
                </div>

                <!-- Tab Content: From Image -->
                ${c==="from-image"&&l`
                <div class="actions" style=${{justifyContent:"space-between",marginBottom:"1.5rem",flexWrap:"wrap",gap:"0.5rem"}}>
                    <div style=${{display:"flex",gap:"0.5rem"}}>
                        <button class="btn btn-primary" onClick=${N}>
                            <span style=${{fontSize:"1.2em",marginRight:"0.5rem"}}>+</span> ${t("add_group")}
                        </button>
                        <button class="btn btn-primary" onClick=${()=>B()} disabled=${E||m.every(e=>e.status==="done"||!e.selected)}>
                            <${ge} /> ${t("generate_all_selected")}
                        </button>
                    </div>
                    <button class="btn btn-primary" onClick=${ne} disabled=${O===0||W}>
                        <${I} /> ${W?t("processing")||"Đang nén...":`${t("download_all")||"Tải tất cả"} (${O})`}
                    </button>
                </div>

                <div class="video-groups-container" style=${{display:"grid",gridTemplateColumns:"repeat(auto-fill, minmax(450px, 1fr))",gap:"1.5rem"}}>
                    ${m.map((e,a)=>l`
                        <div class="video-group-card" style=${{background:"#2a2a2a",borderRadius:"12px",padding:"1.5rem",border:e.generatedVideo&&e.selected?"2px solid var(--primary)":e.selected?"1px solid #4a4a4a":"1px solid transparent",position:"relative",boxShadow:e.generatedVideo&&e.selected?"0 0 10px color-mix(in srgb, var(--primary) 30%, transparent)":"none"}}>
                            <div class="group-header" style=${{display:"flex",justifyContent:"space-between",marginBottom:"1rem"}}>
                                <div style=${{display:"flex",alignItems:"center",gap:"0.5rem"}}>
                                    <input type="checkbox" checked=${e.selected} onChange=${o=>h(e.id,{selected:o.target.checked})} />
                                    <h3 style=${{margin:0,fontSize:"1rem",color:"#ddd"}}>${t("group")} ${a+1}</h3>
                                </div>
                                <button class="btn-icon" onClick=${()=>re(e.id)} title=${t("delete")} style=${{color:"#ff4d4f",background:"transparent",border:"none",cursor:"pointer"}}>
                                    <${ve} />
                                </button>
                            </div>

                            <div class="group-content" style=${{display:"flex",flexDirection:"column",gap:"1rem"}}>
                                <!-- Images Row -->
                                <div style=${{display:"flex",gap:"1rem"}}>
                                    <!-- Start Image -->
                                    <div class="image-upload-area" style=${{flex:1}}>
                                        <div class="label" style=${{marginBottom:"0.5rem",fontSize:"0.85em",color:"#aaa"}}>${t("start_frame")}</div>
                                        <div 
                                            class="upload-box ${e.startImagePreview?"":"empty"}" 
                                            style=${{width:"100%",aspectRatio:x.haipixRatio==="9:16"?"9/16":"16/9",background:"#1f1f1f",borderRadius:"8px",display:"flex",alignItems:"center",justifyContent:"center",overflow:"hidden",cursor:"pointer",border:"1px dashed #444",position:"relative"}}
                                            onClick=${()=>{var o;return(o=document.getElementById("start-img-"+e.id))==null?void 0:o.click()}}
                                        >
                                            ${e.startImagePreview?l`
                                                <img src=${e.startImagePreview} style=${{width:"100%",height:"100%",objectFit:"contain"}} />
                                            `:l`
                                                <div style=${{textAlign:"center",color:"#666"}}>
                                                    <${L} />
                                                    <div style=${{fontSize:"0.75em",marginTop:"0.5rem"}}>${t("upload")}</div>
                                                </div>
                                            `}
                                            <input 
                                                type="file" 
                                                id=${"start-img-"+e.id}
                                                style=${{display:"none"}} 
                                                accept="image/*"
                                                onChange=${o=>{var r;return((r=o.target.files)==null?void 0:r[0])&&F(e.id,o.target.files[0],"start")}} 
                                            />
                                        </div>
                                    </div>

                                    <!-- End Image -->
                                    <div class="image-upload-area" style=${{flex:1}}>
                                        <div class="label" style=${{marginBottom:"0.5rem",fontSize:"0.85em",color:"#aaa"}}>${t("end_frame")} (${t("optional")})</div>
                                        <div 
                                            class="upload-box ${e.endImagePreview?"":"empty"}" 
                                            style=${{width:"100%",aspectRatio:x.haipixRatio==="9:16"?"9/16":"16/9",background:"#1f1f1f",borderRadius:"8px",display:"flex",alignItems:"center",justifyContent:"center",overflow:"hidden",cursor:"pointer",border:"1px dashed #444",position:"relative"}}
                                            onClick=${()=>{var o;return(o=document.getElementById("end-img-"+e.id))==null?void 0:o.click()}}
                                        >
                                            ${e.endImagePreview?l`
                                                <img src=${e.endImagePreview} style=${{width:"100%",height:"100%",objectFit:"contain"}} />
                                            `:l`
                                                <div style=${{textAlign:"center",color:"#666"}}>
                                                    <${L} />
                                                    <div style=${{fontSize:"0.75em",marginTop:"0.5rem"}}>${t("upload")}</div>
                                                </div>
                                            `}
                                            <input 
                                                type="file" 
                                                id=${"end-img-"+e.id}
                                                style=${{display:"none"}} 
                                                accept="image/*"
                                                onChange=${o=>{var r;return((r=o.target.files)==null?void 0:r[0])&&F(e.id,o.target.files[0],"end")}} 
                                            />
                                        </div>
                                    </div>
                                </div>

                                <!-- Prompt & Actions -->
                                <div class="prompt-area" style=${{display:"flex",flexDirection:"column",gap:"0.75rem"}}>
                                    <div class="form-group">
                                        <div style=${{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"0.5rem"}}>
                                            <div class="label" style=${{fontSize:"0.85em",color:"#aaa"}}>${t("prompt")}</div>
                                        </div>
                                        <textarea 
                                            class="form-control" 
                                            style=${{width:"100%",height:"80px",background:"#1f1f1f",border:"1px solid #444",color:"#fff",resize:"vertical",fontSize:"0.9em"}}
                                            placeholder=${t("placeholder_video_marketing")}
                                            value=${e.prompt}
                                            onInput=${o=>h(e.id,{prompt:o.target.value})}
                                        ></textarea>
                                    </div>

                                    ${e.status==="processing"&&l`
                                        <div class="video-progress-steps" style=${{marginTop:"1rem",padding:"1rem",background:"rgba(0,0,0,0.3)",borderRadius:"12px",border:"1px solid rgba(255,255,255,0.05)"}}>
                                            <div style=${{display:"flex",alignItems:"center",gap:"0.75rem",marginBottom:"1rem"}}>
                                                <div class="spinner-small"></div>
                                                <div style=${{display:"flex",flexDirection:"column"}}>
                                                    <span style=${{fontSize:"0.9rem",color:"#fff",fontWeight:"600"}}>${e.progress||t("processing")}</span>
                                                    <${$e} startTime=${e.processingStartTime} />
                                                </div>
                                            </div>
                                            
                                            <div class="steps-timeline" style=${{display:"flex",flexDirection:"column",gap:"8px"}}>
                                                ${[{label:"Upload ảnh",key:"upload"},{label:"Đang chờ xử lý",key:"pending"},{label:"Kích hoạt video",key:"active"},{label:"Đang render",key:"processing"}].map((o,r)=>{var d,g,T,b,u,y,C,Z,q,Y,J;const n=((d=e.progress)==null?void 0:d.includes("đã tạo thành công"))||r===0&&(((g=e.progress)==null?void 0:g.includes("Yêu cầu"))||((T=e.progress)==null?void 0:T.includes("kích hoạt"))||((b=e.progress)==null?void 0:b.includes("render")))||r===1&&(((u=e.progress)==null?void 0:u.includes("kích hoạt"))||((y=e.progress)==null?void 0:y.includes("render")))||r===2&&((C=e.progress)==null?void 0:C.includes("render")),s=r===0&&((Z=e.progress)==null?void 0:Z.includes("upload"))||r===1&&((q=e.progress)==null?void 0:q.includes("Yêu cầu"))||r===2&&((Y=e.progress)==null?void 0:Y.includes("kích hoạt"))||r===3&&((J=e.progress)==null?void 0:J.includes("render"));return l`
                                                    <div style=${{display:"flex",alignItems:"center",gap:"10px",opacity:n||s?1:.3,transition:"all 0.3s ease"}}>
                                                        <div style=${{width:"8px",height:"8px",borderRadius:"50%",background:s?"var(--primary)":n?"#52c41a":"#555",boxShadow:s?"0 0 8px var(--primary)":"none"}}></div>
                                                        <span style=${{fontSize:"0.75rem",fontWeight:s?"600":"400",color:s?"#fff":"#aaa"}}>${o.label}</span>
                                                    </div>
                                                `})}
                                            </div>
                                        </div>
                                    `}

                                    ${e.status==="error"&&l`
                                        <div class="error-message" style=${{fontSize:"0.9em",color:"#ff4d4f"}}>${e.progress}</div>
                                    `}

                                    ${e.status==="done"&&e.generatedVideo&&l`
                                        <div class="result-video-container" style=${{marginTop:"0.25rem",marginBottom:"0.5rem"}}>
                                            <video 
                                                src=${e.generatedVideo} 
                                                controls 
                                                style=${{width:"100%",borderRadius:"8px",border:"1px solid #444",maxHeight:"250px",backgroundColor:"#000"}} 
                                            />
                                        </div>
                                        <div class="result-actions" style=${{display:"flex",gap:"0.5rem"}}>
                                            <button class="btn btn-secondary" style=${{fontSize:"0.85em",padding:"0.5rem 0.75rem"}} onClick=${()=>k(e)}>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z"/></svg> ${t("video_preview")}
                                            </button>
                                            <button class="btn btn-secondary" style=${{fontSize:"0.85em",padding:"0.5rem 0.75rem"}} onClick=${()=>{V(e.generatedVideo,"video-"+e.id+".mp4")}}>
                                                <${I} />
                                            </button>
                                        </div>
                                    `}

                                    <button 
                                        class="btn btn-primary" 
                                        style=${{width:"100%",fontSize:"0.9em"}}
                                        onClick=${()=>B(e.id)}
                                        disabled=${e.status==="processing"||!e.startImagePreview||!e.prompt}
                                    >
                                        ${e.status==="done"?t("regenerate"):t("create_video")}
                                    </button>
                                </div>
                            </div>
                        </div>
                    `)}
                </div>
                `}

                <!-- Tab Content: VIDEO VIRAL -->
                ${c==="viral"&&l`
                <div class="viral-video-container" style=${{background:"linear-gradient(135deg, rgba(255,107,107,0.1) 0%, rgba(238,90,36,0.1) 100%)",borderRadius:"16px",padding:"2rem",border:"1px solid rgba(255,107,107,0.3)"}}>
                    <div class="viral-header" style=${{textAlign:"center",marginBottom:"2rem"}}>
                        <h2 style=${{margin:"0 0 0.5rem 0",fontSize:"1.8rem",background:"linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%)",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent",fontWeight:"700"}}>${t("viral_video_title")}</h2>
                        <p style=${{margin:0,color:"#aaa",fontSize:"0.95rem"}}>${t("viral_video_subtitle")}</p>
                    </div>

                    <!-- Upload Images Section -->
                    <div class="viral-upload-section" style=${{marginBottom:"2rem"}}>
                        <h3 style=${{marginBottom:"1rem",fontSize:"1.1rem",color:"#fff"}}>📸 Ảnh của bạn</h3>
                        <div style=${{display:"grid",gridTemplateColumns:"repeat(auto-fill, minmax(120px, 1fr))",gap:"1rem",padding:"1.5rem",background:"rgba(0,0,0,0.2)",borderRadius:"12px",border:"2px dashed rgba(255,255,255,0.1)"}}>
                            ${f.map((e,a)=>l`
                                <div style=${{position:"relative",aspectRatio:"1",borderRadius:"8px",overflow:"hidden"}}>
                                    <img src=${e} style=${{width:"100%",height:"100%",objectFit:"cover"}} />
                                    <button 
                                        style=${{position:"absolute",top:"4px",right:"4px",background:"#ff4757",border:"none",borderRadius:"50%",width:"24px",height:"24px",color:"#fff",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",fontSize:"12px"}}
                                        onClick=${()=>H(o=>o.filter((r,n)=>n!==a))}
                                    >✕</button>
                                </div>
                            `)}
                            <label style=${{aspectRatio:"1",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",background:"rgba(255,255,255,0.05)",borderRadius:"8px",border:"2px dashed rgba(255,255,255,0.2)",cursor:"pointer",transition:"all 0.2s ease"}}
                            onMouseEnter=${e=>e.currentTarget.style.borderColor="#ff6b6b"}
                            onMouseLeave=${e=>e.currentTarget.style.borderColor="rgba(255,255,255,0.2)"}
                            >
                                <input 
                                    type="file" 
                                    accept="image/*" 
                                    multiple 
                                    style=${{display:"none"}}
                                    onChange=${e=>{Array.from(e.target.files||[]).forEach(o=>{const r=new FileReader;r.onload=n=>{H(s=>{var d;return[...s,(d=n.target)==null?void 0:d.result]})},r.readAsDataURL(o)})}}
                                />
                                <${L} style=${{width:"32px",height:"32px",color:"#888"}} />
                                <span style=${{marginTop:"8px",fontSize:"0.8rem",color:"#888"}}>Thêm ảnh</span>
                            </label>
                        </div>
                    </div>

                    <!-- Template Selection -->
                    <div class="viral-templates" style=${{marginBottom:"2rem"}}>
                        <h3 style=${{marginBottom:"1rem",fontSize:"1.1rem",color:"#fff"}}>🎬 ${t("viral_section_template")}</h3>
                        <div class="template-grid" style=${{display:"grid",gridTemplateColumns:"repeat(auto-fill, minmax(140px, 1fr))",gap:"0.75rem"}}>
                            ${[{key:"intro",icon:"🏠",label:t("viral_template_intro")},{key:"behind_scenes",icon:"🎥",label:t("viral_template_behind_scenes")},{key:"before_after",icon:"✨",label:t("viral_template_before_after")},{key:"tips",icon:"💡",label:t("viral_template_tips")},{key:"promo",icon:"🎁",label:t("viral_template_promo")},{key:"portfolio",icon:"📷",label:t("viral_template_portfolio")},{key:"trending",icon:"🎵",label:t("viral_template_trending_sound")},{key:"testimonial",icon:"⭐",label:t("viral_template_testimonial")}].map(e=>l`
                                <button 
                                    class="template-btn ${i.selectedTemplate===e.key?"active":""}"
                                    style=${{padding:"1rem",borderRadius:"10px",border:i.selectedTemplate===e.key?"2px solid #ff6b6b":"1px solid rgba(255,255,255,0.1)",background:i.selectedTemplate===e.key?"rgba(255,107,107,0.2)":"rgba(255,255,255,0.03)",color:"#fff",cursor:"pointer",transition:"all 0.2s ease",display:"flex",flexDirection:"column",alignItems:"center",gap:"8px",fontSize:"0.85rem"}}
                                    onClick=${()=>v(a=>({...a,selectedTemplate:e.key}))}
                                >
                                    <span style=${{fontSize:"1.5rem"}}>${e.icon}</span>
                                    ${e.label}
                                </button>
                            `)}
                        </div>
                    </div>

                    <!-- Custom Inputs -->
                    <div class="viral-custom-inputs" style=${{marginBottom:"2rem"}}>
                        <h3 style=${{marginBottom:"1rem",fontSize:"1.1rem",color:"#fff"}}>✏️ ${t("viral_section_custom")}</h3>
                        <div style=${{display:"grid",gap:"1rem"}}>
                            <div class="form-group">
                                <label style=${{display:"block",marginBottom:"0.5rem",color:"#aaa",fontSize:"0.9rem"}}>${t("viral_studio_name")}</label>
                                <input 
                                    type="text" 
                                    placeholder=${t("viral_studio_name_placeholder")}
                                    value=${i.studioName}
                                    onInput=${e=>v(a=>({...a,studioName:e.target.value}))}
                                    style=${{width:"100%",padding:"0.75rem",background:"rgba(0,0,0,0.3)",border:"1px solid rgba(255,255,255,0.1)",borderRadius:"8px",color:"#fff"}}
                                />
                            </div>
                            <div class="form-group">
                                <label style=${{display:"block",marginBottom:"0.5rem",color:"#aaa",fontSize:"0.9rem"}}>${t("viral_specialty")}</label>
                                <input 
                                    type="text" 
                                    placeholder=${t("viral_specialty_placeholder")}
                                    value=${i.specialty}
                                    onInput=${e=>v(a=>({...a,specialty:e.target.value}))}
                                    style=${{width:"100%",padding:"0.75rem",background:"rgba(0,0,0,0.3)",border:"1px solid rgba(255,255,255,0.1)",borderRadius:"8px",color:"#fff"}}
                                />
                            </div>
                            <div class="form-group">
                                <label style=${{display:"block",marginBottom:"0.5rem",color:"#aaa",fontSize:"0.9rem"}}>${t("viral_hook_text")}</label>
                                <input 
                                    type="text" 
                                    placeholder=${t("viral_hook_placeholder")}
                                    value=${i.hookText}
                                    onInput=${e=>v(a=>({...a,hookText:e.target.value}))}
                                    style=${{width:"100%",padding:"0.75rem",background:"rgba(0,0,0,0.3)",border:"1px solid rgba(255,255,255,0.1)",borderRadius:"8px",color:"#fff"}}
                                />
                            </div>
                            <div class="form-group">
                                <label style=${{display:"block",marginBottom:"0.5rem",color:"#aaa",fontSize:"0.9rem"}}>${t("viral_cta_text")}</label>
                                <input 
                                    type="text" 
                                    placeholder=${t("viral_cta_placeholder")}
                                    value=${i.ctaText}
                                    onInput=${e=>v(a=>({...a,ctaText:e.target.value}))}
                                    style=${{width:"100%",padding:"0.75rem",background:"rgba(0,0,0,0.3)",border:"1px solid rgba(255,255,255,0.1)",borderRadius:"8px",color:"#fff"}}
                                />
                            </div>
                        </div>
                    </div>

                    <!-- Style & Duration -->
                    <div style=${{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:"1.5rem",marginBottom:"2rem"}}>
                        <div>
                            <label style=${{display:"block",marginBottom:"0.5rem",color:"#aaa",fontSize:"0.9rem"}}>${t("viral_style")}</label>
                            <select 
                                value=${i.style}
                                onChange=${e=>v(a=>({...a,style:e.target.value}))}
                                style=${{width:"100%",padding:"0.75rem",background:"rgba(0,0,0,0.3)",border:"1px solid rgba(255,255,255,0.1)",borderRadius:"8px",color:"#fff"}}
                            >
                                <option value="cinematic">${t("viral_style_cinematic")}</option>
                                <option value="dynamic">${t("viral_style_dynamic")}</option>
                                <option value="elegant">${t("viral_style_elegant")}</option>
                                <option value="fun">${t("viral_style_fun")}</option>
                                <option value="professional">${t("viral_style_professional")}</option>
                            </select>
                        </div>
                        <div>
                            <label style=${{display:"block",marginBottom:"0.5rem",color:"#aaa",fontSize:"0.9rem"}}>${t("viral_music_mood")}</label>
                            <select 
                                value=${i.musicMood}
                                onChange=${e=>v(a=>({...a,musicMood:e.target.value}))}
                                style=${{width:"100%",padding:"0.75rem",background:"rgba(0,0,0,0.3)",border:"1px solid rgba(255,255,255,0.1)",borderRadius:"8px",color:"#fff"}}
                            >
                                <option value="upbeat">${t("viral_music_upbeat")}</option>
                                <option value="emotional">${t("viral_music_emotional")}</option>
                                <option value="trendy">${t("viral_music_trendy")}</option>
                                <option value="calm">${t("viral_music_calm")}</option>
                            </select>
                        </div>
                        <div>
                            <label style=${{display:"block",marginBottom:"0.5rem",color:"#aaa",fontSize:"0.9rem"}}>${t("viral_duration")}</label>
                            <select 
                                value=${i.duration}
                                onChange=${e=>v(a=>({...a,duration:e.target.value}))}
                                style=${{width:"100%",padding:"0.75rem",background:"rgba(0,0,0,0.3)",border:"1px solid rgba(255,255,255,0.1)",borderRadius:"8px",color:"#fff"}}
                            >
                                <option value="short">${t("viral_duration_short")}</option>
                                <option value="medium">${t("viral_duration_medium")}</option>
                                <option value="long">${t("viral_duration_long")}</option>
                            </select>
                        </div>
                    </div>

                    <!-- Generate Button -->
                    <button 
                        class="btn btn-primary"
                        style=${{width:"100%",padding:"1rem 2rem",fontSize:"1.1rem",fontWeight:"600",background:"linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%)",border:"none",borderRadius:"12px",cursor:f.length===0||_?"not-allowed":"pointer",opacity:f.length===0||_?.5:1,transition:"all 0.2s ease"}}
                        disabled=${f.length===0||_}
                        onClick=${async()=>{if(f.length===0){alert(t("viral_no_images"));return}G(!0);try{const a={intro:`Tạo video giới thiệu studio ảnh ${i.studioName||"chuyên nghiệp"} với phong cách ${i.style}. Chuyên ${i.specialty||"chụp ảnh"}. ${i.hookText||""}. ${i.ctaText||""}`,behind_scenes:`Tạo video hậu trường chụp ảnh tại studio ${i.studioName||""} theo phong cách ${i.style}. Cho thấy quá trình chụp ảnh chuyên nghiệp.`,before_after:`Tạo video before/after transformation, thể hiện sự khác biệt trước và sau khi chỉnh sửa ảnh. Phong cách ${i.style}.`,tips:`Tạo video chia sẻ mẹo chụp ảnh đẹp. ${i.hookText||"Bí mật để có ảnh đẹp như người mẫu"}. Phong cách ${i.style}.`,promo:`Tạo video quảng cáo khuyến mãi cho ${i.studioName||"studio ảnh"}. ${i.hookText||""}. ${i.ctaText||"Đặt lịch ngay!"}.`,portfolio:`Tạo video showcase portfolio ảnh đẹp từ ${i.studioName||"studio"}. Phong cách ${i.style}, chuyên ${i.specialty||"chụp ảnh"}.`,trending:`Tạo video theo trend TikTok/Reels with ảnh studio. Mood nhạc ${i.musicMood}. Phong cách ${i.style}.`,testimonial:`Tạo video review, đánh giá của khách hàng về ${i.studioName||"studio ảnh"}. Phong cách ${i.style}.`}[i.selectedTemplate]||`Tạo video viral quảng bá studio ảnh ${i.studioName}. ${i.hookText}. ${i.ctaText}. Phong cách ${i.style}.`,o=await K(f,{...x,prompt:a,haipixRatio:"9:16"},t,()=>{});ae(o)}catch(e){console.error(e),alert(Q(e,t))}finally{G(!1)}}}
                    >
                        ${_?l`<span class="spinner-small" style=${{marginRight:"10px"}}></span>${t("viral_generating")}`:l`<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style=${{marginRight:"10px"}}><polygon points="5 3 19 12 5 21 5 3"/></svg>${t("viral_generate_button")}`}
                    </button>

                    <!-- Generated Video Preview -->
                    ${P&&l`
                        <div style=${{marginTop:"2rem",padding:"1.5rem",background:"rgba(0,0,0,0.3)",borderRadius:"12px"}}>
                            <h3 style=${{marginBottom:"1rem",color:"#fff"}}>🎬 Video đã tạo</h3>
                            <video 
                                src=${P} 
                                controls 
                                style=${{width:"100%",maxHeight:"400px",borderRadius:"8px",background:"#000"}}
                            />
                            <div style=${{marginTop:"1rem",display:"flex",gap:"1rem"}}>
                                <button 
                                    class="btn btn-primary"
                                    onClick=${()=>{V(P,`viral_video_${Date.now()}.mp4`)}}
                                >
                                    <${I} /> ${t("download_video")}
                                </button>
                            </div>
                        </div>
                    `}
                </div>
                `}

                <!-- Tab Content: Video Motion -->
                ${c==="motion"&&l`
                    <${ue} ...${$} />
                `}
            </div>


            ${c==="from-image"&&l`
            <${le}
                settings=${x}
                setSettings=${oe}
                onGenerate=${()=>B()}
                generating=${E}
                hasImage=${m.some(e=>e.startImagePreview)}
                onBackToHome=${S}
                onChooseAnotherImage=${()=>{}}
                t=${t}
                language=${ee}
                setLanguage=${te}
            />
            `}
        </div>
    `};export{ke as default};
