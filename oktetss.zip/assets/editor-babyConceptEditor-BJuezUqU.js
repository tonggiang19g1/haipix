import{_ as o}from"./vendor-bdgQI7wY.js";import{w as i,h as r}from"./editor-MotionEditor-B8LJN4fm.js";import{B as s}from"./editor-aiEditor-Dm1L4C_K.js";import{S as l}from"./editor-common-ColFbeBm.js";const m=r.bind(o),y=t=>m`<${l}
        ...${t}
        SettingsPanel=${s}
        initialSettings=${{selectedConceptPrompt:null,numImages:1,gender:"boy",aiProvider:"haipix",haipixModel:"google_image_gen_banana_3",haipixMode:"vip1",haipixRatio:"auto",haipixResolution:"5k"}}
        onGenerate=${async(a,e,d,c)=>{const n=Array.from({length:e.numImages},()=>i(a,e));return await Promise.all(n)}}
        loaderTextKey="loader_baby"
        actionButtonTextKey="button_generate_photo_enter"
        downloadFilename="baby-concept.png"
    />`;export{y as default};
