import{R as be,P as ke,_ as Ie}from"./editor-aiEditor-Dm1L4C_K.js";import{d as l,A as Ce,y as M,q as fe,_ as Te,T as Pe}from"./vendor-bdgQI7wY.js";import{aa as pe,m as ne,E as Se,L as ve,y as De,a0 as _e,a5 as Ee,U as $e,a6 as Re,a1 as xe,a2 as Le,p as we,D as ye,Q as Ue,h as Ae,k as Be,n as he,q as Me,T as Oe,t as Ve,u as Fe,v as Ge}from"./editor-MotionEditor-B8LJN4fm.js";import{C as me,U as ze,u as Ne,g as He}from"./editor-common-ColFbeBm.js";const $=Ae.bind(Te),je=S=>{const{initialImage:C,onChooseAnotherImage:o,onBackToHome:D,onImageUpdate:_,t:r,language:h,setLanguage:se}=S,O={background:"auto",colorize:!1,sharpenBackground:!0,highQuality:!1,isVietnamese:!0,numberOfPeople:"",gender:"unknown",ageRange:"unknown",smile:"unknown",clothingPrompt:"",advancedPrompt:"",numberOfResults:1,aiProvider:"haipix",haipixModel:"google_image_gen_banana_3",haipixMode:"vip1",haipixRatio:"auto",haipixResolution:"5k"},[w,Z]=l(C),[W,V]=l([]),[b,F]=l(null),[E,X]=l(!1),[q,P]=l(""),[k,J]=l("generated"),[K,R]=l(null),[x,G]=l(!1),[z,L]=l(!1),[U,A]=l(O),[N,H]=l(!1),[oe]=l(!0),[j,Y]=l(""),[ee,re]=l(r("loader_analyzing")),te=Ce(U);M(()=>{te.current=U},[U]),M(()=>{if(j){const s=setTimeout(()=>{Y("")},5e3);return()=>clearTimeout(s)}},[j]);const ae=fe(async()=>{if(w){re(r("loader_restoration")),X(!0),P(""),V([]),F(null),G(!1),L(!1);try{const{numberOfResults:s,...d}=te.current,y=Array.from({length:s},()=>pe(w,d)),f=await Promise.all(y);f.length>0?(V(f),F(f[0]),J("generated")):P(r("imageGenFailed"))}catch(s){P(ne(s,r))}finally{X(!1)}}},[w,r]),ie=()=>{G(s=>{const d=!s;return d&&L(!1),d})},le=()=>{L(s=>{const d=!s;return d&&G(!1),d})};M(()=>{Z(C),V([]),F(null),P(""),G(!1),L(!1)},[C]),M(()=>{const s=async d=>{var T;const y=d.target;if(["INPUT","TEXTAREA","SELECT"].includes(y.tagName))return;const f=(T=d.clipboardData)==null?void 0:T.items;if(f)for(let e=0;e<f.length;e++){const a=f[e];if(a.type.startsWith("image/")){const t=a.getAsFile();if(t){d.preventDefault();const n=new FileReader;n.onload=i=>{var c;(c=i.target)!=null&&c.result&&_(i.target.result)},n.readAsDataURL(t);break}}}};return document.addEventListener("paste",s),()=>document.removeEventListener("paste",s)},[_]);const ce=(s,d)=>{const y=new FileReader;y.onload=f=>{var T;(T=f.target)!=null&&T.result&&d(f.target.result)},y.readAsDataURL(s)},de=s=>{var y,f;s.preventDefault(),s.stopPropagation(),H(!1);const d=(f=(y=s.dataTransfer)==null?void 0:y.files)==null?void 0:f[0];d&&d.type.startsWith("image/")&&ce(d,_)},ge=s=>{s&&Oe(s,"restored-photo.png")};return $`
        ${j&&$`<div class="toast-notification">${j}</div>`}
        ${q&&$`<${Se} message=${q} onClose=${()=>P("")} />`}
        ${K&&w&&$`
            <${ve} 
                t=${r}
                originalUrl=${w} 
                generatedUrl=${K}
                onClose=${()=>R(null)}
                toggleView=${!0}
                caption=${r("detailedComparison")}
            />
        `}
        <div class="editor-layout ${oe?"":"panel-hidden"}">
            <div 
                class="image-panel droppable ${N?"drag-over":""}"
                onDragOver=${s=>{s.preventDefault(),s.stopPropagation(),H(!0)}}
                onDragEnter=${s=>{s.preventDefault(),s.stopPropagation(),H(!0)}}
                onDragLeave=${s=>{s.preventDefault(),s.stopPropagation(),H(!1)}}
                onDrop=${de}
            >
                ${E&&$`<${De} text=${ee} t=${r} />`}
                ${w?$`
                    <${Ee} 
                        t=${r}
                        original=${w} 
                        generated=${b} 
                        view=${k} 
                        sliderMode=${x} 
                        sideBySideMode=${z}
                        onClick=${()=>b&&!x&&!z&&R(b)} 
                    />
                     ${W.length>1&&$`
                        <div class="thumbnail-gallery">
                            ${W.map((s,d)=>$`
                                <div class="thumbnail-item">
                                    <img 
                                        src=${s} 
                                        alt="${r("generatedAlt",{index:String(d+1)})}" 
                                        class=${b===s?"active":""}
                                        onClick=${()=>F(s)}
                                    />
                                </div>
                            `)}
                        </div>
                    `}
                    <div class="actions">
                         <button class="btn upload-another-btn" onClick=${o} disabled=${E}>
                            <${$e} />
                            <span>${r("uploadNew")}</span>
                        </button>
                        <button class="btn compare-btn" onClick=${()=>J(s=>s==="original"?"generated":"original")} disabled=${!b||x||z}>
                            <${Re} />
                            <span>${r("compare")}</span>
                        </button>
                         <button class="btn slider-btn ${x?"active":""}" onClick=${ie} disabled=${!b}>
                            <${xe} />
                            <span>${r("sliderMode")}</span>
                        </button>
                        <button class="btn side-by-side-btn ${z?"active":""}" onClick=${le} disabled=${!b}>
                            <${Le} />
                            <span>${r("sideBySide")}</span>
                        </button>
                        <button class="btn" onClick=${ae} disabled=${E}>
                            <${we} />
                            <span>${r("regenerate")}</span>
                        </button>
                        <button class="btn" onClick=${()=>ge(b)} disabled=${!b}>
                            <${ye} />
                            <span>${r("download")}</span>
                        </button>
                         <button class="btn" onClick=${()=>{b&&(_(b),D())}} disabled=${!b}>
                            <${Ue} />
                            <span>${r("useThisImage")}</span>
                        </button>
                    </div>
                `:$`
                    <${_e} onImageUpload=${_} t=${r} />
                `}
            </div>
             <${be} 
                settings=${U} 
                setSettings=${s=>A(s)} 
                onGenerate=${ae} 
                generating=${E} 
                hasImage=${!!w} 
                buttonText=${r("button_restore_photo_enter")}
                onBackToHome=${D}
                onChooseAnotherImage=${o}
                currentImage=${w}
                t=${r}
                language=${h}
                setLanguage=${se}
            />
        </div>
    `},We=S=>{const{onBackToHome:C,t:o,language:D,setLanguage:_}=S,[r,h]=l([]),se={background:"auto",colorize:!1,sharpenBackground:!0,highQuality:!1,isVietnamese:!0,numberOfPeople:"",gender:"unknown",ageRange:"unknown",smile:"unknown",clothingPrompt:"",advancedPrompt:"",numberOfResults:1,aiProvider:"haipix",haipixModel:"google_image_gen_banana_3",haipixMode:"vip1",haipixRatio:"auto",haipixResolution:"5k"},[O,w]=l(se),[Z,W]=l(!1),[V,b]=l(0),[F,E]=l(0),[X,q]=l(0),[P,k]=l(""),[J,K]=l(!1),[R,x]=l(null),[G,z]=l(!0),[L,U]=l(!1),[A,N]=l(null),[H,oe]=l([]);M(()=>{Be("image").then(oe).catch(e=>console.error("Models fetch error",e))},[]);const j=async(e,a,t)=>{if(!A||A.length===0)return;const n=[...A];N(null),k("");const i=new Set(n.map(c=>c.id));h(c=>c.map(g=>i.has(g.id)?{...g,status:"processing",processingPhase:"uploading",processingStartTime:Date.now()}:g)),n.forEach(async c=>{const g=c.id,u=c.generated||c.original;try{const p=await Ne(u),{url:m}=await Fe(p,void 0,1e3),v=await Ge(e,"upscale",void 0,void 0,void 0,a,t,void 0,Q=>{h(B=>B.map(ue=>ue.id===g?{...ue,processingPhase:Q}:ue))},m),I=await He(v);h(Q=>Q.map(B=>B.id===g?{...B,generated:v,status:"done",processingPhase:"done",width:I.width,height:I.height}:B))}catch(p){const m=ne(p,o);k(m),h(v=>v.map(I=>I.id===g?{...I,status:"error",error:m}:I))}})};M(()=>{const e=a=>{if(a.key==="*"){const t=a.target;["INPUT","TEXTAREA","SELECT"].includes(t.tagName)||(a.preventDefault(),z(n=>!n))}};return window.addEventListener("keydown",e),()=>window.removeEventListener("keydown",e)},[]);const Y=e=>new Promise((a,t)=>{const n=new FileReader;n.onload=()=>a(n.result),n.onerror=()=>t(new Error(`Lỗi đọc file: ${e.name}`)),n.readAsDataURL(e)}),ee=e=>{if(!e)return;e.length>0&&!document.fullscreenElement&&document.documentElement.requestFullscreen().catch(t=>{console.warn(`Could not enter fullscreen mode: ${t.message}`)});const a=Array.from(e).map(t=>({id:Date.now()+Math.random(),file:t,original:URL.createObjectURL(t),generated:null,status:"pending",selected:!0}));h(t=>[...t,...a])};M(()=>{const e=async a=>{var c;const t=a.target;if(["INPUT","TEXTAREA","SELECT"].includes(t.tagName))return;const n=(c=a.clipboardData)==null?void 0:c.items;if(!n)return;const i=[];for(let g=0;g<n.length;g++){const u=n[g];if(u.type.startsWith("image/")){const p=u.getAsFile();p&&i.push(p)}}if(i.length>0){a.preventDefault();const g=i.map(u=>({id:Date.now()+Math.random(),file:u,original:URL.createObjectURL(u),generated:null,status:"pending",selected:!0}));h(u=>[...u,...g])}};return document.addEventListener("paste",e),()=>document.removeEventListener("paste",e)},[]);const re=async(e,a,t)=>{let n=0;q(e.length),E(0);const i=[...e],c=async()=>{for(;i.length>0;){const g=i.shift();g&&(await t(g),n++,E(u=>u+1),b(Math.round(n/e.length*100)),i.length>0&&await new Promise(u=>setTimeout(u,2e3)))}};await Promise.all(Array(a).fill(null).map(()=>c()))},te=fe(async()=>{W(!0),b(0),k("");const e=r.filter(t=>t.selected&&(t.status==="pending"||t.status==="error"));q(e.length);const a=async t=>{h(n=>n.map(i=>i.id===t.id?{...i,status:"processing",processingStartTime:Date.now(),processingPhase:"uploading"}:i));try{const n=await Y(t.file),i=t.settings||O,{numberOfResults:c,...g}=i,u=await pe(n,g,p=>{h(m=>m.map(v=>v.id===t.id?{...v,processingPhase:p}:v))});h(p=>p.map(m=>m.id===t.id?{...m,generated:u,status:"done",processingPhase:"done"}:m))}catch(n){throw k(ne(n,o)),console.error(`Error processing image ${t.id}:`,n),h(i=>i.map(c=>c.id===t.id?{...c,status:"error"}:c)),n}};try{await re(e,1,a)}catch(t){console.error(o("batch_processing_stopped"),t)}finally{W(!1)}},[r,O,o]),ae=async e=>{const a=r.find(t=>t.id===e);if(a){k(""),h(t=>t.map(n=>n.id===e?{...n,status:"processing",processingStartTime:Date.now(),processingPhase:"uploading"}:n));try{const t=await Y(a.file),n=a.settings||O,{numberOfResults:i,...c}=n,g=await pe(t,c,u=>{h(p=>p.map(m=>m.id===e?{...m,processingPhase:u}:m))});h(u=>u.map(p=>p.id===e?{...p,generated:g,status:"done",processingPhase:"done"}:p))}catch(t){k(ne(t,o)),h(n=>n.map(i=>i.id===e?{...i,status:"error"}:i))}}},ie=e=>h(a=>a.filter(t=>t.id!==e)),le=()=>h([]),ce=e=>h(a=>a.map(t=>t.id===e?{...t,selected:!t.selected}:t)),de=()=>h(e=>e.map(a=>({...a,selected:!0}))),ge=()=>h(e=>e.map(a=>({...a,selected:!1}))),s=e=>{ee(e.currentTarget.files),e.currentTarget.value=""},d=(e,a)=>{e.preventDefault(),e.stopPropagation(),K(a)},y=e=>{var a;d(e,!1),ee(((a=e.dataTransfer)==null?void 0:a.files)||null)},f=async e=>{var t;e.preventDefault(),e.stopPropagation();const a=r.filter(n=>n.selected&&n.generated);if(a.length!==0){U(!0),k("");try{const{default:n}=await Ie(async()=>{const{default:m}=await import("https://cdn.jsdelivr.net/npm/jszip@3.10.1/+esm");return{default:m}},[]),i=new n;let c=0;for(let m=0;m<a.length;m++){const v=a[m];if(v.generated)try{const I=await Ve(v.generated),Q=((t=v.generated.split(".").pop())==null?void 0:t.split("?")[0])||"png",B=`${String(m+1).padStart(3,"0")}_${v.file.name.split(".")[0]}-restored.${Q}`;i.file(B,I),c++}catch(I){console.error("Error fetching image for zip:",I)}}if(c===0)throw new Error("Không thể tải được ảnh nào do lỗi kết nối hoặc CORS.");const g=await i.generateAsync({type:"blob"}),u=URL.createObjectURL(g),p=document.createElement("a");p.href=u,p.download=`restored-photos-${new Date().toISOString().slice(0,10)}.zip`,document.body.appendChild(p),p.click(),document.body.removeChild(p),URL.revokeObjectURL(u)}catch(n){console.error("Error creating zip:",n),k("Lỗi khi tải xuống: "+n.message)}finally{U(!1)}}},T=Pe(()=>r.filter(e=>e.selected&&(e.status==="pending"||e.status==="error")).length,[r]);return $`
        ${R&&R.generated&&$`
            <${ve} 
                t=${o}
                originalUrl=${R.original} 
                generatedUrl=${R.generated}
                onClose=${()=>x(null)}
                caption=${o("detailedComparison")}
                toggleView=${!0}
            />
        `}
        <div class="editor-layout batch-background-view ${G?"":"panel-hidden"}">
            <div class="image-panel droppable ${J?"drag-over":""}" onDragOver=${e=>d(e,!0)} onDragEnter=${e=>d(e,!0)} onDragLeave=${e=>d(e,!1)} onDrop=${y}>
               <div style=${{width:"100%",display:"flex",flexDirection:"column",height:"100%",padding:"1.5rem"}}>
                    <div class="actions" style=${{position:"relative",bottom:"auto",right:"auto",justifyContent:"space-between",marginBottom:"1rem",flexWrap:"wrap",gap:"0.5rem"}}>
                        <button class="btn" onClick=${()=>{var e;return(e=document.getElementById("batch-restoration-file-input"))==null?void 0:e.click()}}><${$e} /> ${o("add_images")}</button>
                        <div style=${{display:"flex",gap:"0.5rem"}}>
                            <button class="btn btn-secondary" onClick=${de}>${o("select_all")}</button>
                            <button class="btn btn-secondary" onClick=${ge}>${o("deselect_all")}</button>
                            <button class="btn btn-secondary" onClick=${le} disabled=${r.length===0}>${o("delete_all")}</button>
                        </div>
                        <input type="file" id="batch-restoration-file-input" multiple accept="image/*" style=${{display:"none"}} onChange=${s} />
                        <button 
                            type="button" 
                            class="btn btn-secondary" 
                            onClick=${()=>{const e=r.filter(a=>a.selected);e.length>0?N(e):alert(o("button_select_to_ai_edit"))}} 
                            disabled=${r.filter(e=>e.selected).length===0}
                            title=${o("label_upscale")}
                        >
                            <${he} /> ${o("label_upscale")}
                        </button>
                        <button class="btn btn-primary" onClick=${f} disabled=${L||r.every(e=>!e.generated)}><${ye} /> ${o(L?"zipping":"download_all")}</button>
                    </div>
                    ${Z&&$`<div class="progress-container"><div class="progress-bar"><div class="progress-bar-inner" style=${{width:`${V}%`}}></div><span class="progress-label">${V}%</span></div><span class="progress-counter">${F} / ${X}</span></div>`}
                    ${P&&$`<div class="error-message" style=${{marginTop:"1rem"}}>${P}</div>`}
                    <div class="batch-grid" style=${{flex:1,overflowY:"auto"}}>
                        ${r.length===0?$`
                            <div class="upload-placeholder" onClick=${()=>{var e;return(e=document.getElementById("batch-restoration-file-input"))==null?void 0:e.click()}} style=${{gridColumn:"1 / -1",height:"100%",minHeight:"400px",alignSelf:"stretch"}}>
                                <${$e} />
                                <strong>${o("upload_multiple_prompt_title")}</strong>
                                <p>${o("upload_restoration_prompt")}</p>
                            </div>
                        `:r.map(e=>$`
                            <div class="batch-item ${e.selected?"selected":""} ${e.generated?"has-generated":""} ${e.status==="error"?"error":""}">
                                <div class="selection-checkbox" onClick=${()=>ce(e.id)}><div class="checkbox-visual"><${me} /></div></div>
                                <div class="image-comparator" style=${{display:"block"}} onClick=${()=>e.generated&&x(e)}>
                                    <div class="image-container ${e.generated?"has-result":""}">
                                        <img src=${e.generated||e.original} onMouseEnter=${a=>{e.generated&&(a.target.src=e.original)}} onMouseLeave=${a=>{e.generated&&(a.target.src=e.generated)}} />
                                        ${e.status==="processing"&&$`<${ke} startTime=${e.processingStartTime} phase=${e.processingPhase} t=${o} />`}
                                        ${e.status==="done"&&$`<div class="batch-item-status-icon"><${me} /></div>`}
                                        ${e.status==="error"&&$`<div class="error-badge" title="${e.error||o("error")}" onClick=${a=>{a.stopPropagation(),alert(e.error||o("error"))}}>${o("error")}</div>`}
                                    </div>
                                </div>
                                <div class="batch-item-actions">
                                    <button class="batch-item-btn" title=${o("regenerate")} onClick=${()=>ae(e.id)}><${we} /></button>
                                    <button class="batch-item-btn" title="Nâng cao chất lượng (Upscale)" onClick=${()=>N([e])}><${he} /></button>
                                    <button class="batch-item-btn" title=${o("delete")} onClick=${()=>ie(e.id)}><${Me} /></button>
                                </div>
                            </div>
                        `)}
                    </div>
               </div>
            </div>
            ${A&&$`
                <${ze} 
                    targetImages=${A.map(e=>({id:e.id,url:e.generated||e.original}))}
                    models=${H}
                    onClose=${()=>N(null)}
                    onConfirm=${j}
                    t=${o}
                />
            `}
            <${be} 
                settings=${O} 
                setSettings=${w} 
                onGenerate=${te} 
                generating=${Z} 
                hasImage=${T>0} 
                buttonText=${T>0?o("button_restore_batch",{count:String(T)}):o("button_select_to_restore")} 
                isBatch=${!0} 
                onBackToHome=${C} 
                onChooseAnotherImage=${()=>{var e;return(e=document.getElementById("batch-restoration-file-input"))==null?void 0:e.click()}} 
                t=${o} 
                language=${D} 
                setLanguage=${_}
            />
        </div>
    `},Je=S=>{const[C,o]=l("single"),{t:D}=S;return $`
        <div style=${{height:"100%",display:"flex",flexDirection:"column"}}>
            <div class="page-tabs">
                <button class="page-tab ${C==="single"?"active":""}" onClick=${()=>o("single")}>${D("singlePhoto")}</button>
                <button class="page-tab ${C==="batch"?"active":""}" onClick=${()=>o("batch")}>${D("batchPhoto")}</button>
            </div>
            <div style=${{flex:1,minHeight:0}}>
                ${C==="single"?$`<${je} ...${S} />`:$`<${We} ...${S} />`}
            </div>
        </div>
    `};export{Je as RestorationApp,Je as default};
