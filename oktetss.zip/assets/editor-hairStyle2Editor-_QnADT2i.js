import{H as Be,P as Fe,_ as ze}from"./editor-aiEditor-Dm1L4C_K.js";import{d as p,A as We,y as D,q as z,T as He,_ as Ge}from"./vendor-bdgQI7wY.js";import{k as Oe,l as ae,m as W,U as ne,n as je,D as Ve,e as Ne,L as qe,o as Ze,p as Je,q as Xe,r as Ye,s as Ke,h as Qe,t as et,g as tt,u as at,v as nt}from"./editor-MotionEditor-B8LJN4fm.js";import{C as se,U as st,u as ot}from"./editor-common-ColFbeBm.js";const u=Qe.bind(Ge),dt=oe=>{var te;const{onBackToHome:re,initialFiles:w,t:s,language:H,setLanguage:ie}=oe,[h,d]=p([]),[C,T]=p({prompt:"",assistantImage:null,assistantPrompt:"",numImages:1,aiProvider:"haipix",haipixModel:"google_image_gen_banana_3",haipixMode:"vip1",haipixRatio:"auto",haipixResolution:"5k",keepPose:!0,keepComposition:!0,keepFocalLength:!0,keepAspectRatio:!0,useRimLight:!1,rimLightDirection:"left",rimLightIntensity:"medium",useGoldenHourBacklight:!1}),[G,k]=p(!1),[O,j]=p(0),[le,V]=p(0),[ce,N]=p(0),[q,$]=p(""),[de,pe]=p(!1),[I,Z]=p(null),J=We(!1),[ge,ue]=p(!0),[X,Y]=p(!1),[he,R]=p(!1),[K,b]=p(null),[x,L]=p(null),[P,S]=p(null),[me,U]=p(!1),[Q,E]=p(!1),[v,A]=p(null),[fe,$e]=p([]);D(()=>{Oe("image").then($e).catch(e=>console.error("Models fetch error",e))},[]);const be=[{label:"Tự do",value:0},{label:"16:9",value:16/9},{label:"4:3",value:4/3},{label:"1:1",value:1},{label:"3:4",value:3/4},{label:"9:16",value:9/16}],ve=z((e,a=-1)=>{const t=new FileReader;t.onload=n=>{b(n.target.result),L(a),R(!0)},t.readAsDataURL(e)},[]),ye=e=>{T(a=>{const t=[...a.detailReferences||[]];return x===-1?t.push({id:Date.now().toString(),url:e,note:""}):x!==null&&x>=0&&(t[x].url=e),{...a,detailReferences:t}}),R(!1),b(null),L(null)},we=()=>{R(!1),E(!1),b(null),L(null)},Ce=z(e=>{const a=new FileReader;a.onload=t=>{b(t.target.result),E(!0)},a.readAsDataURL(e)},[]),ke=async(e,a,t)=>{if(!v||v.length===0)return;const n=[...v];A(null),$("");const o=new Set(n.map(c=>c.id));d(c=>c.map(i=>o.has(i.id)?{...i,status:"processing",processingPhase:"uploading",processingStartTime:Date.now()}:i)),n.forEach(async c=>{const i=c.id,r=c.generated||c.original;try{const l=await ot(r),{url:g}=await at(l,void 0,1e3),m=await nt(e,"upscale",void 0,void 0,void 0,a,t,void 0,f=>{d(y=>y.map(F=>F.id===i?{...F,processingPhase:f}:F))},g);d(f=>f.map(y=>y.id===i?{...y,generated:m,status:"done",processingPhase:"done"}:y))}catch(l){console.error("Upscale error for "+i,l);const g=W(l,s);$(g),d(m=>m.map(f=>f.id===i?{...f,status:"error",error:g}:f))}})},Ie=async e=>{E(!1),b(null),k(!0);try{const a=await tt(e,"custom",H,"concise",s("prompt_auto_analyze_hair"));T(t=>({...t,prompt:t.prompt?`${t.prompt} ${a} `:a}))}catch(a){console.error(a),alert(s("error_describe_failed"))}finally{k(!1)}},xe=e=>{P!==null&&(d(a=>a.map(t=>t.id===P?{...t,original:e}:t)),S(null))};D(()=>{const e=a=>{if(a.key==="*"){const t=a.target;["INPUT","TEXTAREA","SELECT"].includes(t.tagName)||(a.preventDefault(),ue(n=>!n))}};return window.addEventListener("keydown",e),()=>window.removeEventListener("keydown",e)},[]),D(()=>{w&&w.length>0&&!J.current&&(J.current=!0,M(w))},[w]),D(()=>{const e=async a=>{var c;const t=a.target;if(["INPUT","TEXTAREA","SELECT"].includes(t.tagName))return;const n=(c=a.clipboardData)==null?void 0:c.items;if(!n)return;const o=[];for(let i=0;i<n.length;i++){const r=n[i];if(r.type.startsWith("image/")){const l=r.getAsFile();l&&o.push(l)}}if(o.length>0){a.preventDefault();const i=o.map(r=>({id:Date.now()+Math.random(),file:r,original:URL.createObjectURL(r),generated:null,status:"pending",selected:!0}));d(r=>[...r,...i])}};return document.addEventListener("paste",e),()=>document.removeEventListener("paste",e)},[]);const ee=e=>new Promise((a,t)=>{const n=new FileReader;n.onload=()=>a(n.result),n.onerror=()=>t(new Error(`Lỗi đọc file: ${e.name}`)),n.readAsDataURL(e)}),M=e=>{if(!e)return;const a=Array.from(e).map(t=>({id:Date.now()+Math.random(),file:t,original:URL.createObjectURL(t),generated:null,status:"pending",selected:!0}));d(t=>[...t,...a])},Pe=async(e,a,t)=>{let n=0;N(e.length),V(0);const o=[...e],c=async()=>{for(;o.length>0;){const i=o.shift();i&&(await t(i),n++,V(r=>r+1),j(Math.round(n/e.length*100)),o.length>0&&await new Promise(r=>setTimeout(r,2e3)))}};await Promise.all(Array(a).fill(null).map(()=>c()))},_e=z(async()=>{k(!0),j(0),$("");const e=h.filter(t=>t.selected&&(t.status==="pending"||t.status==="error"));N(e.length);const a=async t=>{d(n=>n.map(o=>o.id===t.id?{...o,status:"processing",processingStartTime:Date.now(),processingPhase:"uploading"}:o));try{const n=t.original.startsWith("data:")?t.original:await ee(t.file),{numImages:o,...c}=C,i={...c,hasPaintedMask:t.original.startsWith("data:")},r=await ae(n,i,l=>{d(g=>g.map(m=>m.id===t.id?{...m,processingPhase:l}:m))});d(l=>l.map(g=>g.id===t.id?{...g,generated:r,status:"done",processingPhase:"done"}:g))}catch(n){throw $(W(n,s)),console.error(`Error processing image ${t.id}:`,n),d(o=>o.map(c=>c.id===t.id?{...c,status:"error"}:c)),n}};try{await Pe(e,1,a)}catch(t){console.error(s("batch_processing_stopped"),t)}finally{k(!1)}},[h,C,s]),De=async e=>{const a=h.find(t=>t.id===e);if(a){d(t=>t.map(n=>n.id===e?{...n,status:"processing",generated:null,processingStartTime:Date.now(),processingPhase:"uploading"}:n)),$("");try{const t=a.original.startsWith("data:")?a.original:await ee(a.file),{numImages:n,...o}=C,c={...o,hasPaintedMask:a.original.startsWith("data:")},i=await ae(t,c,r=>{d(l=>l.map(g=>g.id===e?{...g,processingPhase:r}:g))});d(r=>r.map(l=>l.id===e?{...l,generated:i,status:"done",processingPhase:"done"}:l))}catch(t){$(W(t,s)),d(n=>n.map(o=>o.id===e?{...o,status:"error"}:o))}}},Te=e=>d(a=>a.filter(t=>t.id!==e)),Re=e=>d(a=>a.map(t=>t.id===e?{...t,selected:!t.selected}:t)),Le=()=>d(e=>e.map(a=>({...a,selected:!0}))),Se=()=>d(e=>e.map(a=>({...a,selected:!1}))),Ue=e=>{M(e.currentTarget.files),e.currentTarget.value=""},_=(e,a)=>{e.preventDefault(),e.stopPropagation(),pe(a)},Ee=e=>{var a;_(e,!1),M(((a=e.dataTransfer)==null?void 0:a.files)||null)},Ae=async e=>{e.preventDefault(),e.stopPropagation();const a=h.filter(t=>t.selected&&t.generated);if(a.length!==0){Y(!0);try{const{default:t}=await ze(async()=>{const{default:l}=await import("https://cdn.jsdelivr.net/npm/jszip@3.10.1/+esm");return{default:l}},[]),n=new t;let o=0;for(let l=0;l<a.length;l++){const g=a[l];if(g.generated)try{const m=await et(g.generated),f=`${String(l+1).padStart(3,"0")}_${g.file.name.split(".")[0]}-hair-style-2.png`;n.file(f,m),o++}catch(m){console.error("Error fetching image for zip:",m)}}if(o===0)throw new Error("Không thể tải được ảnh nào do lỗi kết nối hoặc CORS.");const c=await n.generateAsync({type:"blob"}),i=URL.createObjectURL(c),r=document.createElement("a");r.href=i,r.download=`hair-style-2-${new Date().toISOString().slice(0,10)}.zip`,document.body.appendChild(r),r.click(),document.body.removeChild(r),URL.revokeObjectURL(i)}catch(t){console.error("Error creating zip:",t),alert("Lỗi khi tải xuống: "+t.message+`

Giải pháp: Bấm vào từng ảnh để xem to rồi chuột phải chọn "Lưu hình ảnh thành..."`)}finally{Y(!1)}}},B=He(()=>h.filter(e=>e.selected&&(e.status==="pending"||e.status==="error")).length,[h]),Me=B>0?s("button_generate_photo_enter",{count:String(B)}):s("button_select_to_generate");return u`
        ${I&&I.generated&&u`
            <${qe}
                t=${s}
                originalUrl=${I.original}
                generatedUrl=${I.generated}
                onClose=${()=>Z(null)}
                caption=${s("detailedComparison")}
                toggleView=${!0}
            />
        `}
        ${me&&u`
             <div class="modal-overlay" onClick=${()=>U(!1)} style=${{position:"fixed",top:0,left:0,right:0,bottom:0,background:"rgba(0,0,0,0.85)",zIndex:9999,display:"flex",alignItems:"center",justifyContent:"center",padding:"1rem"}}>
                <div class="modal-content" onClick=${e=>e.stopPropagation()} style=${{background:"var(--card-bg)",borderRadius:"16px",maxWidth:"700px",width:"100%",maxHeight:"90vh",overflowY:"auto",padding:"2rem",border:"1px solid var(--border-color)",boxShadow:"0 20px 60px rgba(0,0,0,0.5)"}}>
                    <h2>${s("guide_title")}</h2>
                    <p>${s("tabDescription_hair-style-2")}</p>
                    <button onClick=${()=>U(!1)} style=${{width:"100%",marginTop:"1.5rem",padding:"12px",background:"linear-gradient(90deg, #4dabf7, #9775fa)",border:"none",borderRadius:"8px",color:"white",fontWeight:"bold",cursor:"pointer",fontSize:"1rem"}}>${s("close")}</button>
                </div>
            </div>
        `}
        <div class="editor-layout batch-background-view ${ge?"":"panel-hidden"}">
             <div class="image-panel droppable ${de?"drag-over":""}" onDragOver=${e=>_(e,!0)} onDragEnter=${e=>_(e,!0)} onDragLeave=${e=>_(e,!1)} onDrop=${Ee}>
                <div style=${{width:"100%",display:"flex",flexDirection:"column",height:"100%",padding:"1.5rem"}}>
                    <div class="actions" style=${{position:"relative",bottom:"auto",right:"auto",justifyContent:"space-between",marginBottom:"1rem",flexWrap:"wrap",gap:"0.5rem"}}>
                        <div style=${{display:"flex",gap:"0.5rem"}}>
                            <button class="btn" onClick=${()=>{var e;return(e=document.getElementById("hair-style-2-file-input"))==null?void 0:e.click()}}><${ne} /> ${s("add_images")}</button>
                            <button class="btn btn-secondary" onClick=${Le}>${s("select_all")}</button>
                            <button class="btn btn-secondary" onClick=${Se}>${s("deselect_all")}</button>
                        </div>
                        <input type="file" id="hair-style-2-file-input" multiple accept="image/*" style=${{display:"none"}} onChange=${Ue} />
                         <div style=${{display:"flex",gap:"5px"}}>
                              <button 
                                type="button" 
                                class="btn btn-secondary" 
                                onClick=${()=>{const e=h.filter(a=>a.selected);e.length>0?A(e):alert(s("button_select_to_ai_edit"))}} 
                                disabled=${h.filter(e=>e.selected).length===0}
                                title=${s("label_upscale")}
                            >
                                <${je} /> ${s("label_upscale")}
                            </button>
                             <button type="button" class="btn" onClick=${()=>U(!0)} style=${{border:"2px solid #ff4d4f",color:"#ff4d4f",fontWeight:"bold"}}>Hướng Dẫn</button>
                             <button type="button" class="btn btn-primary" onClick=${e=>{e.preventDefault(),e.stopPropagation(),Ae(e)}} disabled=${X||h.filter(e=>e.selected&&e.generated).length===0}><${Ve} /> ${s(X?"zipping":"download_all")}</button>
                        </div>
                    </div>
                    ${G&&u`<div class="progress-container"><div class="progress-bar"><div class="progress-bar-inner" style=${{width:`${O}%`}}></div><span class="progress-label">${O}%</span></div><span class="progress-counter">${le} / ${ce}</span></div>`}
                    ${q&&u`<div class="error-message" style=${{marginTop:"1rem"}}>${q}</div>`}
                    <div class="batch-grid" style=${{flex:1,overflowY:"auto",alignContent:"flex-start"}}>
                        ${h.length===0?u`
                            <div class="upload-placeholder" onClick=${()=>{var e;return(e=document.getElementById("hair-style-2-file-input"))==null?void 0:e.click()}} style=${{gridColumn:"1 / -1",height:"100%",minHeight:"400px",alignSelf:"stretch"}}>
                                <${ne} /><strong>${s("upload_multiple_prompt_title")}</strong><p>${s("uploader_drag_drop_prompt")}</p>
                            </div>`:h.map(e=>u`
                            <div class="batch-item ${e.selected?"selected":""} ${e.generated?"has-generated":""} ${e.status==="error"?"error":""}">
                                <div class="selection-checkbox" onClick=${()=>Re(e.id)}><div class="checkbox-visual"><${se} /></div></div>
                                <div class="image-comparator" style=${{display:"block"}} onClick=${()=>e.generated&&Z(e)}>
                                    <div class="image-container ${e.generated?"has-result":""}">
                                        <img src=${e.generated||e.original} onMouseEnter=${a=>{e.generated&&(a.target.src=e.original)}} onMouseLeave=${a=>{e.generated&&(a.target.src=e.generated)}} />
                                        ${e.status==="processing"&&u`<${Fe} startTime=${e.processingStartTime} phase=${e.processingPhase} t=${s} />`}
                                        ${e.status==="done"&&u`<div class="batch-item-status-icon"><${se} /></div>`}
                                        ${e.status==="error"&&u`<div class="error-badge" title="${e.error||s("error")}" onClick=${a=>{a.stopPropagation(),alert(e.error||s("error"))}}>${s("error")}</div>`}
                                    </div>
                                </div>
                                <div class="batch-item-actions">
                                    <button class="batch-item-btn" title="Bút Vẽ" onClick=${a=>{a.stopPropagation(),S(e.id)}}><${Ze} /></button>
                                    <button class="batch-item-btn" title=${s("regenerate")} onClick=${()=>De(e.id)}><${Je} /></button>
                                    <button class="batch-item-btn" title=${s("delete")} onClick=${()=>Te(e.id)}><${Xe} /></button>
                                </div>
                            </div>`)}
                    </div>
                    <${Ne} t=${s} style=${{marginTop:"0.5rem",marginBottom:"0.5rem",fontSize:"10px",padding:"2px 8px",width:"fit-content",margin:"0 auto",opacity:.7,borderRadius:"4px",display:"flex",gap:"5px",flexWrap:"wrap",justifyContent:"center"}} />
                </div>
            </div>
            <${Be} 
                settings=${C} 
                setSettings=${T} 
                onGenerate=${_e} 
                generating=${G} 
                hasImage=${B>0} 
                buttonText=${Me} 
                isBatch=${!0} 
                onBackToHome=${re} 
                onChooseAnotherImage=${()=>{var e;return(e=document.getElementById("hair-style-2-file-input"))==null?void 0:e.click()}} 
                t=${s} 
                language=${H} 
                setLanguage=${ie}
                onLaunchDetailRefCrop=${ve}
                onLaunchAssistantCrop=${Ce}
            />
            ${P!==null&&u`
                <${Ye}
                    t=${s}
                    imageUrl=${((te=h.find(e=>e.id===P))==null?void 0:te.original)||""}
                    onSave=${xe}
                    onCancel=${()=>S(null)}
                />
            `}
            ${(he||Q)&&K&&u`
                <${Ke} 
                    t=${s}
                    imageUrl=${K} 
                    onCrop=${Q?Ie:ye}
                    onCancel=${we}
                    aspectRatios=${be}
                    warning=${`1. crop cận nguyên vật thể cần tham chiếu
2. nếu sử dụng quá nhiều tham chiếu có thể gây biến dị cho người mẫu
Chú ý: 1 công cụ sáng tạo mới đa nhiệp vụ hãy cùng sáng tạo tùy biến`}
                />
            `}
            ${v&&u`
                <${st}
                    targetImages=${v.map(e=>({id:e.id,url:e.generated||e.original}))}
                    models=${fe}
                    onClose=${()=>A(null)}
                    onConfirm=${ke}
                    t=${s}
                />
            `}
        </div>
    `};export{dt as default};
