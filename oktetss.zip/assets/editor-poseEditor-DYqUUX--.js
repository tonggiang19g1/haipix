import{d as oe,P as re,_ as ae}from"./editor-aiEditor-Dm1L4C_K.js";import{d as I,A as V,y as F,_ as ne}from"./vendor-bdgQI7wY.js";import{i as ie,a9 as k,k as se,D as M,n as K,q as le,U as ce,M as pe,T as O,h as de,t as me,m as q,u as fe,v as ge}from"./editor-MotionEditor-B8LJN4fm.js";import{S as he,U as ue,u as xe}from"./editor-common-ColFbeBm.js";const g=de.bind(ne),ye=({settings:s,setSettings:P,t:i,onGenerate:R,generating:S,onSelect:C,originalImage:L})=>{const y=s.faceGroups||[],[U,j]=I([]),[W,B]=I({}),[d,a]=I(null),[$,w]=I([]),[b,u]=I({}),[f,G]=I(new Set),[x,A]=I(null);F(()=>{se("image").then(w).catch(e=>console.error("Models fetch error",e))},[]);const h=async(e,o,n)=>{if(!d||d.length===0)return;const t=[...d];a(null),G(new Set);for(const l of t){const{groupId:r,resultIndex:c,url:m}=l,p=`${r}-${c}`;u(D=>({...D,[p]:{status:"processing",processingPhase:"uploading",startTime:Date.now()}}));try{const D=await xe(m),{url:H}=await fe(D,void 0,1e3);ge(e,"upscale",void 0,void 0,void 0,o,n,void 0,_=>{u(T=>({...T,[p]:{...T[p],processingPhase:_}}))},H).then(_=>{u(T=>({...T,[p]:{status:"done",generated:_}}))}).catch(_=>{const T=q(_,i);u(te=>({...te,[p]:{status:"error",error:T}}))})}catch(D){const H=q(D,i);u(_=>({..._,[p]:{status:"error",error:H}}))}}},v=(e,o)=>{const n=`${e}-${o}`,t=new Set(f);t.has(n)?t.delete(n):t.add(n),G(t)},z=()=>{const e=[];y.forEach(o=>{o.results&&o.results.forEach((n,t)=>{const l=`${o.id}-${t}`;if(f.has(l)){const r=b[l],c=(r==null?void 0:r.generated)||n;e.push({groupId:o.id,resultIndex:t,url:c})}})}),e.length>0&&a(e)},J=()=>{P(e=>{const o=e.faceGroups||[];return{...e,faceGroups:[...o,{id:Date.now().toString()+"-"+Math.random().toString(36).substr(2,9),images:[],results:[]}]}})},N=e=>{P(o=>({...o,faceGroups:(o.faceGroups||[]).filter(n=>n.id!==e)}))},Z=async(e,o)=>{const n=Array.from(o).filter(l=>l.type.startsWith("image/")),t=await Promise.all(n.map(l=>new Promise(r=>{const c=new FileReader;c.onload=m=>{var p;return r((p=m.target)==null?void 0:p.result)},c.readAsDataURL(l)})));P(l=>({...l,faceGroups:(l.faceGroups||[]).map(r=>r.id===e?{...r,images:[...r.images,...t]}:r)}))},X=(e,o)=>{P(n=>({...n,faceGroups:(n.faceGroups||[]).map(t=>{if(t.id===e){const l=[...t.images];return l.splice(o,1),{...t,images:l}}return t})}))},Y=async e=>{const o=y.find(t=>t.id===e);if(!o)return;if(o.images.length===0){alert(i("error_no_faces")||"Vui lòng thêm ít nhất một ảnh khuôn mặt vào nhóm.");return}const n=L||s.faceReferenceImage||o.images[0];j(t=>[...t,e]),B(t=>({...t,[e]:Date.now()}));try{const t=[],l=s.myPrompt&&s.myPrompt.trim()||s.selectedPoses.length>0||s.customPosePrompts.filter(r=>r.trim()!=="").length>0;if(s.myPrompt&&s.myPrompt.trim()){const r=Array.from({length:s.numImages},()=>k(n,s.myPrompt,s,s.faceReferenceImage,o.images));t.push(...r)}for(const r of s.selectedPoses)if(r){const c=Array.from({length:s.numImages},()=>k(n,r,s,s.faceReferenceImage,o.images));t.push(...c)}for(const r of s.customPosePrompts.filter(c=>c.trim()!=="")){const c=Array.from({length:s.numImages},()=>k(n,r,s,s.faceReferenceImage,o.images));t.push(...c)}if(!l){const r=Array.from({length:s.numImages},()=>k(n,"",s,s.faceReferenceImage,o.images));t.push(...r)}if(t.length>0){const r=await Promise.all(t);P(c=>({...c,faceGroups:(c.faceGroups||[]).map(m=>m.id===e?{...m,results:[...m.results||[],...r]}:m)})),C&&r.length>0&&C(r[0])}}catch(t){console.error("Group generation failed",t),alert(q(t,i))}finally{j(t=>t.filter(l=>l!==e))}},Q=async e=>{if(!(!e||e.length===0))for(let o=0;o<e.length;o++){const n=e[o],t=`result-${o+1}.png`;await O(n,t)}},ee=async()=>{const e=[];if(y.forEach((o,n)=>{o.results&&o.results.length>0&&o.results.forEach((t,l)=>{e.push({url:t,filename:`group-${n+1}-result-${l+1}.png`})})}),e.length===0){alert("Chưa có kết quả nào để tải.");return}try{const{default:o}=await ae(async()=>{const{default:m}=await import("https://cdn.jsdelivr.net/npm/jszip@3.10.1/+esm");return{default:m}},[]),n=new o;let t=0;if(await Promise.all(e.map(async m=>{try{const p=await me(m.url);n.file(m.filename,p),t++}catch(p){console.error("Failed to fetch image for zip",m.url,p)}})),t===0)throw new Error("Không thể tải được ảnh nào do lỗi kết nối hoặc CORS.");const l=await n.generateAsync({type:"blob"}),r=URL.createObjectURL(l),c=document.createElement("a");c.href=r,c.download=`face_swap_results_${Date.now()}.zip`,document.body.appendChild(c),c.click(),document.body.removeChild(c),setTimeout(()=>URL.revokeObjectURL(r),100)}catch(o){console.error("Error creating zip:",o),alert("Lỗi khi tải ảnh: "+(o instanceof Error?o.message:String(o))+`

Giải pháp: Bấm vào từng ảnh để xem to rồi chuột phải chọn "Lưu hình ảnh thành..."`)}},E=V(null);return F(()=>{E.current&&y.length>0&&(E.current.scrollTop=E.current.scrollHeight)},[y.length]),g`
        <div class="posing-gallery-container" style=${{width:"100%",flex:1,minHeight:"250px",display:"flex",flexDirection:"column",padding:"1.5rem",paddingTop:"2rem",overflow:"hidden"}}>
            <div style=${{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"2rem",flexShrink:0,paddingBottom:"1rem",borderBottom:"1px solid var(--border-color)"}}>
                <div>
                     <h3 style=${{marginBottom:"0.5rem",marginTop:0}}>${i("section_face_images")}</h3>
                     <p style=${{opacity:.7,fontSize:"0.9em",margin:0}}>${i("note_face_images")}</p>
                </div>
                <div style=${{display:"flex",gap:"1rem"}}>
                    ${f.size>0&&g`
                        <button class="btn" style=${{padding:"6px 16px",background:"var(--accent)",color:"white",whiteSpace:"nowrap",border:"none"}} onClick=${z}>
                            <${K} style=${{width:"16px",height:"16px",marginRight:"8px"}} />
                            Upscale Selected (${f.size})
                        </button>
                    `}
                    <button class="btn btn-secondary" style=${{padding:"6px 16px",border:"1px dashed var(--accent)",color:"var(--accent)",whiteSpace:"nowrap"}} onClick=${J}>
                        <span style=${{fontSize:"1.2em",marginRight:"8px"}}>+</span> ${i("add_group")||"Thêm nhóm"}
                    </button>
                    <button 
                        class="btn btn-primary" 
                        style=${{padding:"6px 16px",whiteSpace:"nowrap"}} 
                        onClick=${ee} 
                        disabled=${!y.some(e=>e.results&&e.results.length>0)}
                    >
                        <${M} style=${{width:"16px",height:"16px",marginRight:"8px"}} />
                        ${i("download_all_results")||"Tải tất cả"}
                    </button>
                </div>
            </div>
            
            <div ref=${E} style=${{flex:1,overflowY:"auto",display:"grid",gridTemplateColumns:y.length===0?"1fr":"repeat(auto-fill, minmax(350px, 1fr))",gap:"1.5rem",paddingRight:"0.5rem",alignContent:"start"}}>
                ${y.length===0?g`
                    <div style=${{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",flex:1,opacity:.5,border:"2px dashed var(--border-color)",borderRadius:"12px",padding:"2rem"}}>
                        <p>${i("empty_groups_hint")||"Chưa có nhóm nào. Nhấn nút bên dưới để thêm nhóm mới."}</p>
                    </div>
                `:y.map((e,o)=>g`
                    <div class="face-group-card" style=${{background:"rgba(255,255,255,0.03)",borderRadius:"12px",padding:"1rem",border:"1px solid rgba(255,255,255,0.1)",boxShadow:"0 4px 12px rgba(0,0,0,0.1)",position:"relative"}}>
                        ${U.includes(e.id)&&g`
                            <div style=${{position:"absolute",top:0,left:0,right:0,bottom:0,background:"rgba(0,0,0,0.7)",zIndex:10,display:"flex",alignItems:"center",justifyContent:"center",borderRadius:"12px",backdropFilter:"blur(2px)"}}>
                                <${re} startTime=${W[e.id]} t=${i} />
                            </div>
                        `}
                        <div style=${{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"1rem",borderBottom:"1px solid rgba(255,255,255,0.05)",paddingBottom:"0.5rem"}}>
                            <h4 style=${{margin:0,color:"var(--accent)",fontSize:"1.1em"}}>${i("group")} ${o+1}</h4>
                            <div style=${{display:"flex",gap:"6px"}}>
                                <button 
                                    class="btn btn-primary" 
                                    style=${{padding:"4px 10px",minHeight:"32px",fontSize:"0.8em",display:"flex",alignItems:"center",gap:"6px"}} 
                                    onClick=${()=>Y(e.id)}
                                    disabled=${U.includes(e.id)||e.images.length===0}
                                    title=${i("button_generate_photo")}
                                >
                                    ${U.includes(e.id)?i("processing"):g`<${pe} style=${{width:"14px",height:"14px"}} /> <span>${i("create_photo")||"Tạo ảnh"}</span>`}
                                </button>
                                
                                ${e.results&&e.results.length>0&&g`
                                    <button 
                                        class="btn btn-secondary" 
                                        style=${{padding:"4px 8px",minHeight:"32px",fontSize:"0.8em",borderColor:"var(--accent)",color:"var(--accent)",display:"flex",alignItems:"center"}} 
                                        onClick=${()=>Q(e.results)}
                                        title=${i("download_results")||"Tải kết quả"}
                                    >
                                        <${M} style=${{width:"14px",height:"14px"}} />
                                    </button>
                                `}
                                
                                <button 
                                    class="btn btn-secondary" 
                                    style=${{padding:"4px 8px",minHeight:"32px",fontSize:"0.85em",color:"#ff4d4f",border:"1px solid rgba(255,77,79,0.3)",display:"flex",alignItems:"center"}} 
                                    onClick=${()=>N(e.id)}
                                    title=${i("delete")}
                                >
                                    <${le} style=${{width:"14px",height:"14px"}} />
                                </button>
                            </div>
                        </div>
                        
                        <div style=${{display:"flex",flexWrap:"wrap",gap:"12px"}}>
                            ${e.images.map((n,t)=>g`
                                <div style=${{position:"relative",width:"90px",height:"90px",borderRadius:"8px",overflow:"hidden",border:"2px solid var(--border-color)",cursor:"pointer"}} onClick=${()=>C&&C(n)}>
                                    <img src=${n} style=${{width:"100%",height:"100%",objectFit:"cover"}} />
                                    <button 
                                        style=${{position:"absolute",top:"2px",right:"2px",width:"20px",height:"20px",borderRadius:"50%",background:"rgba(255,0,0,0.8)",border:"none",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",color:"white",fontSize:"10px"}}
                                        onClick=${l=>{l.stopPropagation(),X(e.id,t)}}
                                    >✕</button>
                                </div>
                            `)}
                            <label style=${{width:"90px",height:"90px",borderRadius:"8px",border:"2px dashed var(--border-color)",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",cursor:"pointer",background:"rgba(255,255,255,0.02)"}}>
                                <input type="file" multiple accept="image/*" style=${{display:"none"}} onChange=${n=>Z(e.id,n.target.files)} />
                                <${ce} style=${{width:"24px",height:"24px",opacity:.5}} />
                                <span style=${{fontSize:"10px",marginTop:"4px",textAlign:"center"}}>${i("add_images")}</span>
                            </label>
                        </div>

                        ${e.results&&e.results.length>0&&g`
                            <div style=${{marginTop:"1rem",paddingTop:"1rem",borderTop:"1px solid rgba(255,255,255,0.05)"}}>
                                <div style=${{fontSize:"0.9em",opacity:.8,marginBottom:"0.5rem"}}>${i("results")||"Kết quả"}:</div>
                                <div style=${{display:"flex",flexWrap:"wrap",gap:"10px"}}>
                                    ${e.results.map((n,t)=>{const l=`${e.id}-${t}`,r=b[l],c=(r==null?void 0:r.generated)||n,m=f.has(l);return g`
                                            <div
                                                style=${{position:"relative",width:"80px",height:"100px",borderRadius:"4px",overflow:"hidden",border:m?"2px solid var(--accent)":"1px solid var(--border-color)",cursor:"zoom-in"}}
                                                onClick=${()=>A(c)}
                                            >
                                                <img src=${c} style=${{width:"100%",height:"100%",objectFit:"cover"}} />
                                                
                                                ${(r==null?void 0:r.status)==="processing"&&g`
                                                    <div style=${{position:"absolute",top:0,left:0,right:0,bottom:0,background:"rgba(0,0,0,0.6)",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center"}}>
                                                        <div class="spinner" style=${{width:"16px",height:"16px",borderWidth:"2px"}}></div>
                                                    </div>
                                                `}
                                                
                                                ${(r==null?void 0:r.status)==="done"&&g`
                                                    <div style=${{position:"absolute",top:"2px",left:"2px",background:"rgba(0,128,0,0.8)",padding:"1px 3px",borderRadius:"2px",fontSize:"8px",color:"white"}}>HD</div>
                                                `}
                                                
                                                ${(r==null?void 0:r.status)==="error"&&g`
                                                    <div class="error-badge" style=${{fontSize:"8px",top:"2px",right:"2px"}} title="${r.error||i("error")}" onClick=${p=>{p.stopPropagation(),alert(r.error||i("error"))}}>${i("error")}</div>
                                                `}

                                                <div 
                                                    style=${{position:"absolute",top:"2px",right:"2px",width:"16px",height:"16px",borderRadius:"4px",background:m?"var(--accent)":"rgba(0,0,0,0.5)",border:"1px solid white",display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",zIndex:5}}
                                                    onClick=${p=>{p.stopPropagation(),v(e.id,t)}}
                                                >
                                                    ${m&&g`<span style=${{color:"white",fontSize:"10px",fontWeight:"bold"}}>✓</span>`}
                                                </div>
                                                
                                                 <button 
                                                     style=${{position:"absolute",bottom:"2px",right:"2px",width:"20px",height:"20px",borderRadius:"50%",background:"rgba(0,0,0,0.6)",border:"none",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",color:"white",padding:0,zIndex:6}}
                                                     onClick=${p=>{p.stopPropagation(),a([{groupId:e.id,resultIndex:t,url:c}])}}
                                                     title="Upscale"
                                                  ><${K} style=${{width:"12px",height:"12px"}} /></button>

                                                <button
                                                    style=${{position:"absolute",bottom:"2px",left:"2px",width:"20px",height:"20px",borderRadius:"50%",background:"rgba(56,189,248,0.85)",border:"none",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",color:"white",padding:0,zIndex:6}}
                                                    onClick=${p=>{p.stopPropagation(),O(c,`haipix-face-${e.id}-${t+1}.png`)}}
                                                    title=${i("download")||"Tải ảnh"}
                                                ><${M} style=${{width:"11px",height:"11px"}} /></button>
                                            </div>
                                        `})}
                                </div>
                            </div>
                        `}
                    </div>
                `)}
            </div>
            
            ${x&&g`
                <div
                    style=${{position:"fixed",top:0,left:0,right:0,bottom:0,background:"rgba(0,0,0,0.92)",zIndex:9999,display:"flex",alignItems:"center",justifyContent:"center"}}
                    onClick=${()=>A(null)}
                >
                    <img
                        src=${x}
                        style=${{maxWidth:"90vw",maxHeight:"90vh",objectFit:"contain",borderRadius:"8px",boxShadow:"0 10px 50px rgba(0,0,0,0.6)"}}
                        onClick=${e=>e.stopPropagation()}
                    />
                    <button
                        style=${{position:"fixed",top:"16px",right:"16px",background:"rgba(255,255,255,0.1)",border:"1px solid rgba(255,255,255,0.3)",borderRadius:"50%",width:"40px",height:"40px",color:"#fff",fontSize:"20px",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",zIndex:1e4}}
                        onClick=${()=>A(null)}
                    >×</button>
                    <button
                        style=${{position:"fixed",bottom:"24px",left:"50%",transform:"translateX(-50%)",background:"rgba(56,189,248,0.9)",border:"none",borderRadius:"8px",padding:"10px 24px",color:"#fff",fontSize:"14px",fontWeight:600,cursor:"pointer",display:"flex",alignItems:"center",gap:"8px",zIndex:1e4}}
                        onClick=${e=>{e.stopPropagation(),O(x,"haipix-faceswap.png")}}
                    ><${M} style=${{width:"16px",height:"16px"}} /> Tải ảnh</button>
                </div>
            `}

            ${d&&g`
                <${ue}
                    targetImages=${d.map((e,o)=>({id:o,url:e.url}))}
                    models=${$}
                    onClose=${()=>a(null)}
                    onConfirm=${h}
                    t=${i}
                />
            `}
        </div>
    `},Ie=s=>{const P={faceReferenceImage:null,additionalFaceImages:[],faceGroups:[{id:"group-1",images:[]}],selectedPoses:[],customPosePrompts:[],numImages:1,aiProvider:"haipix",haipixModel:"google_image_gen_banana_3",haipixMode:"vip1",haipixRatio:"auto",haipixResolution:"5k"},[i,R]=I(P),[S,C]=I(!1),L=(d,a)=>{a==="faceReferenceImage"&&R($=>({...$,faceReferenceImage:d}))},y=V(null);F(()=>{(async()=>{if(i.faceReferenceImage&&i.faceReferenceImage!==y.current&&!S){y.current=i.faceReferenceImage,C(!0);try{const a=await ie(i.faceReferenceImage,s.language);R($=>({...$,myPrompt:a}))}catch(a){console.error("Error auto-describing:",a)}finally{C(!1)}}})()},[i.faceReferenceImage,S]);const U=async(d,a,$)=>{$&&R(w=>({...w,faceReferenceImage:$}))},j=async(d,a,$,w)=>{const b=[];let u=a.faceGroups&&a.faceGroups.length>0?a.faceGroups.filter(f=>f.images.length>0):[];u.length===0&&(u=[{id:"default",images:[]}]);for(const f of u){const G=[],x=[],A=a.myPrompt&&a.myPrompt.trim()||a.selectedPoses.length>0||a.customPosePrompts.filter(h=>h.trim()!=="").length>0;if(a.myPrompt&&a.myPrompt.trim()){const h=Array.from({length:a.numImages},()=>k(d,a.myPrompt,a,a.faceReferenceImage,f.images,w));x.push(...h)}for(const h of a.selectedPoses)if(h){const v=Array.from({length:a.numImages},()=>k(d,h,a,a.faceReferenceImage,f.images,w));x.push(...v)}for(const h of a.customPosePrompts.filter(v=>v.trim()!=="")){const v=Array.from({length:a.numImages},()=>k(d,h,a,a.faceReferenceImage,f.images,w));x.push(...v)}if(!A){const h=Array.from({length:a.numImages},()=>k(d,"",a,a.faceReferenceImage,f.images,w));x.push(...h)}if(x.length>0){const h=await Promise.all(x);G.push(...h),b.push(...h),f.id!=="default"&&R(v=>({...v,faceGroups:(v.faceGroups||[]).map(z=>z.id===f.id?{...z,results:[...z.results||[],...G]}:z)}))}}return b},W=async d=>{const a=Array.from(d).filter(b=>b.type.startsWith("image/"));if(a.length===0)return null;const $=a.map(b=>new Promise(u=>{const f=new FileReader;f.onload=G=>{var x;return u((x=G.target)==null?void 0:x.result)},f.readAsDataURL(b)})),w=await Promise.all($);return w.length>0&&R(b=>{const u={id:Date.now().toString()+"-"+Math.random().toString(36).substr(2,6),images:w,results:[]};return{...b,faceGroups:[...b.faceGroups||[],u]}}),null},B=d=>{R(a=>({...a,faceReferenceImage:d}))};return F(()=>{s.initialImage&&B(s.initialImage)},[]),g`<${he}
        ...${s}
        settings=${i}
        onSettingsChange=${R}
        SettingsPanel=${oe}
        initialSettings=${P}
        onGenerate=${j}
        onImageUpdate=${B}
        loaderTextKey="loader_posing"
        actionButtonTextKey="button_generate_photo_enter"
        downloadFilename="posed-image.png"
        allowBatchUpload=${!0}
        processBatchUpload=${W}
        GalleryComponent=${ye}
        allowNoImage=${!0}
        preventAutoSetOriginalImage=${!1}
        isDescribing=${S}
        onAutoDescribe=${U}
        onRefCropConfirm=${L}
    />`};export{Ie as default};
