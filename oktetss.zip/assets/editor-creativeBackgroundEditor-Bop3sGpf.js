import{_ as o}from"./vendor-bdgQI7wY.js";import{a7 as r,h as l}from"./editor-MotionEditor-B8LJN4fm.js";import{b as g}from"./editor-aiEditor-Dm1L4C_K.js";import{S as m}from"./editor-common-ColFbeBm.js";const s=l.bind(o),v=a=>s`<${m}
        ...${a}
        SettingsPanel=${g}
        initialSettings=${{prompt:"",referenceImage:null,numImages:1,shotType:"full",aiProvider:"haipix",haipixModel:"google_image_gen_banana_3",haipixMode:"vip1",haipixRatio:"auto",haipixResolution:"5k"}}
        onGenerate=${async(t,e,u,i)=>{const n=Array.from({length:e.numImages},()=>r(t,e,i));return await Promise.all(n)}}
        loaderTextKey="loader_creative_background"
        actionButtonTextKey="button_creative_background"
        downloadFilename="creative-background.png"
        allowNoImage=${!0}
    />`;export{v as default};
