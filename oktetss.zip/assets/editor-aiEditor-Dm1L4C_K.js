import{d as K,y as le,_ as Ce,A as de,T as he,q as Se}from"./vendor-bdgQI7wY.js";import{I as nn,M as tn,B as on,C as an,H as ln,R as rn,P as cn,V as sn,a as pn,h as Ke,A as oe,b as s,U as se,N as pe,c as Me,d as re,e as me,f as $e,S as gn,g as Ie,i as dn,j as un,k as hn,l as Le,m as Te,n as ze,D as mn,L as bn,o as _n,p as $n,q as yn,r as fn,s as vn,t as kn,u as xn,v as wn}from"./editor-MotionEditor-B8LJN4fm.js";import{C as Be,U as Tn,u as Cn,g as Kn}from"./editor-common-ColFbeBm.js";/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */const Un=[{id:"id-photo",labelKey:"tabLabel_id-photo",icon:nn,descriptionKey:"tabDescription_id-photo"},{id:"ai-editor",labelKey:"tabLabel_ai-editor",icon:tn,descriptionKey:"tabDescription_ai-editor"},{id:"batch-background",labelKey:"tabLabel_batch-background",icon:on,descriptionKey:"tabDescription_batch-background"},{id:"batch-clothing-change",labelKey:"tabLabel_batch-clothing-change",icon:an,descriptionKey:"tabDescription_batch-clothing-change"},{id:"hair-style-2",labelKey:"tabLabel_hair-style-2",icon:ln,descriptionKey:"tabDescription_hair-style-2"},{id:"restoration",labelKey:"tabLabel_restoration",icon:rn,descriptionKey:"tabDescription_restoration"},{id:"posing-studio",labelKey:"tabLabel_posing-studio",icon:cn,descriptionKey:"tabDescription_posing-studio"},{id:"video-marketing",labelKey:"tabLabel_video-marketing",icon:sn,descriptionKey:"tabDescription_video-marketing"},{id:"transaction-history",labelKey:"tabLabel_transaction-history",icon:pn,descriptionKey:"tabDescription_transaction-history"}],In=[{labelKey:"clothing_whiteShirt",prompt:"Áo sơ mi trắng trơn cài cúc, kiểu trang trọng"},{labelKey:"clothing_blueShirt",prompt:"Áo sơ mi xanh nhạt trơn cài cúc, kiểu trang trọng"},{labelKey:"clothing_blackShirt",prompt:"Áo sơ mi đen trơn cài cúc, kiểu trang trọng"},{labelKey:"clothing_polo",prompt:"Áo polo một màu, đơn giản và gọn gàng"},{labelKey:"clothing_blouse",prompt:"Áo blouse nữ chuyên nghiệp, trơn màu"},{labelKey:"clothing_bowNeck",prompt:"Áo blouse gọn gàng với cổ thắt nơ nhỏ"},{labelKey:"clothing_suit",prompt:"Bộ vest công sở với áo sơ mi trắng và cà vạt, kiểu ảnh hộ chiếu"},{labelKey:"clothing_classicBlackVest",prompt:"Bộ vest đen cổ điển với áo sơ mi trắng và cà vạt tối màu"},{labelKey:"clothing_navyVest",prompt:"Bộ vest xanh navy với áo sơ mi trắng và cà vạt"},{labelKey:"clothing_charcoalVest",prompt:"Bộ vest xám than với áo sơ mi trắng và cà vạt"},{labelKey:"clothing_vestTie",prompt:"Bộ vest trang trọng với cà vạt trơn cùng tông"},{labelKey:"clothing_lightGreyVest",prompt:"Bộ vest màu ghi sáng với áo sơ mi trắng và cà vạt"},{labelKey:"clothing_whiteAoDai",prompt:"Áo dài truyền thống Việt Nam màu trắng trơn, kiểu ảnh hộ chiếu"},{labelKey:"clothing_femaleVest",prompt:"Áo khoác vest công sở nữ mặc ngoài một chiếc áo trơn"},{labelKey:"clothing_fittedFemaleVest",prompt:"Áo khoác vest nữ được may đo vừa vặn, phong cách chuyên nghiệp"}],Pn=[{key:"original",labelKey:"hairstyle_original"},{key:"auto",labelKey:"hairstyle_auto"},{key:"shoulder_front",labelKey:"hairstyle_shoulder_front"},{key:"shoulder_back",labelKey:"hairstyle_shoulder_back"},{key:"ponytail",labelKey:"hairstyle_ponytail"},{key:"long_straight_smooth",labelKey:"hairstyle_long_straight_smooth"},{key:"slicked_back",labelKey:"hairstyle_slicked_back"},{key:"neat_male",labelKey:"hairstyle_neat_male"},{key:"tied_back",labelKey:"hairstyle_tied_back"},{key:"loose_waves",labelKey:"hairstyle_loose_waves"},{key:"straight_smooth",labelKey:"hairstyle_straight_smooth"},{key:"low_bun",labelKey:"hairstyle_low_bun"},{key:"bangs",labelKey:"hairstyle_bangs"},{key:"thicken",labelKey:"hairstyle_thicken"}],Rn={female:{"Tóc ngắn":["Tóc bob ngắn ngang cằm, uốn cúp nhẹ","Tóc pixie cá tính, mái xéo","Tóc tém uốn xoăn nhẹ nhàng","Tóc lob ngang vai, duỗi thẳng tự nhiên","Tóc bob bất đối xứng, một bên dài một bên ngắn"],"Tóc dài":["Tóc dài thẳng mượt, óng ả","Tóc dài xoăn sóng lơi tự nhiên","Tóc dài uốn lọn to bồng bềnh","Tóc đuôi ngựa buộc cao, gọn gàng","Tóc búi cao gọn gàng, thanh lịch","Tóc tết bím lệch vai duyên dáng","Tóc layer nhiều tầng hiện đại"]},male:{"Tóc ngắn":["Tóc húi cua (buzz cut) nam tính","Tóc side part cổ điển, lịch lãm","Tóc vuốt dựng (spiky) hiện đại","Tóc two-block kiểu Hàn Quốc","Tóc Undercut vuốt ngược","Tóc Mohican ngắn"],"Tóc dài":["Tóc dài ngang vai, lãng tử","Tóc Man Bun buộc cao gọn gàng","Tóc vuốt ngược (slick back) dài","Tóc dài xoăn nhẹ tự nhiên","Tóc Mullet hiện đại"]}},z="QUAN TRỌNG: Giữ nguyên tuyệt đối tỷ lệ, vị trí và bố cục của chủ thể. Không được thay đổi kích thước, không dịch chuyển, không làm méo hay biến dạng. Tư thế và dáng đứng của chủ thể phải được giữ nguyên một cách hoàn hảo. Tuyệt đối không làm biến dạng cơ thể, làm méo mặt, kéo dài hoặc nén chủ thể. Ảnh đầu ra phải có tỷ lệ khung hình chính xác như ảnh gốc.",Dn={boy:[{labelKey:"concept_fashion",prompt:`${z} Thay thế cảnh và trang phục bằng một studio concept thời trang tối giản, tông màu đen trắng. Em bé mặc áo sơ mi trắng, quần đen, có thể có nơ hoặc mũ phớt. Phông nền trắng trơn, ánh sáng studio chuyên nghiệp.`},{labelKey:"concept_little_boss",prompt:`${z} Thay thế cảnh và trang phục bằng một concept 'doanh nhân nhí' hài hước, em bé mặc áo sơ mi và cà vạt, bò trên sàn nhà văn phòng với laptop, cặp xách và giấy tờ. Tông màu xanh navy và xám.`},{labelKey:"concept_scholar",prompt:`${z} Thay thế cảnh và trang phục bằng một studio concept thư sinh cổ trang, em bé mặc áo dài cách tân, ngồi bên bàn gỗ thấp với giấy bút lông và bình phong gỗ. Tông màu trầm ấm, hoài cổ.`},{labelKey:"concept_blue_birthday",prompt:`${z} Thay thế cảnh và trang phục bằng một concept sinh nhật với phông nền màu xanh da trời. Em bé mặc trang phục dự tiệc, đội mũ sinh nhật, có bóng bay, quà và bánh kem. Ánh sáng trong trẻo, vui tươi.`},{labelKey:"concept_pilot",prompt:`${z} Thay thế cảnh và trang phục bằng một studio concept phi công nhí. Em bé mặc trang phục phi công, đội mũ và kính phi công, ngồi cạnh các mô hình máy bay. Phông nền bầu trời và mây.`},{labelKey:"concept_superhero",prompt:`${z} Thay thế cảnh và trang phục bằng một studio concept siêu anh hùng. Em bé mặc trang phục siêu nhân, có áo choàng. Phông nền là một thành phố hoạt hình, ánh sáng mạnh mẽ.`},{labelKey:"concept_explorer",prompt:`${z} Thay thế cảnh và trang phục bằng một studio concept nhà thám hiểm. Em bé mặc đồ safari, đội mũ rộng vành, cầm ống nhòm, xung quanh là cây lá nhiệt đới.`},{labelKey:"concept_footballer",prompt:`${z} Thay thế cảnh và trang phục bằng một studio concept cầu thủ bóng đá. Em bé mặc đồng phục thể thao, ngồi cạnh quả bóng trên nền cỏ xanh.`},{labelKey:"concept_teddy_bear",prompt:`${z} Thay thế cảnh và trang phục bằng một studio concept tông màu nâu ấm, em bé mặc bộ romper gấu bông dễ thương, ngồi giữa các chú gấu teddy, ánh sáng dịu nhẹ, ấm cúng.`},{labelKey:"concept_brown_birthday",prompt:`${z} Thay thế cảnh và trang phục bằng một concept sinh nhật tông màu nâu gỗ ấm cúng. Em bé mặc trang phục lịch sự màu be hoặc nâu, ngồi giữa các món đồ chơi bằng gỗ, có bánh kem và cờ treo trang trí. Ánh sáng tự nhiên, dịu nhẹ.`},{labelKey:"concept_first_birthday",prompt:`${z} Thay thế cảnh và trang phục bằng một concept studio tối giản Hàn Quốc cho sinh nhật 1 tuổi. Em bé mặc trang phục màu trắng hoặc be, ngồi trên sàn gỗ. Phông nền trắng trơn, có một quả bóng bay số '1' màu vàng gold, một chiếc bánh kem nhỏ và một vài món đồ chơi gỗ. Ánh sáng tự nhiên, trong trẻo và mềm mại.`},{labelKey:"concept_vintage",prompt:`${z} Thay thế cảnh và trang phục bằng một studio concept retro, em bé mặc quần yếm và mũ nồi cổ điển, phông nền tường vàng, có TV, quạt cũ. Tông màu phim ấm áp.`},{labelKey:"concept_korean_minimal",prompt:`${z} Thay thế cảnh và trang phục bằng một studio tối giản Hàn Quốc, em bé mặc bộ đồ cotton màu trung tính (be, trắng), phông nền trơn, ít phụ kiện. Ánh sáng dịu nhẹ.`},{labelKey:"concept_dinosaur",prompt:`${z} Thay thế cảnh và trang phục bằng một studio concept khủng long. Em bé mặc quần yếm, ngồi trong một chiếc xe đẩy gỗ. Phông nền màu cam rực rỡ, xung quanh là các chú khủng long đồ chơi màu xanh lá. Ánh sáng vui tươi.`},{labelKey:"concept_investigator",prompt:`${z} Thay thế cảnh và trang phục bằng một studio concept nhà điều tra nhí. Em bé mặc đồ kaki, đội mũ, cầm kính lúp. Phông nền là một bàn làm việc với các bản đồ cũ và các vật dụng khám phá. Ánh sáng studio, tông màu vintage.`},{labelKey:"concept_safari",prompt:`${z} Thay thế cảnh và trang phục bằng một studio concept safari tối giản. Em bé mặc trang phục màu trung tính, ngồi trên ghế sofa hình thú, xung quanh là các con thú nhồi bông như hươu cao cổ, sư tử, ngựa vằn. Phông nền trắng, ánh sáng studio.`},{labelKey:"concept_little_room",prompt:`${z} Thay thế cảnh và trang phục bằng một concept căn phòng ngủ tối giản. Em bé mặc đồ ngủ thoải mái, ngồi trên giường kẻ caro xanh trắng. Phông nền là vách ngăn shoji, có cây xanh trong giỏ mây và các món đồ chơi đơn giản. Ánh sáng tự nhiên.`}],girl:[{labelKey:"concept_sweet_candy",prompt:`${z} Thay thế cảnh và trang phục bằng một studio concept kẹo ngọt vui nhộn. Em bé mặc trang phục sặc sỡ, ngồi giữa các loại kẹo mút, bim bim, bánh kẹo. Phông nền màu đỏ rực rỡ, ánh sáng tươi vui.`},{labelKey:"concept_fairy_tale",prompt:`${z} Thay thế cảnh và trang phục bằng một studio concept khu vườn cổ tích mơ màng. Em bé mặc trang phục màu trắng hoặc pastel, xung quanh có hoa, bươm bướm và vải voan mềm mại. Tông màu ảnh trong trẻo, dịu dàng.`},{labelKey:"concept_white_rabbit",prompt:`${z} Thay thế cảnh và trang phục bằng một concept thỏ trắng đáng yêu, em bé mặc bộ đồ thỏ bông trắng muốt, ngồi trên sofa hoặc nền mềm mại, xung quanh có bóng bay màu pastel và thỏ nhồi bông. Ánh sáng trong trẻo, nhẹ nhàng.`},{labelKey:"concept_tea_party",prompt:`${z} Thay thế cảnh và trang phục bằng một concept tiệc trà vui nhộn, em bé mặc đồ dễ thương, ngồi trên thảm sặc sỡ bên cạnh một bộ ấm trà và bánh macaron. Phông nền màu xanh dương, có các nhân vật hoạt hình đáng yêu. Không khí tinh nghịch.`},{labelKey:"concept_princess",prompt:`${z} Thay thế cảnh và trang phục bằng một studio concept công chúa. Em bé mặc một chiếc váy bồng bềnh, có thể đội vương miện nhỏ. Phông nền là một lâu đài cổ tích hoặc khu vườn hoa.`},{labelKey:"concept_little_chef",prompt:`${z} Thay thế cảnh và trang phục bằng một studio concept đầu bếp. Em bé mặc tạp dề, đội mũ đầu bếp, xung quanh có các dụng cụ làm bếp bằng gỗ và bột mì.`},{labelKey:"concept_little_artist",prompt:`${z} Thay thế cảnh và trang phục bằng một studio concept họa sĩ. Em bé đội mũ nồi, mặc yếm, ngồi trước giá vẽ với các vệt màu sặc sỡ.`},{labelKey:"concept_angel",prompt:`${z} Thay thế cảnh và trang phục bằng một studio concept thiên thần. Em bé mặc váy trắng, có đôi cánh nhỏ, ngồi trên những đám mây bông. Ánh sáng mềm mại, huyền ảo.`},{labelKey:"concept_teddy_bear",prompt:`${z} Thay thế cảnh và trang phục bằng một studio concept tông màu nâu ấm, em bé mặc bộ romper gấu bông dễ thương, ngồi giữa các chú gấu teddy, ánh sáng dịu nhẹ, ấm cúng.`},{labelKey:"concept_birthday_party",prompt:`${z} Thay thế cảnh và trang phục bằng một concept sinh nhật với phông nền pastel, em bé mặc trang phục dự tiệc dễ thương, có bóng bay, bánh kem và chữ Happy Birthday. Ánh sáng trong trẻo, vui tươi.`},{labelKey:"concept_first_birthday",prompt:`${z} Thay thế cảnh và trang phục bằng một concept studio tối giản Hàn Quốc cho sinh nhật 1 tuổi. Em bé mặc trang phục màu trắng hoặc be, ngồi trên sàn gỗ. Phông nền trắng trơn, có một quả bóng bay số '1' màu vàng gold, một chiếc bánh kem nhỏ và một vài món đồ chơi gỗ. Ánh sáng tự nhiên, trong trẻo và mềm mại.`},{labelKey:"concept_nature",prompt:`${z} Thay thế cảnh và trang phục bằng một concept 'khu vườn' trong studio, em bé mặc đồ màu xanh lá hoặc màu be, ngồi giữa hoa lá và rau củ. Ánh sáng tự nhiên.`},{labelKey:"concept_korean_minimal",prompt:`${z} Thay thế cảnh và trang phục bằng một studio tối giản Hàn Quốc, em bé mặc bộ đồ cotton màu trung tính (be, trắng), phông nền trơn, ít phụ kiện. Ánh sáng dịu nhẹ.`},{labelKey:"concept_vegetable_garden",prompt:`${z} Thay thế cảnh và trang phục bằng một studio concept vườn rau củ quả. Em bé mặc trang phục hình quả cà chua, ngồi trong giỏ mây, xung quanh là rất nhiều loại trái cây và rau củ tươi ngon như dưa hấu, dứa, chuối. Phông nền màu xanh lá nhạt.`},{labelKey:"concept_hedgehog",prompt:`${z} Thay thế cảnh và trang phục bằng một studio concept hoạt hình vui nhộn. Em bé mặc bộ đồ hình con nhím dễ thương, đội mũ nhím. Phông nền màu pastel với các cây và quả táo hoạt hình. Ánh sáng tươi sáng, vui vẻ.`},{labelKey:"concept_safari",prompt:`${z} Thay thế cảnh và trang phục bằng một studio concept safari tối giản. Em bé mặc trang phục màu trung tính, ngồi trên ghế sofa hình thú, xung quanh là các con thú nhồi bông như hươu cao cổ, sư tử, ngựa vằn. Phông nền trắng, ánh sáng studio.`},{labelKey:"concept_little_room",prompt:`${z} Thay thế cảnh và trang phục bằng một concept căn phòng ngủ tối giản. Em bé mặc đồ ngủ thoải mái, ngồi trên giường kẻ caro xanh trắng. Phông nền là vách ngăn shoji, có cây xanh trong giỏ mây và các món đồ chơi đơn giản. Ánh sáng tự nhiên.`}]},Sn=[{labelKey:"bg_cat_baby",key:"bg_cat_baby",subCategories:[{labelKey:"bg_subcat_teddy",items:[{promptKey:"bg_prompt_baby_teddy_1"},{promptKey:"bg_prompt_baby_teddy_2"},{promptKey:"bg_prompt_baby_teddy_3"},{promptKey:"bg_prompt_baby_teddy_4"},{promptKey:"bg_prompt_baby_teddy_5"}]},{labelKey:"bg_subcat_birthday",items:[{promptKey:"bg_prompt_baby_birthday_1"},{promptKey:"bg_prompt_baby_birthday_2"},{promptKey:"bg_prompt_baby_birthday_3"},{promptKey:"bg_prompt_baby_birthday_4"},{promptKey:"bg_prompt_baby_birthday_5"}]},{labelKey:"bg_subcat_nature",items:[{promptKey:"bg_prompt_baby_nature_1"},{promptKey:"bg_prompt_baby_nature_2"},{promptKey:"bg_prompt_baby_nature_3"},{promptKey:"bg_prompt_baby_nature_4"}]},{labelKey:"bg_subcat_vintage",items:[{promptKey:"bg_prompt_baby_vintage_1"},{promptKey:"bg_prompt_baby_vintage_2"},{promptKey:"bg_prompt_baby_vintage_3"},{promptKey:"bg_prompt_baby_vintage_4"}]},{labelKey:"bg_subcat_fun",items:[{promptKey:"bg_prompt_baby_fun_1"},{promptKey:"bg_prompt_baby_fun_2"},{promptKey:"bg_prompt_baby_fun_3"},{promptKey:"bg_prompt_baby_fun_4"}]},{labelKey:"bg_subcat_minimalist",items:[{promptKey:"bg_prompt_baby_minimalist_1"},{promptKey:"bg_prompt_baby_minimalist_2"},{promptKey:"bg_prompt_baby_minimalist_3"}]}]},{labelKey:"bg_cat_wedding",key:"bg_cat_wedding",subCategories:[{labelKey:"bg_subcat_wedding_indoor",items:[{promptKey:"bg_prompt_wedding_indoor_1"},{promptKey:"bg_prompt_wedding_indoor_2"},{promptKey:"bg_prompt_wedding_indoor_3"},{promptKey:"bg_prompt_wedding_indoor_4"},{promptKey:"bg_prompt_wedding_indoor_5"},{promptKey:"bg_prompt_wedding_indoor_6"},{promptKey:"bg_prompt_wedding_indoor_7"},{promptKey:"bg_prompt_wedding_indoor_8"},{promptKey:"bg_prompt_wedding_indoor_9"},{promptKey:"bg_prompt_wedding_indoor_10"},{promptKey:"bg_prompt_wedding_indoor_11"},{promptKey:"bg_prompt_wedding_indoor_12"},{promptKey:"bg_prompt_wedding_indoor_13"},{promptKey:"bg_prompt_wedding_indoor_14"},{promptKey:"bg_prompt_wedding_indoor_15"},{promptKey:"bg_prompt_wedding_indoor_16"},{promptKey:"bg_prompt_wedding_indoor_17"},{promptKey:"bg_prompt_wedding_indoor_18"},{promptKey:"bg_prompt_wedding_indoor_19"},{promptKey:"bg_prompt_wedding_indoor_20"},{promptKey:"bg_prompt_wedding_indoor_21"},{promptKey:"bg_prompt_wedding_indoor_22"}]},{labelKey:"bg_subcat_wedding_outdoor",items:[{promptKey:"bg_prompt_wedding_outdoor_1"},{promptKey:"bg_prompt_wedding_outdoor_2"},{promptKey:"bg_prompt_wedding_outdoor_3"},{promptKey:"bg_prompt_wedding_outdoor_4"},{promptKey:"bg_prompt_wedding_outdoor_5"},{promptKey:"bg_prompt_wedding_outdoor_6"},{promptKey:"bg_prompt_wedding_outdoor_7"},{promptKey:"bg_prompt_wedding_outdoor_8"},{promptKey:"bg_prompt_wedding_outdoor_9"},{promptKey:"bg_prompt_wedding_outdoor_10"},{promptKey:"bg_prompt_wedding_outdoor_11"}]},{labelKey:"bg_subcat_wedding_beach",items:[{promptKey:"bg_prompt_wedding_beach_1"},{promptKey:"bg_prompt_wedding_beach_2"},{promptKey:"bg_prompt_wedding_beach_3"},{promptKey:"bg_prompt_wedding_beach_4"}]},{labelKey:"bg_subcat_wedding_urban",items:[{promptKey:"bg_prompt_wedding_urban_1"},{promptKey:"bg_prompt_wedding_urban_2"},{promptKey:"bg_prompt_wedding_urban_3"},{promptKey:"bg_prompt_wedding_urban_4"},{promptKey:"bg_prompt_wedding_urban_5"},{promptKey:"bg_prompt_wedding_urban_6"},{promptKey:"bg_prompt_wedding_urban_7"},{promptKey:"bg_prompt_wedding_urban_8"},{promptKey:"bg_prompt_wedding_urban_9"},{promptKey:"bg_prompt_wedding_urban_10"}]}]},{labelKey:"bg_cat_fashion",key:"bg_cat_fashion",subCategories:[{labelKey:"bg_subcat_fashion_indoor",items:[{promptKey:"bg_prompt_fashion_indoor_1"},{promptKey:"bg_prompt_fashion_indoor_2"},{promptKey:"bg_prompt_fashion_indoor_3"},{promptKey:"bg_prompt_fashion_indoor_4"}]},{labelKey:"bg_subcat_fashion_lighting",items:[{promptKey:"bg_prompt_fashion_lighting_1"},{promptKey:"bg_prompt_fashion_lighting_2"},{promptKey:"bg_prompt_fashion_lighting_3"},{promptKey:"bg_prompt_fashion_lighting_4"}]},{labelKey:"bg_subcat_fashion_outdoor",items:[{promptKey:"bg_prompt_fashion_outdoor_1"},{promptKey:"bg_prompt_fashion_outdoor_2"},{promptKey:"bg_prompt_fashion_outdoor_3"},{promptKey:"bg_prompt_fashion_outdoor_4"},{promptKey:"bg_prompt_fashion_outdoor_5"},{promptKey:"bg_prompt_fashion_outdoor_6"}]}]}],_e={lighting_group_hair:[{key:"hair_edge_light",labelKey:"lighting_effect_hair_edge_light"},{key:"hair_rim_left",labelKey:"lighting_effect_hair_rim_left"},{key:"hair_rim_right",labelKey:"lighting_effect_hair_rim_right"},{key:"backlight_left",labelKey:"lighting_effect_backlight_left"},{key:"backlight_right",labelKey:"lighting_effect_backlight_right"},{key:"nape_light",labelKey:"lighting_effect_nape_light"},{key:"back_top_light",labelKey:"lighting_effect_back_top_light"},{key:"shoulder_left",labelKey:"lighting_effect_shoulder_left"},{key:"shoulder_right",labelKey:"lighting_effect_shoulder_right"},{key:"collarline_light",labelKey:"lighting_effect_collarline_light"}],lighting_group_back:[{key:"spine_light",labelKey:"lighting_effect_spine_light"},{key:"waist_rim",labelKey:"lighting_effect_waist_rim"},{key:"hip_rim_left",labelKey:"lighting_effect_hip_rim_left"},{key:"hip_rim_right",labelKey:"lighting_effect_hip_rim_right"}],lighting_group_hands:[{key:"hand_flower_light",labelKey:"lighting_effect_hand_flower_light"},{key:"ring_light",labelKey:"lighting_effect_ring_light"},{key:"wrist_light",labelKey:"lighting_effect_wrist_light"},{key:"lapel_light",labelKey:"lighting_effect_lapel_light"},{key:"tie_light",labelKey:"lighting_effect_tie_light"}],lighting_group_dress:[{key:"dress_streak_diagonal",labelKey:"lighting_effect_dress_streak_diagonal"},{key:"dress_lace_light",labelKey:"lighting_effect_dress_lace_light"},{key:"dress_fold_light",labelKey:"lighting_effect_dress_fold_light"},{key:"dress_hem_light",labelKey:"lighting_effect_dress_hem_light"},{key:"dress_trail_light",labelKey:"lighting_effect_dress_trail_light"},{key:"veil_back_light",labelKey:"lighting_effect_veil_back_light"},{key:"veil_through_light",labelKey:"lighting_effect_veil_through_light"}],lighting_group_env:[{key:"floor_streak_front",labelKey:"lighting_effect_floor_streak_front"},{key:"floor_streak_back",labelKey:"lighting_effect_floor_streak_back"},{key:"window_streak_bg",labelKey:"lighting_effect_window_streak_bg"},{key:"streak_horizontal",labelKey:"lighting_effect_streak_horizontal"},{key:"streak_vertical",labelKey:"lighting_effect_streak_vertical"},{key:"blinds_effect_bg",labelKey:"lighting_effect_blinds_effect_bg"},{key:"spotlight_on_subject",labelKey:"lighting_effect_spotlight_on_subject"},{key:"foliage_gobo",labelKey:"lighting_effect_foliage_gobo"},{key:"bokeh_lights_back",labelKey:"lighting_effect_bokeh_lights_back"},{key:"soft_halo_back",labelKey:"lighting_effect_soft_halo_back"},{key:"full_body_silhouette",labelKey:"lighting_effect_full_body_silhouette"},{key:"kicker_left",labelKey:"lighting_effect_kicker_left"},{key:"kicker_right",labelKey:"lighting_effect_kicker_right"},{key:"streak_diagonal_bg",labelKey:"lighting_effect_streak_diagonal_bg"},{key:"streak_diagonal_down_bg",labelKey:"lighting_effect_streak_diagonal_down_bg"},{key:"circle_light_bg",labelKey:"lighting_effect_circle_light_bg"}]},Ln="modulepreload",zn=function(e){return"/"+e},Ee={},Bn=function(t,L,f){let E=Promise.resolve();if(L&&L.length>0){document.getElementsByTagName("link");const T=document.querySelector("meta[property=csp-nonce]"),n=(T==null?void 0:T.nonce)||(T==null?void 0:T.getAttribute("nonce"));E=Promise.allSettled(L.map(a=>{if(a=zn(a),a in Ee)return;Ee[a]=!0;const g=a.endsWith(".css"),p=g?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${a}"]${p}`))return;const I=document.createElement("link");if(I.rel=g?"stylesheet":Ln,g||(I.as="script"),I.crossOrigin="",I.href=a,n&&I.setAttribute("nonce",n),document.head.appendChild(I),g)return new Promise((P,O)=>{I.addEventListener("load",P),I.addEventListener("error",()=>O(new Error(`Unable to preload CSS for ${a}`)))})}))}function R(T){const n=new Event("vite:preloadError",{cancelable:!0});if(n.payload=T,window.dispatchEvent(n),!n.defaultPrevented)throw T}return E.then(T=>{for(const n of T||[])n.status==="rejected"&&R(n.reason);return t().catch(R)})},Oe=Ke.bind(Ce),En=({startTime:e,phase:t,t:L})=>{const[f,E]=K(0);le(()=>{const n=e||Date.now(),a=setInterval(()=>{const g=Date.now(),p=Math.floor((g-n)/1e3);E(p)},1e3);return()=>clearInterval(a)},[e]);const R=[{key:"uploading",label:L("processing_step_uploading")},{key:"request_success",label:L("processing_step_request_success")},{key:"pending",label:L("processing_step_pending")},{key:"processing",label:L("processing_step_processing")}],T=(()=>{if(!t)return 0;const n=R.findIndex(a=>a.key===t);return n===-1?t==="done"?4:0:n})();return Oe`
        <div class="batch-item-status-overlay">
            <div class="spinner"></div>
            <div class="processing-timeline">
                ${R.map((n,a)=>{const g=a<T||t==="done";return Oe`
                        <div class="timeline-step ${g?"completed":""} ${a===T&&t!=="done"?"active":""}">
                            <div class="step-dot"></div>
                            <span class="step-label">${n.label}</span>
                        </div>
                    `})}
            </div>
            <div style=${{display:"flex",flexDirection:"column",alignItems:"center",gap:"4px",textAlign:"center",marginTop:"8px"}}>
                <span class="processing-timer" style=${{fontSize:"1.2em",fontWeight:"bold",color:"#00d1b2"}}>${f}s</span>
                <span class="processing-mode-hint" style=${{fontSize:"0.8em",fontWeight:"500",opacity:.8,whiteSpace:"pre-wrap",lineHeight:"1.2"}}>
                    ${L("processing_mode_hint")}
                </span>
            </div>
        </div>
    `};/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */const h=Ke.bind(Ce),Pe=e=>{e.preventDefault(),e.stopPropagation()},Nn=({settings:e,setSettings:t,onGenerate:L,generating:f,hasImage:E,buttonText:R,onBackToHome:T,onChooseAnotherImage:n,isBatch:a=!1,t:g})=>{const[p,I]=K(!1),P=(d,_)=>{d.preventDefault(),d.stopPropagation(),I(_)},O=d=>{const _=new FileReader;_.onload=$=>{var D;const v=(D=$.target)==null?void 0:D.result;t(u=>({...u,customClothingImage:v,clothingPrompts:[]}))},_.readAsDataURL(d)},H=d=>{var $,v;P(d,!1);const _=(v=($=d.dataTransfer)==null?void 0:$.files)==null?void 0:v[0];_&&_.type.startsWith("image/")&&O(_)},V=d=>{t(_=>{const $=_.clothingPrompts||[],v=$.includes(d)?$.filter(D=>D!==d):[d];return{..._,clothingPrompts:v,customClothingImage:null}})},G=()=>{t(d=>({...d,clothingPrompts:[],customClothingImage:null}))};return h`
        <div class="settings-panel">
            <button onClick=${T} class="back-button">${g("backButton")}</button>
            ${!a&&n&&h`<button class="btn btn-secondary" onClick=${n} style=${{width:"100%",marginBottom:"1rem"}}>${g("selectAnotherImage")}</button>`}


            <div style=${{flex:"1",overflowY:"auto",paddingRight:"0.5rem"}}>
                <${oe} settings=${e} setSettings=${t} t=${g} allowedModels=${["google_image_gen_banana_3","google_image_gen_banana_2","google_image_gen_banana_2_cheap","google_image_gen_banana_pro","google_image_gen_banana_pro_cheap","3.0-omni","google_image_gen_banana","o1","google_image_gen_banana_pro_reason","seedream_4_5"]} />
                <${s} title=${g("backgroundColor")}>
                    <div class="radio-group">
                        <label>
                            <input type="radio" name="bg" value="white" checked=${e.background==="white"} onChange=${()=>t(d=>({...d,background:"white"}))} />
                            ${g("white")}
                        </label>
                        <label>
                            <input type="radio" name="bg" value="blue" checked=${e.background==="blue"} onChange=${()=>t(d=>({...d,background:"blue"}))} />
                            ${g("blue")}
                        </label>
                        <label>
                            <input type="radio" name="bg" value="gray" checked=${e.background==="gray"} onChange=${()=>t(d=>({...d,background:"gray"}))} />
                            ${g("gray")}
                        </label>
                    </div>
                </${s}>

                <${s} title=${g("clothing")}>
                    <div class="clothing-grid">
                        ${In.map(d=>h`
                            <button 
                                class="clothing-btn ${e.clothingPrompts.includes(d.prompt)?"active":""}"
                                onClick=${()=>V(d.prompt)}
                            >${g(d.labelKey)}</button>
                        `)}
                         <button 
                            class="clothing-btn ${e.clothingPrompts.length===0&&!e.customClothingImage?"active":""}"
                            onClick=${G}
                        >${g("keepOriginal")}</button>
                    </div>
                    <div class="form-group" style=${{marginTop:"1rem"}}>
                        <label class="uploader-label">${g("orUploadTemplate")}</label>
                        <div 
                            class="reference-uploader ${p?"drag-over":""}"
                            style=${{cursor:"default",width:"100%",height:"120px"}}
                            onDragOver=${d=>P(d,!0)}
                            onDragEnter=${d=>P(d,!0)}
                            onDragLeave=${d=>P(d,!1)}
                            onDrop=${H}
                            onPaste=${Pe}
                        >
                            ${e.customClothingImage?h`
                                <img src=${e.customClothingImage} alt="Custom Clothing Reference" class="reference-preview"/>
                                <button class="remove-reference-btn" onClick=${d=>{d.stopPropagation(),t(_=>({..._,customClothingImage:null}))}} title=${g("removeTemplate")}><${re}/></button>
                            `:h`
                                <div class="reference-placeholder" style=${{gap:"0.25rem"}}>
                                   <${se} />
                                   <span style=${{fontWeight:500}}>${g("uploader_drag_drop_prompt")}</span>
                                   <span style=${{fontSize:"0.8em",opacity:.7}}>${g("uploader_drag_drop_note")}</span>
                                </div>
                            `}
                        </div>
                    </div>
                </${s}>

                <${s} title=${g("hairStyle")}>
                    <select class="form-group" value=${e.hairStyle} onChange=${d=>t(_=>({..._,hairStyle:d.currentTarget.value}))}>
                        ${Pn.map(d=>h`
                            <option value=${d.key}>${g(d.labelKey)}</option>
                        `)}
                    </select>
                </${s}>

                <${s} title=${g("detailedEdits")} initialOpen=${!0}>
                    <div class="checkbox-group">
                        <label>
                            <input type="checkbox" checked=${e.preserveHairStyle} onChange=${d=>t(_=>({..._,preserveHairStyle:d.currentTarget.checked}))}/>
                            ${g("preserveHair")}
                        </label>
                        <label>
                            <input type="checkbox" checked=${e.preserveFaceShape} onChange=${d=>t(_=>({..._,preserveFaceShape:d.currentTarget.checked}))}/>
                            ${g("preserveFaceShape")}
                        </label>
                        <label><input type="checkbox" checked=${e.preserveFaceDetails} onChange=${d=>t(_=>({..._,preserveFaceDetails:d.currentTarget.checked}))}/> ${g("preserveFaceDetails")}</label>
                        <label><input type="checkbox" checked=${e.smoothSkin} onChange=${d=>t(_=>({..._,smoothSkin:d.currentTarget.checked}))}/> ${g("smoothSkin")}</label>
                        <label><input type="checkbox" checked=${e.slightSmile} onChange=${d=>t(_=>({..._,slightSmile:d.currentTarget.checked}))}/> ${g("slightSmile")}</label>
                    </div>
                </${s}>

                <${s} title=${g("otherRequests")} initialOpen=${!1}>
                    <div class="textarea-container">
                        <textarea 
                            id="custom-prompt" 
                            placeholder=${g("placeholder_glasses")}
                            value=${e.customPrompt}
                            onInput=${d=>t(_=>({..._,customPrompt:d.currentTarget.value}))}
                        ></textarea>
                        ${e.customPrompt&&h`
                            <button class="clear-textarea-btn" onClick=${()=>{t(d=>({...d,customPrompt:""}))}} title=${g("clear")}>
                                <${re} />
                            </button>
                        `}
                    </div>
                </${s}>

                <${s} title=${g("preservationPrompt")} initialOpen=${!1}>
                    <div class="checkbox-group" style=${{marginBottom:"0.5rem"}}>
                        <label>
                            <input 
                                type="checkbox" 
                                checked=${e.usePreservationPrompt} 
                                onChange=${d=>t(_=>({..._,usePreservationPrompt:d.currentTarget.checked}))}
                            />
                            <strong>${g("usePrompt")}</strong>
                        </label>
                    </div>
                    <textarea 
                        id="preservation-prompt" 
                        value=${e.preservationPrompt}
                        onInput=${d=>t(_=>({..._,preservationPrompt:d.currentTarget.value}))}
                        disabled=${!e.usePreservationPrompt}
                        rows="6"
                        style=${{opacity:e.usePreservationPrompt?1:.6,backgroundColor:e.usePreservationPrompt?"var(--surface-2)":"var(--surface-1)"}}
                    ></textarea>
                </${s}>
                
                ${!a&&h`
                    <${s} title=${g("section_num_images_id")}>
                        <${pe}
                            value=${e.numImages}
                            options=${[1,2,3,4]}
                            onChange=${d=>{t(_=>({..._,numImages:d}))}}
                        />
                    </${s}>
                `}
            </div>
            
            <${me} t=${g} />
            <button class="btn btn-primary" onClick=${L} disabled=${f||!E} style=${{width:"100%"}}>
                ${f?g("processing_photo"):R||g("button_generate_photo")}
            </button>
        </div>
    `},Wn=({settings:e,setSettings:t,onGenerate:L,generating:f,hasImage:E,buttonText:R,onBackToHome:T,onChooseAnotherImage:n,isBatch:a=!1,currentImage:g,t:p,language:I})=>{const[P,O]=K(!1),[H,V]=K(!1),G=async()=>{if(g){O(!0);try{const u=await Ie(g,"general",I);t(k=>({...k,advancedPrompt:u}))}catch(u){console.error("Failed to describe image",u),alert(p("error_describe_failed"))}finally{O(!1)}}},d=async()=>{if(g){V(!0);try{const u=await un(g);t(k=>({...k,...u}))}catch(u){console.error("Failed to analyze image",u),alert(p("error_analyze_failed"))}finally{V(!1)}}},_=[{value:"unknown",labelKey:"option_unknown"},{value:"male",labelKey:"option_male"},{value:"female",labelKey:"option_female"}],$=[{value:"unknown",labelKey:"age_range_unknown"},{value:"0-5",labelKey:"age_range_0_5"},{value:"6-12",labelKey:"age_range_6_12"},{value:"13-19",labelKey:"age_range_13_19"},{value:"20-30",labelKey:"age_range_20_30"},{value:"31-40",labelKey:"age_range_31_40"},{value:"41-50",labelKey:"age_range_41_50"},{value:"51+",labelKey:"age_range_over_50"}],v=[{value:"unknown",labelKey:"option_unknown"},{value:"not_smiling",labelKey:"option_not_smiling"},{value:"slight_smile",labelKey:"option_slight_smile"},{value:"big_smile",labelKey:"option_big_smile"}],D=f||P||H;return h`
        <div class="settings-panel">
            <button onClick=${T} class="back-button">${p("backButton")}</button>
             ${!a&&n&&h`<button class="btn btn-secondary" onClick=${n} style=${{width:"100%",marginBottom:"1rem"}}>${p("selectAnotherImage")}</button>`}

            <div style=${{flex:"1",overflowY:"auto",paddingRight:"0.5rem"}}>
                <${oe} settings=${e} setSettings=${t} t=${p} allowedModels=${["google_image_gen_banana_3","google_image_gen_banana_2","google_image_gen_banana_2_cheap","google_image_gen_banana_pro","google_image_gen_banana_pro_cheap","3.0-omni","google_image_gen_banana","o1","google_image_gen_banana_pro_reason","seedream_4_5"]} />
                <!-- Gemini Analysis disabled temporarily -->
                <!-- <div class="form-group" style=${{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"0.5rem"}}>
                    <button class="btn btn-secondary" onClick=${d} disabled=${D||!E}>
                        ${p(H?"button_analyzing":"button_auto_analyze")}
                    </button>
                    <button class="btn btn-secondary" onClick=${G} disabled=${D||!E}>
                        ${p(P?"button_creating":"button_create_description")}
                    </button>
                </div> -->

                <${s} title=${p("section_restore_options")}>
                    <div class="checkbox-group" style=${{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"0.75rem"}}>
                        <label>
                            <input type="checkbox" checked=${e.colorize} onChange=${u=>t(k=>({...k,colorize:u.currentTarget.checked}))}/>
                            ${p("checkbox_colorize")}
                        </label>
                        <label>
                            <input type="checkbox" checked=${e.sharpenBackground} onChange=${u=>t(k=>({...k,sharpenBackground:u.currentTarget.checked}))}/>
                            ${p("checkbox_sharpen_bg")}
                        </label>
                        <label>
                            <input type="checkbox" checked=${e.highQuality} onChange=${u=>t(k=>({...k,highQuality:u.currentTarget.checked}))}/>
                            ${p("checkbox_high_quality")}
                        </label>
                        <label>
                            <input type="checkbox" checked=${e.isVietnamese} onChange=${u=>t(k=>({...k,isVietnamese:u.currentTarget.checked}))}/>
                            ${p("checkbox_is_vietnamese")}
                        </label>
                    </div>
                </${s}>

                <${s} title=${p("backgroundColor")}>
                    <div class="radio-group">
                        <label>
                            <input type="radio" name="restore-bg" value="auto" checked=${e.background==="auto"} onChange=${()=>t(u=>({...u,background:"auto"}))} />
                            ${p("auto")}
                        </label>
                        <label>
                            <input type="radio" name="restore-bg" value="white" checked=${e.background==="white"} onChange=${()=>t(u=>({...u,background:"white"}))} />
                            ${p("white")}
                        </label>
                        <label>
                            <input type="radio" name="restore-bg" value="blue" checked=${e.background==="blue"} onChange=${()=>t(u=>({...u,background:"blue"}))} />
                            ${p("blue")}
                        </label>
                        <label>
                            <input type="radio" name="restore-bg" value="gray" checked=${e.background==="gray"} onChange=${()=>t(u=>({...u,background:"gray"}))} />
                            ${p("gray")}
                        </label>
                    </div>
                </${s}>

                <div class="form-group" style=${{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"1rem"}}>
                    <div>
                        <label for="number-of-people">${p("label_num_people")}</label>
                        <input type="text" class="number-input" id="number-of-people" value=${e.numberOfPeople} onInput=${u=>t(k=>({...k,numberOfPeople:u.currentTarget.value}))} />
                    </div>
                     <div>
                        <label for="gender">${p("label_gender")}</label>
                        <select id="gender" class="form-group" value=${e.gender} onChange=${u=>t(k=>({...k,gender:u.currentTarget.value}))}>
                            ${_.map(u=>h`<option value=${u.value}>${p(u.labelKey)}</option>`)}
                        </select>
                    </div>
                </div>
                 <div class="form-group" style=${{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"1rem"}}>
                    <div>
                        <label for="age-range">${p("label_age")}</label>
                        <select id="age-range" class="form-group" value=${e.ageRange} onChange=${u=>t(k=>({...k,ageRange:u.currentTarget.value}))}>
                            ${$.map(u=>h`<option value=${u.value}>${p(u.labelKey)}</option>`)}
                        </select>
                    </div>
                     <div>
                        <label for="smile">${p("label_smile")}</label>
                        <select id="smile" class="form-group" value=${e.smile} onChange=${u=>t(k=>({...k,smile:u.currentTarget.value}))}>
                            ${v.map(u=>h`<option value=${u.value}>${p(u.labelKey)}</option>`)}
                        </select>
                    </div>
                </div>
                
                <${s} title=${p("section_clothing_desc")}>
                    <p class="form-note" style=${{marginBottom:"1rem"}}>
                        ${p("note_clothing_override")}
                    </p>
                    <div class="textarea-container">
                        <textarea 
                            id="clothing-prompt-restore" 
                            placeholder=${p("placeholder_clothing_prompt")}
                            value=${e.clothingPrompt}
                            onInput=${u=>t(k=>({...k,clothingPrompt:u.currentTarget.value}))}
                            rows="3"
                        ></textarea>
                        ${e.clothingPrompt&&h`
                            <button class="clear-textarea-btn" onClick=${()=>{t(u=>({...u,clothingPrompt:""}))}} title=${p("clear")}>
                                <${re} />
                            </button>
                        `}
                    </div>
                </${s}>

                <${s} title=${p("section_advanced_requests")}>
                    <div class="textarea-container">
                        <textarea 
                            id="advanced-prompt-restore" 
                            placeholder=${p("placeholder_advanced_prompt")}
                            value=${e.advancedPrompt}
                            onInput=${u=>t(k=>({...k,advancedPrompt:u.currentTarget.value}))}
                            rows="5"
                        ></textarea>
                        ${e.advancedPrompt&&h`
                            <button class="clear-textarea-btn" onClick=${()=>{t(u=>({...u,advancedPrompt:""}))}} title=${p("clear")}>
                                <${re} />
                            </button>
                        `}
                    </div>
                </${s}>

                ${!a&&h`
                    <div class="form-group">
                        <label for="number-of-results">${p("label_num_results")}</label>
                        <input type="number" min="1" max="5" class="number-input" id="number-of-results" value=${e.numberOfResults} onInput=${u=>t(k=>({...k,numberOfResults:Math.max(1,Math.min(5,parseInt(u.currentTarget.value)||1))}))} />
                    </div>
                `}
            </div>
            
            <button class="btn btn-primary" onClick=${L} disabled=${D||!E} style=${{width:"100%",marginTop:"auto"}}>
                ${D?p("processing"):R||p("button_restore_photo")}
            </button>
        </div>
    `},Gn=({settings:e,setSettings:t,onGenerate:L,generating:f,hasImage:E,isBatch:R=!1,onBackToHome:T,onChooseAnotherImage:n,t:a,onLaunchRefCrop:g,subjectImageUploaded:p,onUploaderHover:I,onLaunchDetailRefCrop:P})=>{const[O,H]=K(!1),[V,G]=K(!1),d=de(null);de(null);const[_,$]=K({aiSource:!0,shotType:!0,refImage:!0,prompt:!0,effects:!0,foreground:!0,weather:!1,lightPro:!1,suggestions:!1,options:!1,numImages:!1}),v=(r,m)=>{if(m){const w={};Object.keys(_).forEach(o=>{w[o]=o===r||o==="prompt"||o==="shotType"||o==="refImage"||o==="effects"&&_.effects||o==="foreground"&&_.foreground}),$(w)}else{if(r==="prompt")return;$(w=>({...w,[r]:!1}))}};le(()=>{e.referenceImage&&v("prompt",!0)},[!!e.referenceImage]);const D=()=>{if(!("webkitSpeechRecognition"in window)){alert("Trình duyệt không hỗ trợ nhập liệu giọng nói.");return}const r=new window.webkitSpeechRecognition;r.lang="vi-VN",r.onstart=()=>H(!0),r.onend=()=>H(!1),r.onresult=m=>{const w=m.results[0][0].transcript;t(o=>({...o,prompt:o.prompt?`${o.prompt} ${w}`:w}))},O?r.stop():r.start()},u=r=>{var w;const m=(w=r.currentTarget.files)==null?void 0:w[0];m&&g(m),r.currentTarget.value=""},k=(r,m)=>{r.preventDefault(),r.stopPropagation(),G(m),I==null||I(m)},q=r=>{var w,o;k(r,!1);const m=(o=(w=r.dataTransfer)==null?void 0:w.files)==null?void 0:o[0];m&&g(m)},Y=r=>{const m=r.trim();t(w=>({...w,prompt:m}))},l=r=>{let m=r;for(const w of Object.values(_e)){const o=w.find(c=>c.key===r);if(o){m=a(o.labelKey);break}}t(w=>{const c=!(w.lightingEffects||[]).includes(r),C=c?[r]:[];let X=(w.prompt||"").split(",").map(Q=>Q.trim()).filter(Q=>Q);for(const Q of Object.values(_e))for(const ae of Q){const ye=a(ae.labelKey);X=X.filter(fe=>fe!==ye)}c&&X.push(m);const Z=c?!1:w.useRimLight;return{...w,lightingEffects:C,prompt:X.join(", "),useRimLight:Z}})},b=(r,m)=>r.split(",").map(w=>w.trim()).includes(m),B=(r,m)=>{t(w=>{let o=w.prompt||"";const c=a("label_foreground_auto"),C=a("label_foreground_flower"),A="Tiền ảnh hoa",X=a("label_foreground_leaf"),Z=[c,C,A,X];let Q=o.split(",").map(ae=>ae.trim()).filter(ae=>ae);return Q=Q.filter(ae=>!Z.includes(ae)),m&&Q.push(r),{...w,prompt:Q.join(", ")}})},N=(r,m)=>{t(w=>{let c=(w.prompt||"").split(",").map(C=>C.trim()).filter(C=>C);return m?c.includes(r)||c.push(r):c=c.filter(C=>C!==r),{...w,prompt:c.join(", ")}})},ne=he(()=>E&&(e.prompt.trim()!==""||e.referenceImage!==null),[E,e.prompt,e.referenceImage]),ie=["f/16","f/11","f/8","f/5.6","f/4","f/3.5","f/2.8","f/2.0","f/1.8","f/1.4","f/1.2"],ge=r=>ie[r]||"f/16";return h`
        <div class="settings-panel">
            <button onClick=${T} class="back-button">${a("backButton")}</button>
            ${n&&!R&&h`<button class="btn btn-secondary" onClick=${n} style=${{width:"100%",marginBottom:"1rem"}}>${a("selectAnotherImage")}</button>`}

            <div style=${{flex:"1",overflowY:"auto",paddingRight:"0.5rem"}}>
                <${oe} 
                    settings=${e} 
                    setSettings=${t} 
                    t=${a} 
                    allowedModels=${["google_image_gen_banana_3","google_image_gen_banana_2","google_image_gen_banana_2_cheap","google_image_gen_banana_pro","google_image_gen_banana_pro_cheap","3.0-omni","google_image_gen_banana","o1","google_image_gen_banana_pro_reason","seedream_4_5"]}
                    open=${_.aiSource}
                    onToggle=${r=>v("aiSource",r)}
                />

                <${s} 
                    title=${a("label_shot_type")} 
                    open=${_.shotType} 
                    onToggle=${r=>v("shotType",r)}
                >
                    <div class="radio-group" style=${{display:"flex",flexDirection:"column",gap:"0.5rem"}}>
                        <label>
                            <input type="radio" name="shotType" value="wide" checked=${e.shotType==="wide"||!e.shotType} onChange=${()=>{t(r=>({...r,shotType:"wide"})),v("shotType",!0)}} />
                            ${a("shot_wide")} <span style=${{color:"#ff4d4f",fontSize:"0.8rem",marginLeft:"0.4rem"}}>${a("shot_wide_note")}</span>
                        </label>
                        <label>
                            <input type="radio" name="shotType" value="full" checked=${e.shotType==="full"} onChange=${()=>{t(r=>({...r,shotType:"full"})),v("shotType",!0)}} />
                            ${a("shot_full")} <span style=${{color:"#ff4d4f",fontSize:"0.8rem",marginLeft:"0.4rem"}}>${a("shot_full_note")}</span>
                        </label>
                        <label>
                            <input type="radio" name="shotType" value="half" checked=${e.shotType==="half"} onChange=${()=>{t(r=>({...r,shotType:"half",useLensBlur:!0,lensBlur:6})),v("shotType",!0)}} />
                            ${a("shot_half")} <span style=${{color:"#ff4d4f",fontSize:"0.8rem",marginLeft:"0.4rem"}}>${a("shot_half_note")}</span>
                        </label>
                        <label>
                            <input type="radio" name="shotType" value="closeup" checked=${e.shotType==="closeup"} onChange=${()=>{t(r=>({...r,shotType:"closeup",useLensBlur:!0,lensBlur:8})),v("shotType",!0)}} />
                            ${a("shot_closeup")} <span style=${{color:"#ff4d4f",fontSize:"0.8rem",marginLeft:"0.4rem"}}>${a("shot_closeup_note")}</span>
                        </label>
                    </div>
                </${s}>

                <${s} 
                    title=${h`<span style=${{color:"#fff",fontSize:"1.1rem",fontWeight:"bold"}}>${a("section_ref_image")}</span>`} 
                    open=${_.refImage} 
                    onToggle=${r=>v("refImage",r)}
                >
                    <div style=${{display:"flex",alignItems:"center",gap:"1.5rem",padding:"0.5rem 0"}}>
                        <div style=${{flex:1,display:"flex",flexDirection:"column"}}>
                            <div style=${{color:"#ff4d4f",fontSize:"0.95rem",fontWeight:"500"}}>${a("section_ref_image_note")}</div>
                        </div>
                        <div style=${{width:"1px",height:"40px",background:"#333",margin:"0 0.25rem"}}></div>
                        <div style=${{position:"relative"}}>
                            <input type="file" ref=${d} onChange=${u} accept="image/*" style=${{display:"none"}} />
                            <div 
                                class="reference-uploader ${V?"drag-over":""}" 
                                onClick=${()=>{var r;return(r=d.current)==null?void 0:r.click()}}
                                style=${{cursor:"pointer",width:"70px",height:"70px",margin:0,flexShrink:0,backgroundColor:"#222",borderRadius:"10px"}}
                                onDragOver=${r=>k(r,!0)}
                                onDragLeave=${r=>k(r,!1)}
                                onDrop=${q}
                                onMouseEnter=${()=>I==null?void 0:I(!0)}
                                onMouseLeave=${()=>I==null?void 0:I(!1)}
                                onPaste=${Pe}
                                title=${p?"":a("error_no_subject_for_ref")}
                            >
                                ${e.referenceImage?h`
                                    <img src=${e.referenceImage} alt="Reference" class="reference-preview"/>
                                    <button class="remove-reference-btn" style=${{width:"1.2rem",height:"1.2rem",padding:"0.15rem"}} onClick=${r=>{r.stopPropagation(),t(m=>({...m,referenceImage:null}))}} title=${a("removeTemplate")}><${re}/></button>
                                    <button 
                                        style=${{position:"absolute",bottom:"4px",right:"4px",background:"rgba(0,0,0,0.6)",border:"1px solid rgba(255,255,255,0.3)",borderRadius:"50%",width:"20px",height:"20px",display:"flex",alignItems:"center",justifyContent:"center",color:"#fff",fontSize:"10px",cursor:"pointer",zIndex:5,backdropFilter:"blur(4px)"}}
                                        onClick=${r=>{r.stopPropagation(),g&&e.referenceImage&&fetch(e.referenceImage).then(m=>m.blob()).then(m=>{const w=new File([m],"ref_image.png",{type:"image/png"});g(w)})}}
                                        title=${a("crop")}
                                    >✂️</button>
                                `:h`
                                    <div class="reference-placeholder" style=${{gap:"2px",padding:"4px"}}>
                                       <${se} style=${{width:"18px",height:"18px",color:"#888"}} />
                                       <span style=${{fontSize:"0.7rem",fontWeight:500,lineHeight:1.1,color:"#aaa"}}>Kéo thả</span>
                                       <span style=${{fontSize:"0.7rem",fontWeight:500,lineHeight:1.1,color:"#aaa"}}>ảnh</span>
                                       <span style=${{fontSize:"0.7rem",fontWeight:500,lineHeight:1.1,color:"#aaa"}}>vào đây</span>
                                       <span style=${{fontSize:"0.55rem",opacity:.6,lineHeight:1,color:"#666"}}>(Chi nhận)</span>
                                    </div>
                                `}
                            </div>
                        </div>
                    </div>
                </${s}>

                <!-- <${s} title=${a("detail_ref_images")}>
                    ... (content omitted for brevity)
                </${s}> -->

                <${s} 
                    title=${a("section_your_prompt")} 
                    open=${_.prompt}
                    onToggle=${r=>v("prompt",r)}
                >
                    <div class="voice-input-container">
                        <textarea
                            id="bg-prompt"
                            placeholder=${a("placeholder_bg_prompt")}
                            value=${e.prompt}
                            onFocus=${()=>v("prompt",!0)}
                            onInput=${r=>t(m=>({...m,prompt:r.currentTarget.value}))}
                            rows="8"
                        ></textarea>
                        ${e.prompt&&h`
                                        <button class="clear-textarea-btn" onClick=${()=>{t(r=>({...r,prompt:""}))}} title=${a("clear")}>
                                            <${re} />
                                        </button>
                                    `}
                        <!-- Voice Input disabled temporarily -->
                        <!-- <button class="voice-btn ${O?"recording":""}" onClick=${D} title=${a("button_voice_input")}>
                            <${Me} recording=${O} />
                        </button> -->
                    </div>

                </${s}>



        <${s} 
            title=${a("section_visual_effects")} 
            open=${_.effects}
            onToggle=${r=>v("effects",r)}
        >
            <${s} 
                title=${h`<span>${a("foreground_background_options")} <span style=${{color:"#ff4d4f",fontSize:"0.85em",marginLeft:"0.5rem"}}>(Nên dùng)</span></span>`} 
                open=${_.foreground}
                onToggle=${r=>v("foreground",r)}
            >
                <div class="checkbox-group" style=${{display:"flex",flexDirection:"column",gap:"0.5rem"}}>
                    ${[{labelKey:"label_foreground_auto",text:a("label_foreground_auto")},{labelKey:"label_foreground_flower",text:a("label_foreground_flower")},{labelKey:"label_foreground_leaf",text:a("label_foreground_leaf")}].map(r=>h`
                                <label>
                                    <input 
                                        type="checkbox"
                                        checked=${b(e.prompt||"",r.text)}
                                        onChange=${m=>{B(r.text,m.currentTarget.checked),v("effects",!0),v("foreground",!0)}}
                                    />
                                    ${a(r.labelKey)}
                                </label>
                            `)}
                </div>

                ${(b(e.prompt||"",a("label_foreground_flower"))||b(e.prompt||"",a("label_foreground_leaf")))&&h`
                            <div class="form-group" style=${{marginTop:"0.75rem",paddingLeft:"0.5rem"}}>
                                <label style=${{fontSize:"0.85rem"}}>${a("label_foreground_amount")}: ${a("amount_"+(e.foregroundAmount||"medium"))}</label>
                                <input 
                                    type="range" 
                                    min="0" 
                                    max="2" 
                                    step="1" 
                                    value=${e.foregroundAmount==="low"?0:e.foregroundAmount==="high"?2:1} 
                                    onInput=${r=>{const m=parseInt(r.currentTarget.value),w=m===0?"low":m===2?"high":"medium";t(o=>({...o,foregroundAmount:w}))}}
                                    style=${{width:"100%"}}
                                />
                                <div style=${{display:"flex",justifyContent:"space-between",fontSize:"0.75rem",color:"var(--text-secondary)"}}>
                                    <span>${a("amount_low")}</span>
                                    <span>${a("amount_medium")}</span>
                                    <span>${a("amount_high")}</span>
                                </div>
                            </div>
                        `}
            </${s}>

            <div class="form-group">
                <div style=${{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"0.5rem"}}>
                    <label style=${{display:"flex",alignItems:"center",gap:"0.5rem",cursor:"pointer"}}>
                        <input
                            type="checkbox"
                            checked=${e.useLensBlur}
                            onChange=${r=>{t(m=>({...m,useLensBlur:r.currentTarget.checked})),v("effects",!0)}}
                        />
                        ${a("label_lens_blur")}
                    </label>
                    <span style=${{color:"var(--text-secondary)",opacity:e.useLensBlur?1:.5}}>${ge(e.lensBlur)}</span>
                </div>
                <input
                    type="range"
                    id="lens-blur-slider"
                    min="0"
                    max="10"
                    step="1"
                    disabled=${!e.useLensBlur}
                    style=${{width:"100%",opacity:e.useLensBlur?1:.5}}
                    value=${e.lensBlur}
                    onInput=${r=>t(m=>({...m,lensBlur:parseInt(r.currentTarget.value,10)}))}
                />
            </div>

            <div class="form-group">
                <label style=${{marginBottom:"0.5rem",display:"block"}}>${a("section_color_sync")}</label>
                <select
                    class="form-control"
                    value=${e.colorSyncMode||"none"}
                    onChange=${r=>{const m=r.currentTarget.value;v("effects",!0);const w={sync_character_scene:"Đồng bộ màu sắc giữa nhân vật và cảnh.",ref_bg_follows_subject:"Điều chỉnh màu sắc và độ tương phản của nền tham chiếu để phù hợp với chủ thể.",subject_follows_ref_bg:"Điều chỉnh màu sắc và độ tương phản của chủ thể để phù hợp với nền tham chiếu."};t(o=>{let c=o.prompt||"";return Object.values(w).forEach(C=>{c.includes(C)&&(c=c.replace(C,"").replace(/\s\s+/g," ").trim())}),m!=="none"&&w[m]&&(c=`${c} ${w[m]}`.trim()),{...o,colorSyncMode:m,prompt:c}})}}
                    style=${{width:"100%",padding:"0.5rem",borderRadius:"6px",background:"var(--surface-2)",color:"var(--text-primary)",border:"1px solid var(--border-color)"}}
                >
                    <option value="none">${a("option_none")}</option>
                    <option value="sync_character_scene">${a("option_sync_character_scene")}</option>
                    <option value="ref_bg_follows_subject">${a("option_ref_bg_follows_subject")}</option>
                    <option value="subject_follows_ref_bg">${a("option_subject_follows_ref_bg")}</option>
                </select>
            </div>
            <${s} title=${h`<span>${a("section_light_painting")} <span style=${{color:"#ff4d4f",fontSize:"0.85em",marginLeft:"0.5rem"}}>${a("section_light_painting_note")}</span></span>`} initialOpen=${!1}>
                <div class="form-group">
                    <label>
                        <input
                            type="checkbox"
                            checked=${e.useRimLight}
                            onChange=${r=>{const m=r.currentTarget.checked;t(w=>{let o=w.lightingEffects,c=w.prompt||"";if(m){o=[];let C=c.split(",").map(A=>A.trim()).filter(A=>A);for(const A of Object.values(_e))for(const X of A){const Z=a(X.labelKey);C=C.filter(Q=>Q!==Z)}c=C.join(", ")}return{...w,useRimLight:m,lightingEffects:o,prompt:c}})}}
                        />
                        ${a("label_rim_light")}
                    </label>
                </div>
                <div class="form-group" style=${{marginTop:"0.5rem"}}>
                    <label>
                        <input
                            type="checkbox"
                            checked=${e.useGoldenHourBacklight}
                            onChange=${r=>{t(m=>({...m,useGoldenHourBacklight:r.currentTarget.checked}))}}
                        />
                        ${a("lighting_effect_backlight_golden_hour")}
                    </label>
                </div>
                ${e.useRimLight&&h`
                            <div style=${{display:"flex",gap:"1rem",marginTop:"0.5rem",paddingLeft:"1.5rem"}}>
                                <div class="form-group" style=${{flex:1}}>
                                    <label style=${{fontSize:"0.85rem"}}>${a("label_direction")}</label>
                                    <select 
                                        value=${e.rimLightDirection} 
                                        onChange=${r=>t(m=>({...m,rimLightDirection:r.currentTarget.value}))}
                                        style=${{padding:"0.25rem"}}
                                    >
                                        <option value="left">${a("direction_left")}</option>
                                        <option value="right">${a("direction_right")}</option>
                                        <option value="top">${a("direction_top")}</option>
                                        <option value="bottom">${a("direction_bottom")}</option>
                                    </select>
                                </div>
                                <div class="form-group" style=${{flex:1}}>
                                    <label style=${{fontSize:"0.85rem"}}>${a("label_intensity")}</label>
                                    <select 
                                        value=${e.rimLightIntensity} 
                                        onChange=${r=>t(m=>({...m,rimLightIntensity:r.currentTarget.value}))}
                                        style=${{padding:"0.25rem"}}
                                    >
                                        <option value="strong">${a("intensity_strong")}</option>
                                        <option value="medium">${a("intensity_medium")}</option>
                                        <option value="weak">${a("intensity_weak")}</option>
                                    </select>
                                </div>
                            </div>
                        `}
            </${s}>
            <${s} title=${a("weather_options")} initialOpen=${!1}>
                <div class="checkbox-group" style=${{gap:"0.5rem",paddingLeft:"0.5rem"}}>
                    ${[{labelKey:"label_weather_sunny",text:a("label_weather_sunny")},{labelKey:"label_weather_harsh",text:a("label_weather_harsh")},{labelKey:"label_weather_sunset",text:a("label_weather_sunset")},{labelKey:"label_weather_night",text:a("label_weather_night")},{labelKey:"label_weather_snow",text:a("label_weather_snow")},{labelKey:"label_weather_rain",text:a("label_weather_rain")},{labelKey:"label_weather_fog",text:a("label_weather_fog")}].map(r=>h`
                                <label>
                                    <input 
                                        type="checkbox" 
                                        checked=${(e.prompt||"").includes(r.text)} 
                                        onChange=${m=>N(r.text,m.currentTarget.checked)} 
                                    />
                                    ${a(r.labelKey)}
                                </label>
                            `)}
                </div>
            </${s}>
            <${s} title=${a("section_lighting_effects")} initialOpen=${!1}>
                <div class="suggestions-list" style=${{maxHeight:"none",overflowY:"visible",border:"none",background:"transparent",padding:"0"}}>
                    ${Object.entries(_e).map(([r,m])=>h`
                                <div class="suggestion-sub-category" style=${{marginBottom:"0.5rem"}}>
                                    <h4>${a(r)}</h4>
                                    <div class="checkbox-group" style=${{gap:"0.5rem",paddingLeft:"0.5rem"}}>
                                        ${m.map(w=>{var o;return h`
                                            <label>
                                                <input
                                                    type="checkbox"
                                                    checked=${(o=e.lightingEffects)==null?void 0:o.includes(w.key)}
                                                    onChange=${()=>l(w.key)}
                                                />
                                                <span>${a(w.labelKey)}</span>
                                            </label>
                                        `})}
                                    </div>
                                </div>
                            `)}
                </div>
            </${s}>
        </${s}>

            <${s} 
                title=${a("options")} 
                open=${_.options} 
                onToggle=${r=>v("options",r)}
            >
                <div class="checkbox-group">
                    <label>
                        <input type="checkbox" checked=${e.keepPose} onChange=${r=>t(m=>({...m,keepPose:r.currentTarget.checked}))} />
                        ${a("checkbox_keep_pose")}
                    </label>
                    <label>
                        <input type="checkbox" checked=${e.keepComposition} onChange=${r=>t(m=>({...m,keepComposition:r.currentTarget.checked}))} />
                        ${a("checkbox_keep_composition")}
                    </label>
                    <label>
                        <input type="checkbox" checked=${e.keepFocalLength} onChange=${r=>t(m=>({...m,keepFocalLength:r.currentTarget.checked}))} />
                        ${a("checkbox_keep_focal_length")}
                    </label>
                    <label>
                        <input type="checkbox" checked=${e.keepAspectRatio} onChange=${r=>t(m=>({...m,keepAspectRatio:r.currentTarget.checked}))} />
                        ${a("checkbox_keep_aspect_ratio")}
                    </label>
                </div>
            </${s}>

                <${s} 
                    title=${a("section_prompt_suggestions")} 
                    open=${_.suggestions} 
                    onToggle=${r=>v("suggestions",r)}
                >
                    ${Sn.map(r=>h`
                        <${s} title=${a(r.labelKey)} initialOpen=${!1}>
                            <div class="suggestions-list" style=${{resize:"none",height:"250px",padding:"0.5rem"}}>
                                ${r.subCategories.map(m=>h`
                                    <div class="suggestion-sub-category">
                                        <h4>${a(m.labelKey)}</h4>
                                        <ul>
                                            ${m.items.map(w=>h`
                                                <li onClick=${()=>Y(a(w.promptKey))}>
                                                    ${a(w.promptKey)}
                                                </li>
                                            `)}
                                        </ul>
                                    </div>
                                `)}
                            </div>
                        </${s}>
                    `)}
                </${s}>

                        ${!R&&h`
                    <${s} 
                        title=${a("numberOfImages")} 
                        open=${_.numImages} 
                        onToggle=${r=>v("numImages",r)}
                    >
                        <${pe}
                            value=${e.numImages}
                            options=${[1,2,3,4]}
                            onChange=${r=>{t(m=>({...m,numImages:r})),v("numImages",!0)}}
                        />
                    </${s}>
                `}
            </div>
            
            ${!R&&h`<${me} t=${a} />`}
            ${!R&&h`
                <button class="btn btn-primary" onClick=${L} disabled=${f||!ne} style=${{width:"100%"}}>
                    ${a(f?"processing":"button_generate_photo_enter")}
                </button>
            `}
        </div>
    `},qn=({settings:e,setSettings:t,onGenerate:L,generating:f,hasImage:E,onBackToHome:R,onChooseAnotherImage:T,buttonText:n,isBatch:a=!1,onEnterFullscreen:g,t:p,language:I})=>{const[P,O]=K(!1),[H,V]=K(!1),[G,d]=K(!1),[_,$]=K("");le(()=>{if(_){const l=setTimeout(()=>{$("")},5e3);return()=>clearTimeout(l)}},[_]);const v=()=>{if(!("webkitSpeechRecognition"in window)){alert(p("error_voice_not_supported"));return}const l=new window.webkitSpeechRecognition;l.lang=I,l.onstart=()=>O(!0),l.onend=()=>O(!1),l.onresult=b=>{const B=b.results[0][0].transcript;t(N=>({...N,prompt:N.prompt?`${N.prompt} ${B} `:B}))},P?l.stop():l.start()},D=async()=>{if(e.referenceImage){d(!0),$("");try{const l=await Ie(e.referenceImage,"clothing",I);t(b=>({...b,prompt:l})),$(p("toast_analysis_complete_clothing"))}catch(l){console.error("Failed to auto-describe image:",l),$(p("toast_analysis_error_clothing"))}finally{d(!1)}}},u=l=>{g==null||g();const b=new FileReader;b.onload=B=>{var ne;const N=(ne=B.target)==null?void 0:ne.result;N&&(t(ie=>({...ie,referenceImage:N})),D())},b.readAsDataURL(l)},k=(l,b)=>{l.preventDefault(),l.stopPropagation(),V(b)},q=l=>{var b,B;k(l,!1),(B=(b=l.dataTransfer)==null?void 0:b.files)!=null&&B[0]&&u(l.dataTransfer.files[0])},Y=he(()=>E&&(e.prompt.trim()!==""||e.referenceImage!==null),[E,e.prompt,e.referenceImage]);return h`
        ${_&&h`<div class="toast-notification">${_}</div>`}
<div class="settings-panel">
    <button onClick=${R} class="back-button">${p("backButton")}</button>
    ${T&&!a&&h`<button class="btn btn-secondary" onClick=${T} style=${{width:"100%",marginBottom:"1rem"}}>${p("selectAnotherImage")}</button>`}

    <div style=${{flex:"1",overflowY:"auto",paddingRight:"0.5rem"}}>
        <${oe} settings=${e} setSettings=${t} t=${p} allowedModels=${["google_image_gen_banana_3","google_image_gen_banana_2","google_image_gen_banana_2_cheap","google_image_gen_banana_pro","google_image_gen_banana_pro_cheap","3.0-omni","google_image_gen_banana","o1","google_image_gen_banana_pro_reason","seedream_4_5"]} />
        <${s} title=${p("section_clothing_description")}>
            <div class="voice-input-container">
                <textarea
                    placeholder=${p("placeholder_clothing_change")}
                    value=${e.prompt}
                    rows="4"
                    onInput=${l=>t(b=>({...b,prompt:l.currentTarget.value}))}
                ></textarea>
                ${e.prompt&&h`
                            <button class="clear-textarea-btn" onClick=${()=>t(l=>({...l,prompt:""}))} title=${p("clear")}>
                                <${re} />
                            </button>
                        `}
                <!-- Voice Input disabled temporarily -->
                <!-- <button class="voice-btn ${P?"recording":""}" onClick=${v} title=${p("button_voice_input")}>
                    <${Me} recording=${P} />
                </button> -->
            </div>
        </${s}>

        <${s} title=${p("section_clothing_ref")}>
            <div
                class="reference-uploader ${H?"drag-over":""}"
                style=${{cursor:"default",width:"100%",height:"120px"}}
                onDragOver=${l=>k(l,!0)}
                onDragLeave=${l=>k(l,!1)}
                onDrop=${q}
                onPaste=${Pe}
            >
                ${e.referenceImage?h`
                            <img src=${e.referenceImage} alt="Reference" class="reference-preview"/>
                            <button class="remove-reference-btn" onClick=${l=>{l.stopPropagation(),t(b=>({...b,referenceImage:null}))}} title=${p("removeTemplate")}><${re}/></button>
                        `:h`
                            <div class="reference-placeholder" style=${{gap:"0.25rem"}}>
                               <${se} />
                               <span style=${{fontWeight:500}}>${p("uploader_drag_drop_prompt")}</span>
                               <span style=${{fontSize:"0.8em",opacity:.7}}>${p("uploader_drag_drop_note")}</span>
                            </div>
                        `}
            </div>
            <button class="btn btn-secondary" style=${{width:"100%",marginTop:"1rem"}} onClick=${D} disabled=${!e.referenceImage||G}>
                ${p(G?"processing":"button_auto_describe_ref")}
            </button>
        </${s}>

        <${s} title=${p("section_color_optional")} initialOpen=${!1}>
            <div class="radio-group">
                <label>
                    <input type="radio" name="clothing-color" value="" checked=${!e.color} onChange=${()=>t(l=>({...l,color:null}))} />
                    ${p("option_none")}
                </label>
                <label>
                    <input type="radio" name="clothing-color" value="red" checked=${e.color==="red"} onChange=${()=>t(l=>({...l,color:"red"}))} />
                    ${p("color_red")}
                </label>
                <label>
                    <input type="radio" name="clothing-color" value="black" checked=${e.color==="black"} onChange=${()=>t(l=>({...l,color:"black"}))} />
                    ${p("color_black")}
                </label>
                <label>
                    <input type="radio" name="clothing-color" value="white" checked=${e.color==="white"} onChange=${()=>t(l=>({...l,color:"white"}))} />
                    ${p("color_white")}
                </label>
            </div>
        </${s}>

        ${!a&&h`
                    <${s} title=${p("numberOfImages")}>
                        <${pe}
                            value=${e.numImages}
                            options=${[1,2,3,4]}
                            onChange=${l=>{t(b=>({...b,numImages:l}))}}
                        />
                    </${s}>
                `}
    </div>

    <${me} t=${p} />
    <button class="btn btn-primary" onClick=${L} disabled=${f||G||!Y} style=${{width:"100%"}}>
        ${f||G?p("processing"):n||p("button_generate_photo_enter")}
    </button>
</div>
`},Hn=({settings:e,setSettings:t,onGenerate:L,generating:f,hasImage:E,onBackToHome:R,onChooseAnotherImage:T,t:n})=>{const a=he(()=>Dn[e.gender],[e.gender]);return h`
    <div class="settings-panel" >
        <button onClick=${R} class="back-button">${n("backButton")}</button>
            ${T&&h`<button class="btn btn-secondary" onClick=${T} style=${{width:"100%",marginBottom:"1rem"}}>${n("selectAnotherImage")}</button>`}
            
            <div style=${{flex:"1",overflowY:"auto",paddingRight:"0.5rem"}}>
                <${oe} settings=${e} setSettings=${t} t=${n} />
                <${s} title=${n("section_select_concept")}>
                    <div class="radio-group" style=${{marginBottom:"1rem"}}>
                        <label>
                            <input type="radio" name="gender-baby" value="boy" checked=${e.gender==="boy"} onChange=${()=>t(g=>({...g,gender:"boy",selectedConceptPrompt:null}))} />
                            ${n("gender_boy")}
                        </label>
                        <label>
                            <input type="radio" name="gender-baby" value="girl" checked=${e.gender==="girl"} onChange=${()=>t(g=>({...g,gender:"girl",selectedConceptPrompt:null}))} />
                            ${n("gender_girl")}
                        </label>
                    </div>
                    <div class="clothing-grid">
                        ${a.map(g=>h`
                            <button 
                                class="clothing-btn ${e.selectedConceptPrompt===g.prompt?"active":""}"
                                onClick=${()=>t(p=>({...p,selectedConceptPrompt:g.prompt}))}
                            >${n(g.labelKey)}</button>
                        `)}
                    </div>
                </${s}>
                
                <${s} title=${n("numberOfImages")}>
                    <${pe}
                        value=${e.numImages}
                        options=${[1,2,3,4]}
                        onChange=${g=>t(p=>({...p,numImages:g}))}
                    />
                </${s}>
            </div>
            
            <${me} t=${n} />
            <button class="btn btn-primary" onClick=${L} disabled=${f||!E||!e.selectedConceptPrompt} style=${{width:"100%"}}>
                ${n(f?"processing":"button_generate_photo_enter")}
            </button>
        </div>
    `},Vn=({settings:e,setSettings:t,onGenerate:L,generating:f,onBackToHome:E,t:R,isDescribing:T,currentImage:n})=>{const[a,g]=K({ai_source:!0,my_prompt:!0,num_images:!0}),p=($,v)=>{v?g({ai_source:!1,my_prompt:!1,num_images:!1,[$]:!0}):Object.values(a).filter(Boolean).length>1?g({ai_source:!1,my_prompt:!1,num_images:!1,[$]:!0}):g(u=>({...u,[$]:!1}))},[I,P]=K(!1),[O,H]=K(!1),V=de(null),G=async $=>{P(!0);try{const v=await dn($,"vi");if(!v.trim())return;t(D=>{const u=(D.myPrompt||"").trim(),k=u?`${v}

${u}`:v;return{...D,myPrompt:k}})}catch(v){console.error("Failed to analyze reference:",v)}finally{P(!1)}},d=$=>{var u;const v=(u=$.currentTarget.files)==null?void 0:u[0];if(!v)return;const D=new FileReader;D.onload=k=>{var Y;const q=(Y=k.target)==null?void 0:Y.result;q&&G(q)},D.readAsDataURL(v),$.currentTarget.value=""},_=$=>{var D,u;$.preventDefault(),$.stopPropagation(),H(!1);const v=(u=(D=$.dataTransfer)==null?void 0:D.files)==null?void 0:u[0];if(v&&v.type.startsWith("image/")){const k=new FileReader;k.onload=q=>{var l;const Y=(l=q.target)==null?void 0:l.result;Y&&G(Y)},k.readAsDataURL(v)}};return h`
    <div class="settings-panel" >
        <button onClick=${E} class="back-button">${R("backButton")}</button>

             <div style=${{flex:"1",overflowY:"auto",paddingRight:"0.5rem"}}>
                <${oe} 
                    settings=${e} 
                    setSettings=${t} 
                    t=${R} 
                    allowedModels=${["google_image_gen_banana_3","google_image_gen_banana_2","google_image_gen_banana_2_cheap","google_image_gen_banana_pro","google_image_gen_banana_pro_cheap","3.0-omni","google_image_gen_banana","o1","google_image_gen_banana_pro_reason","seedream_4_5"]}
                    open=${a.ai_source} 
                    onToggle=${$=>p("ai_source",$)}
                />
                



                <${s}
                    title="📷 Ảnh tham chiếu (dáng & bối cảnh)"
                    initialOpen=${!0}
                >
                    <input type="file" ref=${V} onChange=${d} accept="image/*" style=${{display:"none"}} />
                    <div
                        class="reference-uploader ${O?"drag-over":""}"
                        style=${{cursor:"pointer",width:"100%",height:"110px",marginBottom:"0.5rem",borderRadius:"10px",background:"#181818"}}
                        onClick=${()=>{var $;return($=V.current)==null?void 0:$.click()}}
                        onDragOver=${$=>{$.preventDefault(),H(!0)}}
                        onDragEnter=${$=>{$.preventDefault(),H(!0)}}
                        onDragLeave=${()=>H(!1)}
                        onDrop=${_}
                    >
                        <div class="reference-placeholder" style=${{gap:"0.3rem"}}>
                            <${se} style=${{width:"22px",height:"22px",color:"#888"}} />
                            <span style=${{fontWeight:600,fontSize:"0.85rem",color:"#ccc"}}>Kéo thả hoặc nhấn để chọn ảnh</span>
                            <span style=${{fontSize:"0.72rem",color:"#666"}}>AI phân tích dáng, trang phục & bối cảnh</span>
                            <span style=${{fontSize:"0.68rem",color:"#555"}}>(Không mô tả khuôn mặt)</span>
                        </div>
                    </div>
                    ${I&&h`
                        <div style=${{textAlign:"center",color:"#ffdd57",fontSize:"0.85rem",padding:"0.25rem 0"}}>
                            ⏳ Đang phân tích ảnh...
                        </div>
                    `}
                </${s}>

                <${s} 
                    title=${R("section_my_prompt")} 
                    open=${a.my_prompt}
                    onToggle=${$=>p("my_prompt",$)}
                >
                    <div style=${{display:"flex",flexDirection:"column",gap:"0.5rem"}}>
                        <textarea 
                            style=${{width:"100%",minHeight:"240px",background:"#1a1a1a",color:"#fff",border:"1px solid #333",borderRadius:"8px",padding:"0.5rem",fontSize:"0.9rem"}}
                            placeholder=${R("placeholder_posing_studio")}
                            value=${e.myPrompt||""}
                            onInput=${$=>t(v=>({...v,myPrompt:$.currentTarget.value}))}
                        ></textarea>
                        ${T&&h`
                            <div style=${{fontSize:"0.85rem",color:"#ffdd57",textAlign:"center",marginTop:"0.25rem"}}>
                                ${R("button_analyzing")}
                            </div>
                        `}
                    </div>
                </${s}>

                

                <${s} 
                    title=${R("section_num_images_posing")}
                    open=${a.num_images}
                    onToggle=${$=>p("num_images",$)}
                >
                    <${pe}
                        value=${e.numImages}
                        options=${[1,2,3,4]}
                        onChange=${$=>t(v=>({...v,numImages:$}))}
                    />
                </${s}>

             </div>

            <button class="btn btn-primary" onClick=${L} disabled=${f||!n&&!e.faceReferenceImage} style=${{width:"100%"}}>
                ${R(f?"processing_posing":"button_generate_photo_enter")}
            </button>
        </div>
    `},On=({settings:e,setSettings:t,onGenerate:L,generating:f,hasImage:E,onBackToHome:R,onChooseAnotherImage:T,t:n,language:a,isBatch:g=!1,buttonText:p,onLaunchDetailRefCrop:I})=>{const[P,O]=K(!1),[H,V]=K(!1),G=de(null),[d,_]=K("ai_source"),$=(o,c)=>{c?_(o):d===o&&_("")},v=(o,c)=>{o.preventDefault(),o.stopPropagation(),V(c)},D=o=>{var C;v(o,!1);const c=(C=o.dataTransfer)==null?void 0:C.files;if(c&&c.length>0){const A=c[0],X=new FileReader;X.onload=()=>t(Z=>({...Z,assistantImage:X.result})),X.readAsDataURL(A)}},[u,k]=K([]),[q,Y]=K(null),[l,b]=K(""),[B,N]=K("");le(()=>{const o=localStorage.getItem("JIYING_CUSTOM_BUTTONS");if(o)try{const c=JSON.parse(o);k(c),t(C=>({...C,jiyingCustomButtons:c}))}catch(c){console.error("Failed to parse Jiying Custom Buttons",c)}},[]),le(()=>{(u.length>0||localStorage.getItem("JIYING_CUSTOM_BUTTONS"))&&t(o=>({...o,jiyingCustomButtons:u}))},[u]);const ne=()=>{const o={id:Date.now().toString(),label:"New Button",prompt:"",isActive:!1},c=[...u,o];k(c),localStorage.setItem("JIYING_CUSTOM_BUTTONS",JSON.stringify(c)),Y(o.id),b(o.label),N(o.prompt)},ie=o=>{if(!confirm(n("confirm_delete_button")))return;const c=u.filter(C=>C.id!==o);k(c),localStorage.setItem("JIYING_CUSTOM_BUTTONS",JSON.stringify(c))},ge=()=>{if(!q)return;const o=u.map(c=>c.id===q?{...c,label:l,prompt:B}:c);k(o),localStorage.setItem("JIYING_CUSTOM_BUTTONS",JSON.stringify(o)),Y(null)},r=o=>{const c=u.map(C=>C.id===o?{...C,isActive:!C.isActive}:C);k(c),localStorage.setItem("JIYING_CUSTOM_BUTTONS",JSON.stringify(c))},m=async()=>{if(e.assistantImage){O(!0);try{const o=await Ie(e.assistantImage,"custom",a,"concise",e.assistantPrompt||"Mô tả chi tiết nội dung trong ảnh này");t(c=>({...c,prompt:c.prompt?`${c.prompt} ${o} `:o}))}catch(o){console.error(o),alert(n("error_describe_failed"))}finally{O(!1)}}},w=o=>{o.clipboardData&&o.preventDefault()};return h`
    <div class="settings-panel" >
        <button onClick=${R} class="back-button">${n("backButton")}</button>

            
            <div style=${{flex:"1",overflowY:"auto",paddingRight:"0.5rem"}}>
                <${oe} 
                    settings=${e} 
                    setSettings=${t} 
                    t=${n} 
                    allowedModels=${["google_image_gen_banana_3","google_image_gen_banana_2","google_image_gen_banana_2_cheap","google_image_gen_banana_pro","google_image_gen_banana_pro_cheap","3.0-omni","google_image_gen_banana","o1","google_image_gen_banana_pro_reason","seedream_4_5"]}
                    open=${d==="ai_source"}
                    onToggle=${o=>$("ai_source",o)}
                />
                <${s} 
                    title=${n("section_ai_assistant")}
                    open=${d==="ai_assistant"}
                    onToggle=${o=>$("ai_assistant",o)}
                >
                    <!-- <${$e}>${n("note_ai_assistant")}</${$e}> -->
                     <div 
                        class="reference-uploader ${H?"drag-over":""}" 
                        style=${{cursor:"default"}}
                        onDragOver=${o=>v(o,!0)}
                        onDragEnter=${o=>v(o,!0)}
                        onDragLeave=${o=>v(o,!1)}
                        onDrop=${D}
                        onPaste=${w}
                    >
                        ${e.assistantImage?h`
                            <img src=${e.assistantImage} alt="Assistant Image" class="reference-preview"/>
                            <button class="remove-reference-btn" onClick=${o=>{o.stopPropagation(),t(c=>({...c,assistantImage:null}))}} title=${n("removeTemplate")}><${re}/></button>
                        `:h`
                            <div class="reference-placeholder" style=${{gap:"0.25rem"}}>
                               <${se} />
                               <span style=${{fontWeight:500}}>${n("uploader_drag_drop_prompt")}</span>
                               <span style=${{fontSize:"0.8em",opacity:.7}}>${n("uploader_drag_drop_note")}</span>
                            </div>
                        `}
                    </div>
                    <textarea 
                        placeholder="Phân tích ảnh lấy thông tin gì? Ví dụ: trang phục, phong cách, phối màu..."
                        value=${e.assistantPrompt||""}
                        onInput=${o=>t(c=>({...c,assistantPrompt:o.currentTarget.value}))}
                        rows="2"
                        style=${{width:"100%",marginTop:"10px",background:"rgba(0,0,0,0.2)",border:"1px solid rgba(255,255,255,0.1)",borderRadius:"6px",color:"#fff",fontSize:"13px",resize:"none",padding:"8px"}}
                    ></textarea>
                    <button class="btn btn-secondary" style=${{width:"100%",marginTop:"10px"}} onClick=${m} disabled=${!e.assistantImage||P}>
                        ${n(P?"processing":"button_auto_describe")}
                    </button>
                </${s}>
                
                <${s} 
                    title=${n("section_edit_request")} 
                    open=${!0}
                >
                    <textarea 
                        class="form-group"
                        placeholder=${n("placeholder_ai_editor")}
                        value=${e.prompt}
                        onInput=${o=>t(c=>({...c,prompt:o.currentTarget.value}))}
                        rows="6"
                    ></textarea>
                </${s}>

                <${s} 
                    title=${n("section_jiying")} 
                    open=${d==="jiying"}
                    onToggle=${o=>$("jiying",o)}
                >
                    <div class="form-group" style=${{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:"8px"}}>
                        <label>
                            <input
                                type="checkbox"
                                checked=${e.fixGrass}
                                onChange=${o=>t(c=>({...c,fixGrass:o.currentTarget.checked}))}
                            />
                            ${n("label_fix_grass")}
                        </label>
                        ${e.fixGrass&&h`
                            <div class="form-group" style=${{marginLeft:"auto",minWidth:"100px"}}>
                                <select 
                                    value=${e.fixGrassIntensity||"medium"} 
                                    onChange=${o=>t(c=>({...c,fixGrassIntensity:o.currentTarget.value}))}
                                    style=${{padding:"0.25rem",fontSize:"0.85em"}}
                                >
                                    <option value="high">${n("intensity_many")}</option>
                                    <option value="medium">${n("intensity_normal")}</option>
                                    <option value="low">${n("intensity_little")}</option>
                                </select>
                            </div>
                        `}
                    </div>
                    <div class="form-group" style=${{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:"8px"}}>
                         <label>
                            <input
                                type="checkbox"
                                checked=${e.removeDebris}
                                onChange=${o=>t(c=>({...c,removeDebris:o.currentTarget.checked}))}
                            />
                            ${n("label_remove_debris")}
                        </label>
                        ${e.removeDebris&&h`
                            <div class="form-group" style=${{marginLeft:"auto",minWidth:"100px"}}>
                                <select 
                                    value=${e.removeDebrisIntensity||"medium"} 
                                    onChange=${o=>t(c=>({...c,removeDebrisIntensity:o.currentTarget.value}))}
                                    style=${{padding:"0.25rem",fontSize:"0.85em"}}
                                >
                                    <option value="high">${n("intensity_many")}</option>
                                    <option value="medium">${n("intensity_normal")}</option>
                                    <option value="low">${n("intensity_little")}</option>
                                </select>
                            </div>
                        `}
                    </div>
                    <div class="form-group" style=${{display:"flex",alignItems:"center",justifyContent:"space-between"}}>
                        <label>
                            <input
                                type="checkbox"
                                checked=${e.fixSkirt}
                                onChange=${o=>t(c=>({...c,fixSkirt:o.currentTarget.checked}))}
                            />
                            ${n("label_fix_skirt")}
                        </label>
                        ${e.fixSkirt&&h`
                            <div class="form-group" style=${{marginLeft:"auto",minWidth:"100px"}}>
                                <select 
                                    value=${e.fixSkirtIntensity||"medium"} 
                                    onChange=${o=>t(c=>({...c,fixSkirtIntensity:o.currentTarget.value}))}
                                    style=${{padding:"0.25rem",fontSize:"0.85em"}}
                                >
                                    <option value="high">${n("intensity_many")}</option>
                                    <option value="medium">${n("intensity_normal")}</option>
                                    <option value="low">${n("intensity_little")}</option>
                                </select>
                            </div>
                        `}
                    </div>
                    <div class="form-group" style=${{display:"flex",alignItems:"center",justifyContent:"space-between",marginTop:"8px"}}>
                        <label>
                            <input
                                type="checkbox"
                                checked=${e.waterWaves}
                                onChange=${o=>t(c=>({...c,waterWaves:o.currentTarget.checked}))}
                            />
                            ${n("label_water_waves")}
                        </label>
                        ${e.waterWaves&&h`
                            <div class="form-group" style=${{marginLeft:"auto",minWidth:"100px"}}>
                                <select 
                                    value=${e.waterWavesIntensity||"medium"} 
                                    onChange=${o=>t(c=>({...c,waterWavesIntensity:o.currentTarget.value}))}
                                    style=${{padding:"0.25rem",fontSize:"0.85em"}}
                                >
                                    <option value="high">${n("intensity_many")}</option>
                                    <option value="medium">${n("intensity_normal")}</option>
                                    <option value="low">${n("intensity_little")}</option>
                                </select>
                            </div>
                        `}
                    </div>
                    <div class="form-group" style=${{marginTop:"12px"}}>
                        <div style=${{display:"flex",alignItems:"center",justifyContent:"space-between"}}>
                            <label>
                                <input
                                    type="checkbox"
                                    checked=${e.jiyingLensBlurEnabled}
                                    onChange=${o=>t(c=>({...c,jiyingLensBlurEnabled:o.currentTarget.checked}))}
                                />
                                ${n("label_lens_blur")}
                            </label>
                            ${e.jiyingLensBlurEnabled&&h`
                                <span style=${{fontSize:"0.85em",fontWeight:"bold",color:"#00d1b2"}}>
                                    ${["f/16","f/11","f/8","f/5.6","f/4","f/3.5","f/2.8","f/2.0","f/1.8","f/1.4","f/1.2"][e.jiyingLensBlurLevel||0]}
                                </span>
                            `}
                        </div>
                        ${e.jiyingLensBlurEnabled&&h`
                            <div style=${{marginTop:"4px",paddingLeft:"1.5rem"}}>
                                <input 
                                    type="range" 
                                    min="0" 
                                    max="10" 
                                    step="1" 
                                    value=${e.jiyingLensBlurLevel||0} 
                                    onInput=${o=>t(c=>({...c,jiyingLensBlurLevel:parseInt(o.currentTarget.value)}))}
                                    style=${{width:"100%"}}
                                />
                                <div style=${{display:"flex",justifyContent:"space-between",fontSize:"0.75em",color:"#888"}}>
                                    <span>F16</span>
                                    <span>F1.2</span>
                                </div>
                            </div>
                        `}
                    </div>

                     <div style=${{borderTop:"1px solid rgba(255,255,255,0.1)",marginTop:"12px",paddingTop:"12px"}}>
                        <div style=${{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:"8px"}}>
                            <span style=${{fontSize:"0.9em",fontWeight:"bold"}}>Custom Controls</span>
                            <button 
                                onClick=${ne} 
                                style=${{background:"none",border:"none",color:"#00d1b2",cursor:"pointer",fontSize:"1.2em",padding:"0 4px"}}
                                title={t('label_add_custom_button')}
                            >+</button>
                        </div>
                        
                        ${u.map(o=>h`
                            <div key=${o.id} style=${{background:"rgba(255,255,255,0.03)",padding:"8px",borderRadius:"6px",marginBottom:"8px",border:q===o.id?"1px solid #00d1b2":"1px solid transparent"}}>
                                ${q===o.id?h`
                                    <div style=${{display:"flex",flexDirection:"column",gap:"8px"}}>
                                        <input 
                                            type="text" 
                                            value=${l} 
                                            onInput=${c=>b(c.currentTarget.value)}
                                            placeholder=${n("label_custom_button_name")}
                                            style=${{background:"#222",border:"1px solid #444",color:"#fff",padding:"4px 8px",borderRadius:"4px",fontSize:"0.9em"}}
                                        />
                                        <textarea 
                                            value=${B} 
                                            onInput=${c=>N(c.currentTarget.value)}
                                            placeholder=${n("label_custom_button_prompt")}
                                            rows="2"
                                            style=${{background:"#222",border:"1px solid #444",color:"#fff",padding:"4px 8px",borderRadius:"4px",fontSize:"0.9em",resize:"vertical"}}
                                        ></textarea>
                                        <div style=${{display:"flex",gap:"8px",justifyContent:"flex-end"}}>
                                             <button 
                                                onClick=${()=>Y(null)} 
                                                style=${{padding:"4px 8px",background:"#444",border:"none",color:"#fff",borderRadius:"4px",cursor:"pointer",fontSize:"0.8em"}}
                                            >${n("button_cancel")}</button>
                                            <button 
                                                onClick=${ge} 
                                                style=${{padding:"4px 8px",background:"#00d1b2",border:"none",color:"#fff",borderRadius:"4px",cursor:"pointer",fontSize:"0.8em"}}
                                            >${n("button_save")}</button>
                                        </div>
                                    </div>
                                `:h`
                                    <div style=${{display:"flex",alignItems:"center",justifyContent:"space-between"}}>
                                        <label style=${{display:"flex",alignItems:"center",flex:1,cursor:"pointer",overflow:"hidden"}}>
                                            <input 
                                                type="checkbox" 
                                                checked=${o.isActive} 
                                                onChange=${()=>r(o.id)}
                                            />
                                            <span style=${{marginLeft:"8px",whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}} title=${o.prompt}>${o.label}</span>
                                        </label>
                                        <div style=${{display:"flex",gap:"4px"}}>
                                            <button 
                                                onClick=${()=>{Y(o.id),b(o.label),N(o.prompt)}} 
                                                style=${{background:"none",border:"none",color:"#888",cursor:"pointer",padding:"4px"}}
                                                title="Edit"
                                            >✎</button>
                                            <button 
                                                onClick=${()=>ie(o.id)} 
                                                style=${{background:"none",border:"none",color:"#ff4d4f",cursor:"pointer",padding:"4px"}}
                                                title="Delete"
                                            >✕</button>
                                        </div>
                                    </div>
                                `}
                            </div>
                        `)}
                    </div>
                </${s}>

                <${s} 
                    title=${h`<span>${n("section_light_painting")} <span style=${{color:"#ff4d4f",fontSize:"0.85em",marginLeft:"0.5rem"}}>${n("section_light_painting_note")}</span></span>`}
                    open=${d==="light_painting"}
                    onToggle=${o=>$("light_painting",o)}
                >
                    <div class="form-group">
                        <label>
                            <input
                                type="checkbox"
                                checked=${e.useRimLight}
                                onChange=${o=>{t(c=>({...c,useRimLight:o.currentTarget.checked}))}}
                            />
                            ${n("label_rim_light")}
                        </label>
                    </div>
                    <div class="form-group" style=${{marginTop:"0.5rem"}}>
                        <label>
                            <input
                                type="checkbox"
                                checked=${e.useGoldenHourBacklight}
                                onChange=${o=>{t(c=>({...c,useGoldenHourBacklight:o.currentTarget.checked}))}}
                            />
                            ${n("lighting_effect_backlight_golden_hour")}
                        </label>
                    </div>
                    ${e.useRimLight&&h`
                        <div style=${{display:"flex",gap:"1rem",marginTop:"0.5rem",paddingLeft:"1.5rem"}}>
                            <div class="form-group" style=${{flex:1}}>
                                <label style=${{fontSize:"0.85rem"}}>${n("label_direction")}</label>
                                <select 
                                    value=${e.rimLightDirection||"left"} 
                                    onChange=${o=>t(c=>({...c,rimLightDirection:o.currentTarget.value}))}
                                    style=${{padding:"0.25rem"}}
                                >
                                    <option value="left">${n("direction_left")}</option>
                                    <option value="right">${n("direction_right")}</option>
                                    <option value="top">${n("direction_top")}</option>
                                    <option value="bottom">${n("direction_bottom")}</option>
                                </select>
                            </div>
                            <div class="form-group" style=${{flex:1}}>
                                <label style=${{fontSize:"0.85rem"}}>${n("label_intensity")}</label>
                                <select 
                                    value=${e.rimLightIntensity||"medium"} 
                                    onChange=${o=>t(c=>({...c,rimLightIntensity:o.currentTarget.value}))}
                                    style=${{padding:"0.25rem"}}
                                >
                                    <option value="strong">${n("intensity_strong")}</option>
                                    <option value="medium">${n("intensity_medium")}</option>
                                    <option value="weak">${n("intensity_weak")}</option>
                                </select>
                            </div>
                        </div>
                    `}
                </${s}>

                <${s} 
                    title=${n("detail_ref_images")}
                    open=${d==="detail_ref"}
                    onToggle=${o=>$("detail_ref",o)}
                >
                    <div style=${{display:"flex",flexDirection:"column",gap:"10px"}}>
                        <p style=${{fontSize:"0.85em",color:"#888",margin:"0 0 5px 0",lineHeight:1.4}}>${n("detail_ref_help")}</p>
                        
                        <div style=${{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"8px"}}>
                            ${(e.detailReferences||[]).map((o,c)=>h`
                                <div style=${{background:"rgba(255,255,255,0.03)",borderRadius:"8px",padding:"8px",border:"1px solid rgba(255,255,255,0.1)",display:"flex",flexDirection:"column",gap:"6px"}}>
                                    <div style=${{position:"relative",width:"100%",paddingTop:"100%",borderRadius:"6px",overflow:"hidden",background:"#000"}}>
                                        <img src=${o.url} style=${{position:"absolute",top:0,left:0,width:"100%",height:"100%",objectFit:"cover"}} />
                                        
                                        <button 
                                            style=${{position:"absolute",top:"4px",right:"4px",background:"#ff4d4f",border:"none",borderRadius:"50%",width:"20px",height:"20px",display:"flex",alignItems:"center",justifyContent:"center",color:"#fff",fontSize:"10px",cursor:"pointer",boxShadow:"0 2px 5px rgba(0,0,0,0.5)",zIndex:2}}
                                            onClick=${()=>{const C=[...e.detailReferences||[]];C.splice(c,1),t(A=>({...A,detailReferences:C}))}}
                                            title="Xóa"
                                        >✕</button>

                                        <button 
                                            class="btn btn-secondary"
                                            style=${{position:"absolute",bottom:"6px",left:"50%",transform:"translateX(-50%)",padding:"0",width:"24px",height:"24px",fontSize:"12px",background:"rgba(0,0,0,0.6)",border:"1px solid rgba(255,255,255,0.3)",backdropFilter:"blur(4px)",borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",color:"#fff",zIndex:2,minHeight:"unset",boxShadow:"0 2px 4px rgba(0,0,0,0.3)"}}
                                            onClick=${()=>{I&&fetch(o.url).then(C=>C.blob()).then(C=>{const A=new File([C],"detail_ref.png",{type:"image/png"});I(A,c)})}}
                                            title=${n("detail_ref_crop")}
                                        >✂️</button>
                                    </div>
                                    
                                    <textarea 
                                        placeholder=${n("detail_ref_note_placeholder")}
                                        value=${o.note}
                                        onInput=${C=>{const A=[...e.detailReferences||[]];A[c]={...A[c],note:C.currentTarget.value},t(X=>({...X,detailReferences:A}))}}
                                        style=${{width:"100%",background:"rgba(0,0,0,0.2)",border:"1px solid rgba(255,255,255,0.05)",borderRadius:"4px",color:"#fff",fontSize:"11px",resize:"none",padding:"6px",height:"50px"}}
                                    ></textarea>
                                </div>
                            `)}
                        </div>

                        <input type="file" ref=${G} onChange=${o=>{var C;const c=(C=o.currentTarget.files)==null?void 0:C[0];c&&I&&I(c,-1),o.currentTarget&&(o.currentTarget.value="")}} accept="image/*" style=${{display:"none"}} />
                        
                        <button 
                            class="btn btn-secondary" 
                            style=${{width:"100%",border:"1px dashed #00d1b2",background:"rgba(0, 209, 178, 0.05)",color:"#00d1b2",padding:"12px",display:"flex",alignItems:"center",justifyContent:"center",gap:"8px",fontSize:"14px",fontWeight:500,height:"auto"}}
                            onClick=${()=>{var o;return(o=G.current)==null?void 0:o.click()}}
                        >
                            <span style=${{fontSize:"18px"}}>+</span> ${n("add_detail_ref")}
                        </button>
                    </div>
                </${s}>

                <${s} 
                    title=${n("options")} 
                    open=${d==="options"}
                    onToggle=${o=>$("options",o)}
                >
                    <div style=${{marginBottom:"10px",fontSize:"0.85em",color:"#ff9800",background:"rgba(255,152,0,0.1)",padding:"8px",borderRadius:"4px"}}>
                        ${n("note_ai_edit_composition")}
                    </div>
                    <div class="checkbox-group">
                        <label>
                            <input type="checkbox" checked=${e.keepPose} onChange=${o=>t(c=>({...c,keepPose:o.currentTarget.checked}))} />
                            ${n("checkbox_keep_pose")}
                        </label>
                        <label>
                            <input type="checkbox" checked=${e.keepComposition} onChange=${o=>t(c=>({...c,keepComposition:o.currentTarget.checked}))} />
                            ${n("checkbox_keep_composition")}
                        </label>
                        <label>
                            <input type="checkbox" checked=${e.keepFocalLength} onChange=${o=>t(c=>({...c,keepFocalLength:o.currentTarget.checked}))} />
                            ${n("checkbox_keep_focal_length")}
                        </label>
                        <label>
                            <input type="checkbox" checked=${e.keepAspectRatio} onChange=${o=>t(c=>({...c,keepAspectRatio:o.currentTarget.checked}))} />
                            ${n("checkbox_keep_aspect_ratio")}
                        </label>
                    </div>
                </${s}>



                <${s} 
                    title=${n("section_color_sync")} 
                    open=${d==="color_sync"}
                    onToggle=${o=>$("color_sync",o)}
                >
                    <div class="radio-group-vertical" style=${{display:"flex",flexDirection:"column",gap:"8px"}}>
                        <label style=${{display:"flex",alignItems:"center",gap:"8px",cursor:"pointer"}}>
                            <input type="radio" name="colorSync" checked=${!e.colorSyncMode||e.colorSyncMode==="none"} onChange=${()=>t(o=>({...o,colorSyncMode:"none"}))} />
                            ${n("option_none")}
                        </label>
                        <label style=${{display:"flex",alignItems:"center",gap:"8px",cursor:"pointer"}}>
                            <input type="radio" name="colorSync" checked=${e.colorSyncMode==="sync_character_scene"} onChange=${()=>t(o=>({...o,colorSyncMode:"sync_character_scene"}))} />
                            ${n("option_sync_character_scene")}
                        </label>
                        <label style=${{display:"flex",alignItems:"center",gap:"8px",cursor:"pointer"}}>
                            <input type="radio" name="colorSync" checked=${e.colorSyncMode==="ref_bg_follows_subject"} onChange=${()=>t(o=>({...o,colorSyncMode:"ref_bg_follows_subject"}))} />
                            ${n("option_ref_bg_follows_subject")}
                        </label>
                        <label style=${{display:"flex",alignItems:"center",gap:"8px",cursor:"pointer"}}>
                            <input type="radio" name="colorSync" checked=${e.colorSyncMode==="subject_follows_ref_bg"} onChange=${()=>t(o=>({...o,colorSyncMode:"subject_follows_ref_bg"}))} />
                            ${n("option_subject_follows_ref_bg")}
                        </label>
                    </div>
                </${s}>

                ${!g&&h`
                    <${s} 
                        title=${n("numberOfImages")} 
                        open=${d==="num_images"}
                        onToggle=${o=>$("num_images",o)}
                    >
                        <${pe}
                            value=${e.numImages}
                            options=${[1,2,3,4]}
                            onChange=${o=>t(c=>({...c,numImages:o}))}
                        />
                    </${s}>
                `}
            </div>
            

            <button class="btn btn-primary" onClick=${L} disabled=${f||!E||!e.prompt.trim()} style=${{width:"100%"}}>
                ${f?n("processing"):p||n("button_generate_photo_enter")}
            </button>
        </div>
    `},Yn=({settings:e,setSettings:t,onGenerate:L,generating:f,hasImage:E,onBackToHome:R,onChooseAnotherImage:T,t:n,language:a,isBatch:g=!1,buttonText:p,onLaunchDetailRefCrop:I,onLaunchAssistantCrop:P})=>{const[O,H]=K(!1),V=de(null),G=de(null),[d,_]=K(null),$=l=>{t(b=>({...b,prompt:l})),_(null)},v=he(()=>{if(!d)return{};const l=Rn[d]||{},b={};for(const B in l)b[B]=l[B];return b},[d,n]),[D,u]=K("ai_source"),k=(l,b)=>{b?u(l):D===l&&u("")},q=(l,b)=>{l.preventDefault(),l.stopPropagation(),H(b)},Y=l=>{var B;q(l,!1);const b=(B=l.dataTransfer)==null?void 0:B.files;b&&b.length>0&&P&&P(b[0])};return h`
        ${d&&h`
            <${gn}
                t=${n}
                category=${n(d==="male"?"gender_male":"gender_female")}
                suggestions=${v}
                onSelect=${$}
                onClose=${()=>_(null)}
            />
        `}
    <div class="settings-panel" >
        <button onClick=${R} class="back-button">${n("backButton")}</button>
            ${T&&h`<button class="btn btn-secondary" onClick=${T} style=${{width:"100%",marginBottom:"1rem"}}>${n("selectAnotherImage")}</button>`}
            
            <div style=${{flex:"1",overflowY:"auto",paddingRight:"0.5rem"}}>
                <${oe} 
                    settings=${e} 
                    setSettings=${t} 
                    t=${n} 
                    allowedModels=${["google_image_gen_banana_3","google_image_gen_banana_2","google_image_gen_banana_2_cheap","google_image_gen_banana_pro","google_image_gen_banana_pro_cheap","3.0-omni","google_image_gen_banana","o1","google_image_gen_banana_pro_reason","seedream_4_5"]}
                    open=${D==="ai_source"}
                    onToggle=${l=>k("ai_source",l)}
                />
                <${s} 
                    title=${n("section_ai_hair_analysis")}
                    open=${D==="ai_assistant"}
                    onToggle=${l=>k("ai_assistant",l)}
                >
                    <!-- <${$e}>${n("note_ai_assistant")}</${$e}> -->
                     <div 
                        class="reference-uploader ${O?"drag-over":""}" 
                        style=${{cursor:"pointer"}}
                        onDragOver=${l=>q(l,!0)}
                        onDragEnter=${l=>q(l,!0)}
                        onDragLeave=${l=>q(l,!1)}
                        onDrop=${Y}
                        onClick=${()=>{var l;return(l=G.current)==null?void 0:l.click()}}
                    >
                        <input 
                            type="file" 
                            ref=${G} 
                            style=${{display:"none"}} 
                            accept="image/*" 
                            onChange=${l=>{l.currentTarget.files&&l.currentTarget.files[0]&&P&&(P(l.currentTarget.files[0]),l.currentTarget.value="")}}
                        />
                        <div class="reference-placeholder" style=${{gap:"0.25rem"}}>
                            <${se} />
                            <span style=${{fontWeight:500}}>${n("uploader_drag_drop_prompt")}</span>
                            <span style=${{fontSize:"0.8em",opacity:.7}}>${n("uploader_drag_drop_note")}</span>
                        </div>
                    </div>
                </${s}>
                
                <${s} 
                    title=${n("section_edit_request")} 
                    open=${!0}
                >
                    <textarea 
                        class="form-group"
                        placeholder=${n("placeholder_ai_editor")}
                        value=${e.prompt}
                        onInput=${l=>t(b=>({...b,prompt:l.currentTarget.value}))}
                        rows="6"
                    ></textarea>
                </${s}>

                <${s} title=${n("section_hair_suggestions")}>
                    <div class="radio-group" style=${{marginBottom:"1rem"}}>
                        <label>
                            <input type="radio" name="gender" value="female" checked=${e.gender==="female"} onChange=${()=>t(l=>({...l,gender:"female"}))} />
                            ${n("gender_female")}
                        </label>
                        <label>
                            <input type="radio" name="gender" value="male" checked=${e.gender==="male"} onChange=${()=>t(l=>({...l,gender:"male"}))} />
                            ${n("gender_male")}
                        </label>
                    </div>
                    <button class="btn btn-secondary" style=${{width:"100%"}} onClick=${()=>_(e.gender||"female")}>
                        ${n("section_hair_suggestions")}...
                    </button>
                </${s}>

                <${s} 
                    title=${h`<span>${n("section_light_painting")} <span style=${{color:"#ff4d4f",fontSize:"0.85em",marginLeft:"0.5rem"}}>${n("section_light_painting_note")}</span></span>`}
                    open=${D==="light_painting"}
                    onToggle=${l=>k("light_painting",l)}
                >
                    <div class="form-group">
                        <label>
                            <input
                                type="checkbox"
                                checked=${e.useRimLight}
                                onChange=${l=>{t(b=>({...b,useRimLight:l.currentTarget.checked}))}}
                            />
                            ${n("label_rim_light")}
                        </label>
                    </div>
                    <div class="form-group" style=${{marginTop:"0.5rem"}}>
                        <label>
                            <input
                                type="checkbox"
                                checked=${e.useGoldenHourBacklight}
                                onChange=${l=>{t(b=>({...b,useGoldenHourBacklight:l.currentTarget.checked}))}}
                            />
                            ${n("lighting_effect_backlight_golden_hour")}
                        </label>
                    </div>
                    ${e.useRimLight&&h`
                        <div style=${{display:"flex",gap:"1rem",marginTop:"0.5rem",paddingLeft:"1.5rem"}}>
                            <div class="form-group" style=${{flex:1}}>
                                <label style=${{fontSize:"0.85rem"}}>${n("label_direction")}</label>
                                <select 
                                    value=${e.rimLightDirection||"left"} 
                                    onChange=${l=>t(b=>({...b,rimLightDirection:l.currentTarget.value}))}
                                    style=${{padding:"0.25rem"}}
                                >
                                    <option value="left">${n("direction_left")}</option>
                                    <option value="right">${n("direction_right")}</option>
                                    <option value="top">${n("direction_top")}</option>
                                    <option value="bottom">${n("direction_bottom")}</option>
                                </select>
                            </div>
                            <div class="form-group" style=${{flex:1}}>
                                <label style=${{fontSize:"0.85rem"}}>${n("label_intensity")}</label>
                                <select 
                                    value=${e.rimLightIntensity||"medium"} 
                                    onChange=${l=>t(b=>({...b,rimLightIntensity:l.currentTarget.value}))}
                                    style=${{padding:"0.25rem"}}
                                >
                                    <option value="strong">${n("intensity_strong")}</option>
                                    <option value="medium">${n("intensity_medium")}</option>
                                    <option value="weak">${n("intensity_weak")}</option>
                                </select>
                            </div>
                        </div>
                    `}
                </${s}>

                <${s} 
                    title=${n("detail_ref_images")}
                    open=${D==="detail_ref"}
                    onToggle=${l=>k("detail_ref",l)}
                >
                    <div style=${{display:"flex",flexDirection:"column",gap:"10px"}}>
                        <p style=${{fontSize:"0.85em",color:"#888",margin:"0 0 5px 0",lineHeight:1.4}}>${n("detail_ref_help")}</p>
                        
                        <div style=${{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"8px"}}>
                            ${(e.detailReferences||[]).map((l,b)=>h`
                                <div style=${{background:"rgba(255,255,255,0.03)",borderRadius:"8px",padding:"8px",border:"1px solid rgba(255,255,255,0.1)",display:"flex",flexDirection:"column",gap:"6px"}}>
                                    <div style=${{position:"relative",width:"100%",paddingTop:"100%",borderRadius:"6px",overflow:"hidden",background:"#000"}}>
                                        <img src=${l.url} style=${{position:"absolute",top:0,left:0,width:"100%",height:"100%",objectFit:"cover"}} />
                                        
                                        <button 
                                            style=${{position:"absolute",top:"4px",right:"4px",background:"#ff4d4f",border:"none",borderRadius:"50%",width:"20px",height:"20px",display:"flex",alignItems:"center",justifyContent:"center",color:"#fff",fontSize:"10px",cursor:"pointer",boxShadow:"0 2px 5px rgba(0,0,0,0.5)",zIndex:2}}
                                            onClick=${()=>{const B=[...e.detailReferences||[]];B.splice(b,1),t(N=>({...N,detailReferences:B}))}}
                                            title="Xóa"
                                        >✕</button>

                                        <button 
                                            class="btn btn-secondary"
                                            style=${{position:"absolute",bottom:"6px",left:"50%",transform:"translateX(-50%)",padding:"0",width:"24px",height:"24px",fontSize:"12px",background:"rgba(0,0,0,0.6)",border:"1px solid rgba(255,255,255,0.3)",backdropFilter:"blur(4px)",borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",color:"#fff",zIndex:2,minHeight:"unset",boxShadow:"0 2px 4px rgba(0,0,0,0.3)"}}
                                            onClick=${()=>{I&&fetch(l.url).then(B=>B.blob()).then(B=>{const N=new File([B],"detail_ref.png",{type:"image/png"});I(N,b)})}}
                                            title=${n("detail_ref_crop")}
                                        >✂️</button>
                                    </div>
                                    
                                    <textarea 
                                        placeholder=${n("detail_ref_note_placeholder")}
                                        value=${l.note}
                                        onInput=${B=>{const N=[...e.detailReferences||[]];N[b]={...N[b],note:B.currentTarget.value},t(ne=>({...ne,detailReferences:N}))}}
                                        style=${{width:"100%",background:"rgba(0,0,0,0.2)",border:"1px solid rgba(255,255,255,0.05)",borderRadius:"4px",color:"#fff",fontSize:"11px",resize:"none",padding:"6px",height:"50px"}}
                                    ></textarea>
                                </div>
                            `)}
                        </div>

                        <input type="file" ref=${V} onChange=${l=>{var B;const b=(B=l.currentTarget.files)==null?void 0:B[0];b&&I&&I(b,-1),l.currentTarget&&(l.currentTarget.value="")}} accept="image/*" style=${{display:"none"}} />
                        
                        <button 
                            class="btn btn-secondary" 
                            style=${{width:"100%",border:"1px dashed #00d1b2",background:"rgba(0, 209, 178, 0.05)",color:"#00d1b2",padding:"12px",display:"flex",alignItems:"center",justifyContent:"center",gap:"8px",fontSize:"14px",fontWeight:500,height:"auto"}}
                            onClick=${()=>{var l;return(l=V.current)==null?void 0:l.click()}}
                        >
                            <span style=${{fontSize:"18px"}}>+</span> ${n("add_detail_ref")}
                        </button>
                    </div>
                </${s}>

                <${s} 
                    title=${n("options")} 
                    open=${D==="options"}
                    onToggle=${l=>k("options",l)}
                >
                    <div style=${{marginBottom:"10px",fontSize:"0.85em",color:"#ff9800",background:"rgba(255,152,0,0.1)",padding:"8px",borderRadius:"4px"}}>
                        ${n("note_ai_edit_composition")}
                    </div>
                    <div class="checkbox-group">
                        <label>
                            <input type="checkbox" checked=${e.keepPose} onChange=${l=>t(b=>({...b,keepPose:l.currentTarget.checked}))} />
                            ${n("checkbox_keep_pose")}
                        </label>
                        <label>
                            <input type="checkbox" checked=${e.keepComposition} onChange=${l=>t(b=>({...b,keepComposition:l.currentTarget.checked}))} />
                            ${n("checkbox_keep_composition")}
                        </label>
                        <label>
                            <input type="checkbox" checked=${e.keepFocalLength} onChange=${l=>t(b=>({...b,keepFocalLength:l.currentTarget.checked}))} />
                            ${n("checkbox_keep_focal_length")}
                        </label>
                        <label>
                            <input type="checkbox" checked=${e.keepAspectRatio} onChange=${l=>t(b=>({...b,keepAspectRatio:l.currentTarget.checked}))} />
                            ${n("checkbox_keep_aspect_ratio")}
                        </label>
                    </div>
                </${s}>



                <${s} 
                    title=${n("section_color_sync")} 
                    open=${D==="color_sync"}
                    onToggle=${l=>k("color_sync",l)}
                >
                    <div class="radio-group-vertical" style=${{display:"flex",flexDirection:"column",gap:"8px"}}>
                        <label style=${{display:"flex",alignItems:"center",gap:"8px",cursor:"pointer"}}>
                            <input type="radio" name="colorSync" checked=${!e.colorSyncMode||e.colorSyncMode==="none"} onChange=${()=>t(l=>({...l,colorSyncMode:"none"}))} />
                            ${n("option_none")}
                        </label>
                        <label style=${{display:"flex",alignItems:"center",gap:"8px",cursor:"pointer"}}>
                            <input type="radio" name="colorSync" checked=${e.colorSyncMode==="sync_character_scene"} onChange=${()=>t(l=>({...l,colorSyncMode:"sync_character_scene"}))} />
                            ${n("option_sync_character_scene")}
                        </label>
                        <label style=${{display:"flex",alignItems:"center",gap:"8px",cursor:"pointer"}}>
                            <input type="radio" name="colorSync" checked=${e.colorSyncMode==="ref_bg_follows_subject"} onChange=${()=>t(l=>({...l,colorSyncMode:"ref_bg_follows_subject"}))} />
                            ${n("option_ref_bg_follows_subject")}
                        </label>
                        <label style=${{display:"flex",alignItems:"center",gap:"8px",cursor:"pointer"}}>
                            <input type="radio" name="colorSync" checked=${e.colorSyncMode==="subject_follows_ref_bg"} onChange=${()=>t(l=>({...l,colorSyncMode:"subject_follows_ref_bg"}))} />
                            ${n("option_subject_follows_ref_bg")}
                        </label>
                    </div>
                </${s}>

                ${!g&&h`
                    <${s} 
                        title=${n("numberOfImages")} 
                        open=${D==="num_images"}
                        onToggle=${l=>k("num_images",l)}
                    >
                        <${pe}
                            value=${e.numImages}
                            options=${[1,2,3,4]}
                            onChange=${l=>t(b=>({...b,numImages:l}))}
                        />
                    </${s}>
                `}
            </div>
            

            <button class="btn btn-primary" onClick=${L} disabled=${f||!E||!e.prompt.trim()} style=${{width:"100%"}}>
                ${f?n("processing"):p||n("button_generate_photo_enter")}
            </button>
        </div>
    `},Jn=({settings:e,setSettings:t,onGenerate:L,generating:f,hasImage:E,onBackToHome:R,onChooseAnotherImage:T,t:n})=>{const a={none:{labelKey:"option_none",prompt:""},pan_left:{labelKey:"camera_pan_left",prompt:"chuyển động máy quay lia chậm sang trái"},pan_right:{labelKey:"camera_pan_right",prompt:"chuyển động máy quay lia chậm sang phải"},zoom_in:{labelKey:"camera_zoom_in",prompt:"chuyển động máy quay zoom chậm vào"},zoom_out:{labelKey:"camera_zoom_out",prompt:"chuyển động máy quay zoom chậm ra"},tilt_up:{labelKey:"camera_tilt_up",prompt:"chuyển động máy quay ngước chậm lên"},dolly:{labelKey:"camera_dolly",prompt:"chuyển động máy quay đẩy chậm tới"}},g={none:{labelKey:"option_none",prompt:""},wind:{labelKey:"effect_wind",prompt:"với hiệu ứng gió nhẹ thổi"},sun:{labelKey:"effect_sun",prompt:"với hiệu ứng tia nắng điện ảnh"},rain:{labelKey:"effect_rain",prompt:"với hiệu ứng mưa rơi nhẹ"},snow:{labelKey:"effect_snow",prompt:"với hiệu ứng tuyết rơi nhẹ"},auto:{labelKey:"effect_auto",prompt:"với hiệu ứng môi trường tự động"}},p=P=>{t(O=>({...O,cameraMovement:P}))},I=P=>{t(O=>({...O,environmentEffect:P}))};return h`
    <div class="settings-panel" >
        <button onClick=${R} class="back-button">${n("backButton")}</button>
            ${T&&h`<button class="btn btn-secondary" onClick=${T} style=${{width:"100%",marginBottom:"1rem"}}>${n("selectAnotherImage")}</button>`}

            <div style=${{flex:"1",overflowY:"auto",paddingRight:"0.5rem"}}>
                <${oe} settings=${e} setSettings=${t} t=${n} allowedModels=${["veo_3_1","kling_video_gen_v1_5_pro","kling_video_gen_v1_5","kling_video_gen_v1_0","3.0-omni","minimax_video_gen_01","luma_dream_machine","runway_gen_3_alpha_turbo","runway_gen_3_alpha","runway_gen_2","cogvideox","haiper_video_v2","haiper_video_v1","svd_xt_1_1","pika_art"]} modelType="video" />
                
                <${s} title=${n("section_camera_movement")}>
                    <div class="radio-group">
                        ${Object.values(a).map(P=>h`
                            <label>
                                <input 
                                    type="radio" 
                                    name="camera-movement"
                                    checked=${e.cameraMovement===P.prompt}
                                    onChange=${()=>p(P.prompt)}
                                />
                                ${n(P.labelKey)}
                            </label>
                        `)}
                    </div>
                </${s}>
                
                <${s} title=${n("section_env_effects")}>
                    <div class="radio-group">
                        ${Object.values(g).map(P=>h`
                            <label>
                                <input 
                                    type="radio" 
                                    name="env-effect" 
                                    checked=${e.environmentEffect===P.prompt}
                                    onChange=${()=>I(P.prompt)}
                                />
                                ${n(P.labelKey)}
                            </label>
                        `)}
                    </div>
                </${s}>
            </div>

            <button class="btn btn-primary" onClick=${L} disabled=${f||!E} style=${{width:"100%",marginTop:"auto"}}>
                ${n(f?"creating_video":"create_video")}
            </button>
        </div>
    `},Qn=({settings:e,setSettings:t,onGenerate:L,generating:f,hasImage:E,buttonText:R,onBackToHome:T,onChooseAnotherImage:n,t:a})=>h`
        <div class="settings-panel">
            <button onClick=${T} class="back-button">${a("backButton")}</button>
            ${n&&h`<button class="btn btn-secondary" onClick=${n} style=${{width:"100%",marginBottom:"1rem"}}>${a("selectAnotherImage")}</button>`}

            <div style=${{flex:"1",overflowY:"auto",paddingRight:"0.5rem"}}>
                <${oe} settings=${e} setSettings=${t} t=${a} allowedModels=${["google_image_gen_banana_3","google_image_gen_banana_2","google_image_gen_banana_2_cheap","google_image_gen_banana_pro","google_image_gen_banana_pro_cheap","3.0-omni","google_image_gen_banana","o1","google_image_gen_banana_pro_reason","seedream_4_5"]} />
                
                <${s} title=${a("label_shot_type")} initialOpen=${!0}>
                    <div class="radio-group" style=${{display:"flex",flexDirection:"column",gap:"0.5rem"}}>
                        <label>
                            <input type="radio" name="shotType" value="wide" checked=${e.shotType==="wide"||!e.shotType} onChange=${()=>t(g=>({...g,shotType:"wide"}))} />
                            ${a("shot_wide")} <span style=${{color:"#ff4d4f",fontSize:"0.8rem",marginLeft:"0.4rem"}}>${a("shot_wide_note")}</span>
                        </label>
                        <label>
                            <input type="radio" name="shotType" value="full" checked=${e.shotType==="full"} onChange=${()=>t(g=>({...g,shotType:"full"}))} />
                            ${a("shot_full")} <span style=${{color:"#ff4d4f",fontSize:"0.8rem",marginLeft:"0.4rem"}}>${a("shot_full_note")}</span>
                        </label>
                        <label>
                            <input type="radio" name="shotType" value="half" checked=${e.shotType==="half"} onChange=${()=>t(g=>({...g,shotType:"half"}))} />
                            ${a("shot_half")} <span style=${{color:"#ff4d4f",fontSize:"0.8rem",marginLeft:"0.4rem"}}>${a("shot_half_note")}</span>
                        </label>
                        <label>
                            <input type="radio" name="shotType" value="closeup" checked=${e.shotType==="closeup"} onChange=${()=>t(g=>({...g,shotType:"closeup"}))} />
                            ${a("shot_closeup")} <span style=${{color:"#ff4d4f",fontSize:"0.8rem",marginLeft:"0.4rem"}}>${a("shot_closeup_note")}</span>
                        </label>
                    </div>
                </${s}>

                <${s} title=${a("section_your_prompt")} initialOpen=${!0}>
                    <textarea
                        id="creative-bg-prompt"
                        placeholder=${a("placeholder_bg_prompt")}
                        value=${e.prompt}
                        onInput=${g=>t(p=>({...p,prompt:g.currentTarget.value}))}
                        rows="8"
                    ></textarea>
                </${s}>

                <div class="form-group">
                    <label>${a("label_num_images")}</label>
                    <${pe}
                        value=${e.numImages}
                        options=${[1,2,3,4]}
                        onChange=${g=>t(p=>({...p,numImages:g}))}
                    />
                </div>
            </div>

            <button class="btn btn-primary" onClick=${L} disabled=${f||!E&&!e.prompt} style=${{width:"100%",marginTop:"auto"}}>
                ${f?a("processing"):R||a("button_creative_background")}
            </button>
        </div>
    `,ee=Ke.bind(Ce),Mn=e=>{var De;const{onBackToHome:t,initialFiles:L,t:f,language:E,setLanguage:R}=e,[T,n]=K([]),[a,g]=K({prompt:"",assistantImage:null,assistantPrompt:"",numImages:1,aiProvider:"haipix",haipixModel:"google_image_gen_banana_3",haipixMode:"vip1",haipixRatio:"auto",haipixResolution:"5k",keepPose:!0,keepComposition:!0,keepFocalLength:!0,keepAspectRatio:!0,useRimLight:!1,rimLightDirection:"left",rimLightIntensity:"medium",useGoldenHourBacklight:!1}),[p,I]=K(!1),[P,O]=K(0),[H,V]=K(0),[G,d]=K(0),[_,$]=K(""),[v,D]=K(!1),[u,k]=K(null),q=de(!1),[Y,l]=K(!0),[b,B]=K(!1),[N,ne]=K(!1),[ie,ge]=K(null),[r,m]=K(null),[w,o]=K(null),[c,C]=K(!1),[A,X]=K(200),[Z,Q]=K(null),[ae,ye]=K([]);le(()=>{hn("image").then(ye).catch(i=>console.error("Models fetch error",i))},[]);const fe=async(i,x,y)=>{if(!Z||Z.length===0)return;const S=[...Z];Q(null),$("");const M=new Set(S.map(W=>W.id));n(W=>W.map(F=>M.has(F.id)?{...F,status:"processing",processingPhase:"uploading",processingStartTime:Date.now()}:F)),S.forEach(async W=>{const F=W.id,j=W.generated||W.original;try{const U=await Cn(j),{url:J}=await xn(U,void 0,1e3),te=await wn(i,"upscale",void 0,void 0,void 0,x,y,void 0,xe=>{n(ue=>ue.map(we=>we.id===F?{...we,processingPhase:xe}:we))},J),ce=await Kn(te);n(xe=>xe.map(ue=>ue.id===F?{...ue,generated:te,status:"done",processingPhase:"done",width:ce.width,height:ce.height}:ue))}catch(U){const J=Te(U,f);$(J),n(te=>te.map(ce=>ce.id===F?{...ce,status:"error",error:J}:ce))}})},je=[{label:"Tự do",value:0},{label:"16:9",value:16/9},{label:"4:3",value:4/3},{label:"1:1",value:1},{label:"3:4",value:3/4},{label:"9:16",value:9/16}],Ae=Se((i,x=-1)=>{const y=new FileReader;y.onload=S=>{ge(S.target.result),m(x),ne(!0)},y.readAsDataURL(i)},[]),Fe=i=>{g(x=>{const y=[...x.detailReferences||[]];return r===-1?y.push({id:Date.now().toString(),url:i,note:""}):r!==null&&r>=0&&(y[r].url=i),{...x,detailReferences:y}}),ne(!1),ge(null),m(null)},Ue=()=>{ne(!1),ge(null),m(null)},Ne=i=>{w!==null&&(n(x=>x.map(y=>y.id===w?{...y,original:i}:y)),o(null))};le(()=>{const i=x=>{if(x.key==="*"){const y=x.target;["INPUT","TEXTAREA","SELECT"].includes(y.tagName)||(x.preventDefault(),l(S=>!S))}};return window.addEventListener("keydown",i),()=>window.removeEventListener("keydown",i)},[]),le(()=>{L&&L.length>0&&!q.current&&(q.current=!0,ve(L))},[L]),le(()=>{const i=async x=>{var W;const y=x.target;if(["INPUT","TEXTAREA","SELECT"].includes(y.tagName))return;const S=(W=x.clipboardData)==null?void 0:W.items;if(!S)return;const M=[];for(let F=0;F<S.length;F++){const j=S[F];if(j.type.startsWith("image/")){const U=j.getAsFile();U&&M.push(U)}}if(M.length>0){x.preventDefault();const F=M.map(j=>({id:Date.now()+Math.random(),file:j,original:URL.createObjectURL(j),generated:null,status:"pending",selected:!0}));n(j=>[...j,...F])}};return document.addEventListener("paste",i),()=>document.removeEventListener("paste",i)},[]);const Re=i=>new Promise((x,y)=>{const S=new FileReader;S.onload=()=>x(S.result),S.onerror=()=>y(new Error(`Lỗi đọc file: ${i.name}`)),S.readAsDataURL(i)}),ve=i=>{if(!i)return;const x=Array.from(i).map(y=>({id:Date.now()+Math.random(),file:y,original:URL.createObjectURL(y),generated:null,status:"pending",selected:!0}));n(y=>[...y,...x])},We=async(i,x,y)=>{let S=0;d(i.length),V(0);const M=[...i],W=async()=>{for(;M.length>0;){const F=M.shift();F&&(await y(F),S++,V(j=>j+1),O(Math.round(S/i.length*100)),M.length>0&&await new Promise(j=>setTimeout(j,2e3)))}};await Promise.all(Array(x).fill(null).map(()=>W()))},Ge=Se(async()=>{I(!0),O(0),$("");const i=T.filter(y=>y.selected&&(y.status==="pending"||y.status==="error"));d(i.length);const x=async y=>{n(S=>S.map(M=>M.id===y.id?{...M,status:"processing",processingStartTime:Date.now(),processingPhase:"uploading"}:M));try{const S=y.original.startsWith("data:")?y.original:await Re(y.file),{numImages:M,...W}=a,F={...W,hasPaintedMask:y.original.startsWith("data:")},j=await Le(S,F,U=>{n(J=>J.map(te=>te.id===y.id?{...te,processingPhase:U}:te))});n(U=>U.map(J=>J.id===y.id?{...J,generated:j,status:"done",processingPhase:"done"}:J))}catch(S){throw $(Te(S,f)),console.error(`Error processing image ${y.id}:`,S),n(M=>M.map(W=>W.id===y.id?{...W,status:"error"}:W)),S}};try{await We(i,1,x)}catch(y){console.error(f("batch_processing_stopped"),y)}finally{I(!1)}},[T,a,f]),qe=async i=>{const x=T.find(y=>y.id===i);if(x){n(y=>y.map(S=>S.id===i?{...S,status:"processing",generated:null,processingStartTime:Date.now(),processingPhase:"uploading"}:S)),$("");try{const y=x.original.startsWith("data:")?x.original:await Re(x.file),{numImages:S,...M}=a,W={...M,hasPaintedMask:x.original.startsWith("data:")},F=await Le(y,W,j=>{n(U=>U.map(J=>J.id===i?{...J,processingPhase:j}:J))});n(j=>j.map(U=>U.id===i?{...U,generated:F,status:"done",processingPhase:"done"}:U))}catch(y){$(Te(y,f)),n(S=>S.map(M=>M.id===i?{...M,status:"error"}:M))}}},He=i=>n(x=>x.filter(y=>y.id!==i)),Ve=i=>n(x=>x.map(y=>y.id===i?{...y,selected:!y.selected}:y)),Ye=()=>n(i=>i.map(x=>({...x,selected:!0}))),Je=()=>n(i=>i.map(x=>({...x,selected:!1}))),Qe=i=>{ve(i.currentTarget.files),i.currentTarget.value=""},be=(i,x)=>{i.preventDefault(),i.stopPropagation(),D(x)},Xe=i=>{var x;be(i,!1),ve(((x=i.dataTransfer)==null?void 0:x.files)||null)},Ze=async i=>{i.preventDefault(),i.stopPropagation();const x=T.filter(y=>y.selected&&y.generated);if(x.length!==0){B(!0);try{const{default:y}=await Bn(async()=>{const{default:U}=await import("https://cdn.jsdelivr.net/npm/jszip@3.10.1/+esm");return{default:U}},[]),S=new y;let M=0;for(let U=0;U<x.length;U++){const J=x[U];if(J.generated)try{const te=await kn(J.generated),ce=`${String(U+1).padStart(3,"0")}_${J.file.name.split(".")[0]}-posing.png`;S.file(ce,te),M++}catch(te){console.error("Error fetching image for zip:",te)}}if(M===0)throw new Error("Không thể tải được ảnh nào do lỗi kết nối hoặc CORS.");const W=await S.generateAsync({type:"blob"}),F=URL.createObjectURL(W),j=document.createElement("a");j.href=F,j.download=`ai-edited-${new Date().toISOString().slice(0,10)}.zip`,document.body.appendChild(j),j.click(),document.body.removeChild(j),URL.revokeObjectURL(F)}catch(y){console.error("Error creating zip:",y),alert("Lỗi khi tải xuống: "+y.message+`

Giải pháp: Bấm vào từng ảnh để xem to rồi chuột phải chọn "Lưu hình ảnh thành..."`)}finally{B(!1)}}},ke=he(()=>T.filter(i=>i.selected&&(i.status==="pending"||i.status==="error")).length,[T]),en=ke>0?f("button_ai_edit_batch",{count:String(ke)}):f("button_select_to_ai_edit");return ee`
        ${u&&u.generated&&ee`
            <${bn}
                t=${f}
                originalUrl=${u.original}
                generatedUrl=${u.generated}
                onClose=${()=>k(null)}
                caption=${f("detailedComparison")}
                toggleView=${!0}
            />
        `}
        ${c&&ee`
            <div class="modal-overlay" onClick=${()=>C(!1)} style=${{position:"fixed",top:0,left:0,right:0,bottom:0,background:"rgba(0,0,0,0.85)",zIndex:9999,display:"flex",alignItems:"center",justifyContent:"center",padding:"1rem"}}>
                <div class="modal-content" onClick=${i=>i.stopPropagation()} style=${{background:"var(--card-bg)",borderRadius:"16px",maxWidth:"700px",width:"100%",maxHeight:"90vh",overflowY:"auto",padding:"2rem",border:"1px solid var(--border-color)",boxShadow:"0 20px 60px rgba(0,0,0,0.5)"}}>
                    <div style=${{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"1.5rem"}}>
                        <h2 style=${{margin:0,fontSize:"1.5rem",background:"linear-gradient(90deg, #4dabf7, #9775fa)",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"}}>Hướng Dẫn Sử Dụng</h2>
                        <button onClick=${()=>C(!1)} style=${{background:"none",border:"none",fontSize:"1.5rem",cursor:"pointer",color:"var(--text-color)",opacity:.7}}>✕</button>
                    </div>
                    
                    <div style=${{marginBottom:"2rem",padding:"1.5rem",background:"linear-gradient(135deg, rgba(255,193,7,0.15), rgba(255,87,34,0.1))",borderRadius:"12px",border:"2px solid rgba(255,193,7,0.3)"}}>
                        <div style=${{display:"flex",alignItems:"center",gap:"10px",marginBottom:"1rem"}}>
                            <span style=${{background:"linear-gradient(90deg, #ff6b6b, #ffa502)",color:"white",padding:"4px 10px",borderRadius:"20px",fontSize:"0.75rem",fontWeight:"bold"}}>MỚI</span>
                            <h3 style=${{margin:0,fontSize:"1.2rem",color:"#ffc107"}}>☀️ Ánh Sáng Pro</h3>
                        </div>
                        <p style=${{margin:"0 0 1rem 0",lineHeight:1.7,opacity:.9}}><strong>Mục đích:</strong> Tạo hiệu ứng ánh sáng nghệ thuật cho ảnh chân dung.</p>
                        <ul style=${{margin:0,paddingLeft:"1.5rem",lineHeight:2}}>
                            <li><strong>Ánh sáng viền (Rim Light):</strong> Tạo viền sáng xung quanh chủ thể, làm nổi bật đường nét. Chọn hướng (trái/phải/sau) và cường độ (nhẹ/vừa/mạnh).</li>
                            <li><strong>Ánh nắng hoàng hôn (Golden Hour):</strong> Thêm ánh nắng vàng ấm áp từ phía sau.</li>
                        </ul>
                    </div>
                    
                    <div style=${{marginBottom:"2rem",padding:"1.5rem",background:"linear-gradient(135deg, rgba(77,171,247,0.15), rgba(151,117,250,0.1))",borderRadius:"12px",border:"2px solid rgba(77,171,247,0.3)"}}>
                        <div style=${{display:"flex",alignItems:"center",gap:"10px",marginBottom:"1rem"}}>
                            <span style=${{background:"linear-gradient(90deg, #4dabf7, #9775fa)",color:"white",padding:"4px 10px",borderRadius:"20px",fontSize:"0.75rem",fontWeight:"bold"}}>MỚI</span>
                            <h3 style=${{margin:0,fontSize:"1.2rem",color:"#4dabf7"}}>🖌️ Bút Vẽ (Drawing Tool)</h3>
                        </div>
                        <p style=${{margin:"0 0 1rem 0",lineHeight:1.7,opacity:.9}}><strong>Mục đích:</strong> Vẽ/tô trực tiếp lên ảnh để chỉ định vùng cần AI chỉnh sửa.</p>
                        <ul style=${{margin:0,paddingLeft:"1.5rem",lineHeight:2}}>
                            <li><strong>Cách sử dụng:</strong> Nhấn vào biểu tượng cọ vẽ (brush icon) dưới mỗi ảnh trong lưới.</li>
                            <li><strong>Màu vẽ:</strong> Chọn màu xanh hoặc đỏ để tô lên vùng bạn muốn AI thay đổi.</li>
                            <li><strong>Kết hợp với prompt:</strong> Viết mô tả trong ô "Yêu cầu chỉnh sửa" để AI hiểu bạn muốn thay đổi gì ở vùng đã tô.</li>
                        </ul>
                        <p style=${{margin:"1rem 0 0 0",padding:"10px",background:"rgba(0,0,0,0.2)",borderRadius:"8px",fontSize:"0.9rem"}}>Ví dụ: Tô đỏ lên vùng áo + viết "thay bằng áo vest đen" → AI sẽ chỉ thay đổi vùng áo bạn đã tô.</p>
                    </div>
                    
                    <div style=${{padding:"1rem",background:"rgba(255,255,255,0.05)",borderRadius:"8px"}}>
                        <h4 style=${{margin:"0 0 0.5rem 0"}}>📋 Các bước sử dụng tổng quát:</h4>
                        <ol style=${{margin:0,paddingLeft:"1.5rem",lineHeight:2}}>
                            <li>Tải ảnh lên bằng nút "Thêm ảnh" hoặc kéo thả.</li>
                            <li>(Tùy chọn) Sử dụng Bút Vẽ để đánh dấu vùng cần sửa.</li>
                            <li>(Tùy chọn) Bật Ánh sáng Pro nếu muốn thêm hiệu ứng ánh sáng.</li>
                            <li>Nhập mô tả chỉnh sửa vào ô "Yêu cầu chỉnh sửa của bạn".</li>
                            <li>Chọn Model và Mode phù hợp.</li>
                            <li>Nhấn "Sửa ảnh AI" để bắt đầu.</li>
                        </ol>
                    </div>
                    
                    <button onClick=${()=>C(!1)} style=${{width:"100%",marginTop:"1.5rem",padding:"12px",background:"linear-gradient(90deg, #4dabf7, #9775fa)",border:"none",borderRadius:"8px",color:"white",fontWeight:"bold",cursor:"pointer",fontSize:"1rem"}}>Đã hiểu, Đóng</button>
                </div>
            </div>
        `}
        <div class="editor-layout batch-background-view ${Y?"":"panel-hidden"}">
             <div class="image-panel droppable ${v?"drag-over":""}" onDragOver=${i=>be(i,!0)} onDragEnter=${i=>be(i,!0)} onDragLeave=${i=>be(i,!1)} onDrop=${Xe}>
                <div style=${{width:"100%",display:"flex",flexDirection:"column",height:"100%",padding:"1.5rem"}}>
                    <div class="actions" style=${{position:"relative",bottom:"auto",right:"auto",justifyContent:"space-between",marginBottom:"1rem",flexWrap:"wrap",gap:"0.5rem"}}>
                        <div style=${{display:"flex",gap:"0.5rem"}}>
                            <button class="btn" onClick=${()=>{var i;return(i=document.getElementById("batch-ai-edit-file-input"))==null?void 0:i.click()}}><${se} /> ${f("add_images")}</button>
                            <button class="btn btn-secondary" onClick=${Ye}>${f("select_all")}</button>
                            <button class="btn btn-secondary" onClick=${Je}>${f("deselect_all")}</button>
                        </div>
                        <input type="file" id="batch-ai-edit-file-input" multiple accept="image/*" style=${{display:"none"}} onChange=${Qe} />
                        <div style=${{display:"flex",gap:"5px"}}>
                             <button type="button" class="btn" onClick=${()=>C(!0)} style=${{border:"2px solid #ff4d4f",color:"#ff4d4f",fontWeight:"bold"}}>Hướng Dẫn</button>
                             <button
                                type="button"
                                class="btn btn-secondary"
                                onClick=${()=>{const i=T.filter(x=>x.selected);i.length>0?Q(i):alert(f("button_select_to_ai_edit"))}}
                                disabled=${T.filter(i=>i.selected).length===0}
                                title=${f("label_upscale")}
                             >
                                <${ze} /> ${f("label_upscale")}
                             </button>
                             <button type="button" class="btn btn-primary" onClick=${i=>{i.preventDefault(),i.stopPropagation(),Ze(i)}} disabled=${b||T.filter(i=>i.selected&&i.generated).length===0}><${mn} /> ${f(b?"zipping":"download_all")}</button>
                        </div>
                    </div>
                    ${p&&ee`<div class="progress-container"><div class="progress-bar"><div class="progress-bar-inner" style=${{width:`${P}%`}}></div><span class="progress-label">${P}%</span></div><span class="progress-counter">${H} / ${G}</span></div>`}
                    ${_&&ee`<div class="error-message" style=${{marginTop:"1rem"}}>${_}</div>`}
                    <div style=${{display:"flex",justifyContent:"flex-end",alignItems:"center",gap:"8px",marginBottom:"8px"}}>
                        <span style=${{fontSize:"11px",opacity:.7}}>📷</span>
                        <input 
                            type="range" 
                            min="100" 
                            max="500" 
                            value=${A} 
                            onInput=${i=>X(parseInt(i.target.value))}
                            style=${{width:"120px",cursor:"pointer"}}
                            title=${`Kích thước ảnh: ${A}px`}
                        />
                        <span style=${{fontSize:"11px",opacity:.7}}>🖼️</span>
                        <span style=${{fontSize:"10px",opacity:.6,minWidth:"40px"}}>${A}px</span>
                    </div>
                    <div class="batch-grid" style=${{flex:1,overflowY:"auto",alignContent:"flex-start",gridTemplateColumns:`repeat(auto-fill, minmax(${A}px, 1fr))`}}>
                        ${T.length===0?ee`
                            <div class="upload-placeholder" onClick=${()=>{var i;return(i=document.getElementById("batch-ai-edit-file-input"))==null?void 0:i.click()}} style=${{gridColumn:"1 / -1",height:"100%",minHeight:"400px",alignSelf:"stretch"}}>
                                <${se} /><strong>${f("upload_multiple_prompt_title")}</strong>
                                <p style=${{opacity:.7,fontSize:"0.85em",marginTop:"0.5rem"}}>${f("upload_multiple_prompt_note")}</p>
                                <p style=${{opacity:.55,fontSize:"0.8em"}}>${f("upload_ai_edit_prompt")}</p>
                            </div>`:T.map(i=>ee`
                            <div class="batch-item ${i.selected?"selected":""} ${i.generated?"has-generated":""} ${i.status==="error"?"error":""}">
                                <div class="selection-checkbox" onClick=${()=>Ve(i.id)}><div class="checkbox-visual"><${Be} /></div></div>
                                <div class="image-comparator" style=${{display:"block"}} onClick=${()=>i.generated&&k(i)}>
                                    <div class="image-container ${i.generated?"has-result":""}">
                                        <img src=${i.generated||i.original} onMouseEnter=${x=>{i.generated&&(x.target.src=i.original)}} onMouseLeave=${x=>{i.generated&&(x.target.src=i.generated)}} />
                                        ${i.status==="processing"&&ee`<${En} startTime=${i.processingStartTime} phase=${i.processingPhase} t=${f} />`}
                                        ${i.status==="done"&&ee`<div class="batch-item-status-icon"><${Be} /></div>`}
                                        ${i.status==="error"&&ee`<div class="error-badge" title="${i.error||f("error")}" onClick=${x=>{x.stopPropagation(),alert(i.error||f("error"))}}>${f("error")}</div>`}
                                    </div>
                                </div>
                                <div class="batch-item-actions">
                                    <button class="batch-item-btn" title="Bút Vẽ" onClick=${x=>{x.stopPropagation(),o(i.id)}}><${_n} /></button>
                                    <button class="batch-item-btn" title=${f("regenerate")} onClick=${()=>qe(i.id)}><${$n} /></button>
                                    <button class="batch-item-btn" title="Nâng cao chất lượng (Upscale)" onClick=${()=>Q([i])}><${ze} /></button>
                                    <button class="batch-item-btn" title=${f("delete")} onClick=${()=>He(i.id)}><${yn} /></button>
                                </div>
                            </div>`)}
                    </div>
                    <${me} t=${f} style=${{marginTop:"0.5rem",marginBottom:"0.5rem",fontSize:"10px",padding:"2px 8px",width:"fit-content",margin:"0 auto",opacity:.7,borderRadius:"4px",display:"flex",gap:"5px",flexWrap:"wrap",justifyContent:"center"}} />
                </div>
            </div>
            <${On} 
                settings=${a} 
                setSettings=${g} 
                onGenerate=${Ge} 
                generating=${p} 
                hasImage=${ke>0} 
                buttonText=${en} 
                isBatch=${!0} 
                onBackToHome=${t} 
                onChooseAnotherImage=${()=>{var i;return(i=document.getElementById("batch-ai-edit-file-input"))==null?void 0:i.click()}} 
                t=${f} 
                language=${E} 
                setLanguage=${R}
                onLaunchDetailRefCrop=${Ae}
            />
            ${w!==null&&ee`
                <${fn}
                    t=${f}
                    imageUrl=${((De=T.find(i=>i.id===w))==null?void 0:De.original)||""}
                    onSave=${Ne}
                    onCancel=${()=>o(null)}
                />
            `}
            ${N&&ie&&ee`
                <${vn} 
                    t=${f}
                    imageUrl=${ie} 
                    onCrop=${Fe}
                    onCancel=${Ue}
                    aspectRatios=${je}
                    warning=${`1. crop cận nguyên vật thể cần tham chiếu
2. nếu sử dụng quá nhiều tham chiếu có thể gây biến dị cho người mẫu
Chú ý: 1 công cụ sáng tạo mới đa nhiệp vụ hãy cùng sáng tạo tùy biến`}
                />
            `}
            ${Z&&ee`
                <${Tn}
                    targetImages=${Z.map(i=>({id:i.id,url:i.generated||i.original}))}
                    models=${ae}
                    onClose=${()=>Q(null)}
                    onConfirm=${fe}
                    t=${f}
                />
            `}
        </div>
    `},Xn=Object.freeze(Object.defineProperty({__proto__:null,default:Mn},Symbol.toStringTag,{value:"Module"}));export{Hn as B,qn as C,Yn as H,In as I,En as P,Wn as R,Un as T,Jn as V,Bn as _,Gn as a,Qn as b,Nn as c,Vn as d,Xn as e};
