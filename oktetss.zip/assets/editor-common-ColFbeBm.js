import{k as qe,m as Ie,e as Ne,E as Xe,L as Qe,$ as Ye,s as Ce,a0 as Ze,a1 as Je,a2 as et,a3 as tt,a4 as nt,n as De,T as it,D as st,a5 as at,a6 as ot,M as rt,Z as lt,h as ct,u as dt,v as gt}from"./editor-MotionEditor-B8LJN4fm.js";import{P as pt}from"./editor-aiEditor-Dm1L4C_K.js";import{d as o,y as I,A as Se,q as ke,_ as ut}from"./vendor-bdgQI7wY.js";const i=ct.bind(ut),bt=(r,u)=>{if(!r||!u)return"";const d=Math.max(r,u);return d>=12e3?"12K":d>=1e4?"10K":d>=7680?"8K":d>=6e3?"6K":d>=3840?"4K":d>=2560||d>=1920?"2K":d>=1200?"1K":"SD"},ft=({src:r})=>{const[u,d]=o(null);return I(()=>{if(!r)return;const s=new Image;return s.onload=()=>{d({width:s.naturalWidth,height:s.naturalHeight})},s.src=r,()=>{s.onload=null}},[r]),u?i`<span>${u.width} x ${u.height}</span>`:null},yt=({generated:r,originalFileSize:u})=>{const[d,s]=o(null);I(()=>{if(!r){s(null);return}if(r.startsWith("data:")){const l=r.split(",")[1]||"",b=l.length*3/4,D=(l.match(/=+$/)||[""])[0].length,C=b-D;s(C)}else r.startsWith("blob:")||r.startsWith("http")?fetch(lt(r)).then(l=>l.blob()).then(l=>{s(l.size)}).catch(()=>{s(null)}):s(null)},[r]);const h=r&&d!==null?(d/(1024*1024)).toFixed(2):(u/(1024*1024)).toFixed(2);return i`
        <div class="image-size-badge" style=${{position:"absolute",bottom:"5px",right:"5px",background:"rgba(0,0,0,0.7)",color:"white",padding:"3px 8px",borderRadius:"4px",fontSize:"0.7em",pointerEvents:"none",display:"flex",flexDirection:"column",alignItems:"flex-end",gap:"2px",backdropFilter:"blur(4px)"}}>
            <span>${h} MB</span>
            ${r&&i`
                <${ft} src=${r} />
            `}
        </div>
    `},wt=r=>new Promise((u,d)=>{const s=new Image;s.onload=()=>u({width:s.naturalWidth,height:s.naturalHeight}),s.onerror=d,s.src=r}),It=()=>i`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" /></svg>`,Ct=`Giữ nguyên khuôn mặt, mắt, mũi, miệng và các chi tiết da gốc một cách chính xác.
Giữ nguyên hình dáng tóc, đường chân tóc và kiểu tóc ban đầu mà không có bất kỳ thay đổi nào.
Duy trì bố cục, khung hình, góc máy, vị trí, kích thước và góc nhìn của chủ thể ban đầu.`,$t=({onClose:r,onCancel:u,onConfirm:d,models:s,targetImages:h,t:l})=>{var B,K;const[b,D]=o("professional"),[C,A]=o("4k"),[F,V]=o(!0),[v,G]=o(null),R=r||u||(()=>{});I(()=>{const t=s.find(m=>m.model==="generative_upscale_v2")||s.find(m=>m.model.includes("upscale"));if(t){G(t);const m=t.mode||t.modes||[];if(m.length>0){const y=m.find(c=>c.type==="professional");D(y?"professional":m[0].type)}const p=t.resolutions||[];if(p.length>0){const y=p.find(c=>c.type==="4k");A(y?"4k":p[0].type)}}V(!1)},[s]);const T=v?v.mode||v.modes||[]:[],O=v?v.resolutions||[]:[];let _=0;if(v&&v.prices){const t=v.prices.find(m=>m.mode===b&&m.resolution===C);if(t)_=t.price;else{const m=T.find(p=>p.type===b);m&&(_=m.price||0)}}const a=h.length,se=_*a;return i`
        <div class="modal-overlay" style=${{position:"fixed",top:0,left:0,right:0,bottom:0,background:"rgba(0,0,0,0.8)",backdropFilter:"blur(8px)",zIndex:10005,display:"flex",alignItems:"center",justifyContent:"center",padding:"20px"}} onClick=${R}>
            <div class="glass-modal" style=${{background:"rgba(30, 30, 40, 0.85)",backdropFilter:"blur(20px) saturate(180%)",padding:"32px",borderRadius:"24px",width:"480px",maxWidth:"100%",border:"1px solid rgba(255, 255, 255, 0.1)",display:"flex",flexDirection:"column",gap:"24px",boxShadow:"0 25px 50px -12px rgba(0, 0, 0, 0.5)",boxSizing:"border-box"}} onClick=${t=>t.stopPropagation()}>
                
                <div style=${{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                    <h3 style=${{margin:0,color:"#fff",fontSize:"22px",fontWeight:"700",letterSpacing:"-0.5px"}}>${l("upscale_title")}</h3>
                    <button onClick=${R} style=${{background:"rgba(255,255,255,0.05)",border:"none",color:"#888",borderRadius:"50%",width:"32px",height:"32px",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}>✕</button>
                </div>
                
                ${F?i`<div style=${{padding:"40px",textAlign:"center",color:"#888"}}><div class="spinner" style=${{margin:"0 auto 15px"}}></div>${l("upscale_loading_options")}</div>`:v?i`
                    <div style=${{display:"flex",flexDirection:"column",gap:"20px"}}>
                        
                        <div style=${{display:"flex",alignItems:"center",gap:"12px",background:"rgba(255,255,255,0.05)",padding:"12px 16px",borderRadius:"16px",border:"1px solid rgba(255,255,255,0.05)"}}>
                            <div style=${{width:"40px",height:"40px",background:"var(--accent)",borderRadius:"12px",display:"flex",alignItems:"center",justifyContent:"center"}}><${De} style=${{width:"20px",height:"20px",color:"white"}} /></div>
                            <div>
                                <div style=${{fontSize:"15px",color:"#fff",fontWeight:"600"}}>${l("upscale_images_selected",{count:a.toString()})}</div>
                                <div style=${{fontSize:"12px",color:"#888"}}>${l("model_label")}: ${v.name||"Generative Upscale V2"}</div>
                            </div>
                        </div>

                        <div style=${{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"15px"}}>
                            <div style=${{display:"flex",flexDirection:"column",gap:"8px"}}>
                                <label style=${{color:"#888",fontSize:"11px",fontWeight:"700",textTransform:"uppercase",letterSpacing:"0.5px"}}>${l("upscale_mode")}</label>
                                <select 
                                    style=${{background:"rgba(0,0,0,0.3)",color:"#fff",border:"1px solid rgba(255,255,255,0.1)",padding:"12px",borderRadius:"12px",fontSize:"14px",outline:"none",cursor:"pointer"}}
                                    value=${b}
                                    onChange=${t=>D(t.currentTarget.value)}
                                >
                                    ${T.map(t=>i`<option value=${t.type}>${t.name}</option>`)}
                                </select>
                            </div>

                            <div style=${{display:"flex",flexDirection:"column",gap:"8px"}}>
                                <label style=${{color:"#888",fontSize:"11px",fontWeight:"700",textTransform:"uppercase",letterSpacing:"0.5px"}}>${l("upscale_resolution")}</label>
                                <select 
                                    style=${{background:"rgba(0,0,0,0.3)",color:"#fff",border:"1px solid rgba(255,255,255,0.1)",padding:"12px",borderRadius:"12px",fontSize:"14px",outline:"none",cursor:"pointer"}}
                                    value=${C}
                                    onChange=${t=>A(t.currentTarget.value)}
                                >
                                    ${O.map(t=>i`<option value=${t.type}>${t.name}</option>`)}
                                </select>
                            </div>
                        </div>

                        ${((B=T.find(t=>t.type===b))==null?void 0:B.description)&&i`
                            <div style=${{fontSize:"13px",color:"#aaa",lineHeight:"1.5",padding:"12px",background:"rgba(255,255,255,0.03)",borderRadius:"12px",borderLeft:"3px solid var(--accent)"}}>
                                ${(K=T.find(t=>t.type===b))==null?void 0:K.description}
                            </div>
                        `}
                        
                        <div style=${{fontSize:"12px",color:"#ffa94d",background:"rgba(255,169,77,0.1)",padding:"12px",borderRadius:"12px",border:"1px solid rgba(255,169,77,0.2)",display:"flex",gap:"10px"}}>
                            <span style=${{fontSize:"16px"}}>⚠️</span> <span>${l("upscale_warning_message")}</span>
                        </div>
                    </div>

                    <div style=${{display:"flex",flexDirection:"column",gap:"16px",marginTop:"12px"}}>
                        <div style=${{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"0 4px"}}>
                            <div style=${{color:"#888",fontSize:"14px"}}>${l("upscale_price_per_image")}</div>
                            <div style=${{color:"#fff",fontWeight:"700",fontSize:"16px"}}>${_} ${l("credits_suffix")}</div>
                        </div>
                        <div style=${{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"16px",background:"rgba(255,255,255,0.05)",borderRadius:"16px",border:"1px solid rgba(255,255,255,0.1)"}}>
                            <div style=${{color:"#fff",fontWeight:"600",fontSize:"15px"}}>${l("upscale_total_estimate")}</div>
                            <div style=${{color:"var(--accent)",fontWeight:"800",fontSize:"20px"}}>${se} ${l("credits_suffix")}</div>
                        </div>
                        <button 
                            class="btn-primary" 
                            style=${{padding:"16px",borderRadius:"16px",fontSize:"16px",fontWeight:"700",marginTop:"8px"}}
                            onClick=${()=>d(v.model,b,C)}
                        >
                            ${l("upscale_confirm_button")}
                        </button>
                    </div>
                `:i`<div style=${{padding:"40px",textAlign:"center",color:"#ef4444"}}>${l("upscale_model_not_found")}</div>`}
            </div>
        </div>
    `},mt=r=>new Promise((u,d)=>{const s=new Image;s.crossOrigin="anonymous",s.onload=()=>{const h=document.createElement("canvas");h.width=s.naturalWidth,h.height=s.naturalHeight;const l=h.getContext("2d");if(!l){d(new Error("Canvas context failed"));return}l.drawImage(s,0,0),u(h.toDataURL("image/png"))},s.onerror=d,s.src=r}),St=({initialImage:r,onChooseAnotherImage:u,onBackToHome:d,SettingsPanel:s,initialSettings:h,onGenerate:l,downloadFilename:b,keepPanelOpenOnGenerate:D=!1,onImageUpdate:C,cropAspectRatios:A,onRefCropConfirm:F,allowBatchUpload:V=!1,processBatchUpload:v,GalleryComponent:G,allowNoImage:R=!1,preventAutoSetOriginalImage:T=!1,settings:O,onSettingsChange:_,t:a,language:se,setLanguage:B})=>{const K=r,[t,m]=o(K),[p,y]=o([]),[c,S]=o(null),[W,H]=o(!1),[ue,z]=o(""),[q,E]=o("original"),[N,X]=o(null),[Q,Y]=o(!1),[Z,J]=o(!1),[Re,Te]=o(h),P=O!==void 0?O:Re,j=e=>{_?_(e):Te(e)},[_e,ae]=o(!1),[ze,Ee]=o(!0),[oe,re]=o(!1),[Pe,fe]=o(void 0),[ee,le]=o(null),[Le,Ue]=o([]);I(()=>{qe("image").then(Ue).catch(e=>console.error("Models fetch error",e))},[]);const[Ae,ce]=o(!1),[$e,de]=o(null),[me,Ge]=o("referenceImage"),ve={brightness:100,contrast:100,saturate:100,sepia:0,"hue-rotate":0},[L,xe]=o(ve),[te,M]=o(!1),[je,w]=o("none"),[Me,x]=o(0),U=Se(null),he=Se(P);I(()=>{he.current=P},[P]);const We=ke(()=>{},[]);I(()=>{T||m(r),y([]),S(null),z(""),E("original"),Y(!1),J(!1),M(!1)},[r]),I(()=>{te&&M(!1),xe(ve)},[c]);const Fe=(e,n="referenceImage")=>{const f=new FileReader;f.onload=()=>{de(f.result),Ge(n),ce(!0)},f.readAsDataURL(e)},Ve=e=>{j(n=>({...n,[me]:e})),ce(!1),de(null),F&&F(e,me,P,j)},Oe=()=>{ce(!1),de(null)},ne=ke(async e=>{if(!t&&!R)return;H(!0),fe(Date.now()),z(""),y([]),S(null),Y(!1),J(!1),M(!1),U.current&&(clearInterval(U.current),U.current=null);const n=Date.now(),f=54e4;w("editing"),x(0),U.current=window.setInterval(()=>{const g=Date.now()-n,$=Math.min(g/f*99,99);w("editing"),x($)},100);try{const g=await l(t,e||he.current,j,$=>{w($),$==="uploading"?x(10):$==="sending_request"?x(30):$==="generating"?x(60):$==="fetching_result"?x(90):$==="done"&&x(100)});g.length>0?(y(g),S(g[0]),G||E("generated")):z(a("imageGenFailed"))}catch(g){z(Ie(g,a))}finally{U.current&&(clearInterval(U.current),U.current=null),H(!1),w("none"),x(0)}},[t,l,D,a,G,R]),Be=()=>{Y(e=>{const n=!e;return n&&J(!1),n})},Ke=()=>{J(e=>{const n=!e;return n&&Y(!1),n})};I(()=>{const e=n=>{if(n.key==="*"){const f=n.target;["INPUT","TEXTAREA","SELECT"].includes(f.tagName)||(n.preventDefault(),Ee(g=>!g))}};return window.addEventListener("keydown",e),()=>window.removeEventListener("keydown",e)},[]),I(()=>{const e=n=>{if(te||oe)return;const f=n.target;if(!["INPUT","TEXTAREA","SELECT"].includes(f.tagName)&&(n.key==="Enter"&&!W&&t&&(n.preventDefault(),ne()),n.code==="Space"&&c&&!Q&&!Z&&(n.preventDefault(),E(g=>g==="original"?"generated":"original")),n.key==="Escape"&&N&&X(null),(n.key==="ArrowRight"||n.key==="ArrowLeft")&&p.length>1)){n.preventDefault();const g=p.findIndex(ge=>ge===c);let $;n.key==="ArrowRight"?$=(g+1)%p.length:g===-1?$=p.length-1:$=(g-1+p.length)%p.length,S(p[$])}};return window.addEventListener("keydown",e),()=>window.removeEventListener("keydown",e)},[c,N,W,t,ne,Q,Z,te,oe,p]);const ie=e=>{T||m(e),C&&C(e)},be=async e=>{if(e.length>0)if(V&&v){const n=await v(e,P,j);n&&ie(n)}else{const n=e[0],f=new FileReader;f.onload=g=>{ie(g.target.result)},f.readAsDataURL(n)}},He=async(e,n,f)=>{if(!ee)return;const g=ee;le(null),z(""),H(!0),fe(Date.now()),w("uploading"),x(10);try{const $=await mt(g),{url:ge}=await dt($,void 0,1e3);w("generating"),x(50);const pe=await gt(e,"upscale",void 0,void 0,void 0,n,f,void 0,k=>{w(k),k==="pending"?x(60):k==="processing"?x(80):k==="fetching_result"&&x(90)},ge);y(k=>{const ye=k.indexOf(g);if(ye!==-1){const we=[...k];return we[ye]=pe,we}return[...k,pe]}),S(pe),x(100),w("done")}catch($){z(Ie($,a))}finally{H(!1),w("none")}};return i`
        <div class="editor-layout ${ze?"":"panel-hidden"}">
            ${W&&i`<${pt} progress=${Me} phase=${je} startTime=${Pe} t=${a} />`}
            ${ue&&i`<${Xe} message=${ue} onClose=${()=>z("")} />`}
            ${N&&i`<${Qe} src=${N} onClose=${()=>X(null)} t=${a} />`}
            ${ee&&i`<${$t} 
                onConfirm=${He} 
                onCancel=${()=>le(null)} 
                models=${Le}
                targetImages=${[{id:0,url:ee}]}
                t=${a}
            />`}

            ${te&&c&&i`
                <${Ye}
                    src=${c}
                    adjustments=${L}
                    setAdjustments=${xe}
                    onSave=${async e=>{try{y(n=>n.map(f=>f===c?e:f)),S(e),M(!1)}catch(n){console.error("Save edit failed",n)}}}
                    onCancel=${()=>M(!1)}
                    t=${a}
                />
            `}

            ${oe&&t&&i`
                <${Ce}
                    imageUrl=${t}
                    onCrop=${e=>{ie(e),re(!1)}}
                    onCancel=${()=>re(!1)}
                    t=${a}
                    aspectRatios=${A}
                />
            `}

            ${Ae&&$e&&i`
                <${Ce}
                    imageUrl=${$e}
                    onCrop=${Ve}
                    onCancel=${Oe}
                    t=${a}
                    aspectRatios=${A}
                />
            `}

            <div class="image-panel ${_e?"dragging":""}"
                onDragOver=${e=>{e.preventDefault(),ae(!0)}}
                onDragLeave=${()=>ae(!1)}
                onDrop=${e=>{e.preventDefault(),ae(!1),be(e.dataTransfer.files)}}>
                
                ${!t&&!R?i`
                    <${Ze} 
                        onImageUpload=${ie} 
                        onBatchUpload=${be} 
                        allowMultiple=${V}
                        t=${a} 
                    />
                `:i`
                    <div class="view-controls">
                        <div class="view-tabs">
                            <button class="view-tab ${q==="original"?"active":""}" onClick=${()=>E("original")}>
                                ${a("viewOrig")}
                            </button>
                            ${p.length>0&&i`
                                <button class="view-tab ${q==="generated"?"active":""}" onClick=${()=>E("generated")}>
                                    ${a("viewGen")}
                                </button>
                            `}
                        </div>

                        ${p.length>0&&i`
                            <div class="view-modes">
                                <button class="mode-btn ${Q?"active":""}" onClick=${Be} title=${a("sliderView")}>
                                    <${Je} />
                                </button>
                                <button class="mode-btn ${Z?"active":""}" onClick=${Ke} title=${a("sideBySide")}>
                                    <${et} />
                                </button>
                            </div>
                        `}

                        <div class="action-buttons">
                           ${q==="original"&&t&&i`
                                <button class="action-btn" onClick=${()=>re(!0)} title=${a("crop")}>
                                    <${tt} />
                                </button>
                           `}
                           
                           ${c&&i`
                                <button class="action-btn" onClick=${()=>M(!0)} title=${a("adjust")}>
                                    <${nt} />
                                </button>
                                <button class="action-btn" onClick=${()=>le(c)} title=${a("upscale")}>
                                    <${De} />
                                </button>
                                <button class="action-btn" onClick=${()=>it(c,b)} title=${a("download")}>
                                    <${st} />
                                </button>
                           `}
                        </div>
                    </div>

                    <div class="view-container" style=${{flex:1,minHeight:0,position:"relative",width:"100%",display:"flex",flexDirection:"column"}}>
                        ${Q&&t&&c?i`
                            <${at} original=${t} generated=${c} />
                        `:Z&&t&&c?i`
                            <div class="side-by-side">
                                <div class="image-wrapper">
                                    <img src=${t} alt="Original" />
                                    <span class="badge">${a("viewOrig")}</span>
                                </div>
                                <div class="image-wrapper">
                                    <img src=${c} alt="Generated" />
                                    <span class="badge">${a("viewGen")}</span>
                                </div>
                            </div>
                        `:q==="original"&&t?i`
                            <div class="image-wrapper" style=${{position:"relative",width:"100%",height:"100%",display:"flex",alignItems:"center",justifyContent:"center",overflow:"hidden"}}>
                                <img src=${t} alt="Original" onClick=${()=>X(t)} style=${{maxWidth:"100%",maxHeight:"100%",objectFit:"contain"}} />
                                <button 
                                    class="btn-choose-another" 
                                    onClick=${u}
                                    style=${{position:"absolute",top:"20px",right:"20px",background:"rgba(0,0,0,0.6)",color:"#fff",border:"none",padding:"8px 16px",borderRadius:"8px",cursor:"pointer",display:"flex",alignItems:"center",gap:"8px",zIndex:10,fontSize:"14px"}}
                                >
                                    <${ot} /> ${a("choose_another_image")}
                                </button>
                            </div>
                        `:c?i`
                            <div class="image-wrapper">
                                <img 
                                    src=${c} 
                                    alt="Generated" 
                                    onClick=${()=>X(c)} 
                                    style=${L?{filter:`brightness(${L.brightness}%) contrast(${L.contrast}%) saturate(${L.saturate}%) sepia(${L.sepia}%) hue-rotate(${L["hue-rotate"]}deg)`}:{}}
                                />
                            </div>
                        `:i`
                            <div class="empty-state">
                                <${rt} />
                                <p>${a("noGenYet")}</p>
                            </div>
                        `}
                    </div>

                    ${p.length>1&&i`
                        <div class="image-thumbnails">
                            ${p.map((e,n)=>i`
                                <div class="thumbnail ${e===c?"active":""}" onClick=${()=>{S(e),E("generated")}}>
                                    <img src=${e} alt="Generated ${n+1}" />
                                </div>
                            `)}
                        </div>
                    `}

                    ${G&&i`<${G} 
                        images=${p} 
                        onSelect=${e=>{S(e),E("generated")}}
                        selectedImage=${c}
                        settings=${P}
                        setSettings=${j}
                        onGenerate=${ne}
                        generating=${W}
                        originalImage=${t}
                        t=${a}
                    />`}
                `}
            </div>

            <${s}
                settings=${P}
                setSettings=${j}
                onGenerate=${ne}
                generating=${W}
                hasImage=${!!t||R}
                onBackToHome=${d}
                onEnterFullscreen=${We}
                onChooseAnotherImage=${u}
                onLaunchRefCrop=${Fe}
                t=${a}
                language=${se}
                setLanguage=${B}
                currentImage=${t}
            />
            
            <${Ne} t=${a} />
        </div>
    `};export{It as C,yt as G,Ct as P,St as S,$t as U,bt as a,wt as g,mt as u};
